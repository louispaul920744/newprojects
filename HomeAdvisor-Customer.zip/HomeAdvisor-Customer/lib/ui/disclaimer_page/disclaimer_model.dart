/// count : 1
/// next : ""
/// previous : ""
/// results : [{"id":1,"description_en":"<p><strong>Disclaimer</strong></p>\r\n\r\n<p><br />\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>","description_ar":"<p>لماذا نستخدمه؟<br />\r\nهناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. الهدف من استخدام لوريم إيبسوم هو أنه يحتوي على توزيع طبيعي -إلى حد ما- للأحرف ، بدلاً من استخدام &quot;هنا يوجد محتوى نصي ، هنا يوجد محتوى نصي&quot; ، مما يجعلها تبدو وكأنها إنجليزية قابلة للقراءة. تستخدم العديد من حزم النشر المكتبي ومحرري صفحات الويب الآن Lorem Ipsum كنص نموذج افتراضي ، وسيكشف البحث عن &quot;lorem ipsum&quot; عن العديد من مواقع الويب التي لا تزال في مهدها. تطورت إصدارات مختلفة على مر السنين ، أحيانًا عن طريق الصدفة ، وأحيانًا عن قصد (روح الدعابة وما شابه ذلك).</p>","image":"https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-1.jpg"}]

class DisclaimerModel {
  int _count;
  String _next;
  String _previous;
  List<Results> _results;

  int get count => _count;
  String get next => _next;
  String get previous => _previous;
  List<Results> get results => _results;

  DisclaimerModel(
      {int count, String next, String previous, List<Results> results}) {
    _count = count;
    _next = next;
    _previous = previous;
    _results = results;
  }

  DisclaimerModel.fromJson(dynamic json) {
    _count = json["count"];
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["count"] = _count;
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 1
/// description_en : "<p><strong>Disclaimer</strong></p>\r\n\r\n<p><br />\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>"
/// description_ar : "<p>لماذا نستخدمه؟<br />\r\nهناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. الهدف من استخدام لوريم إيبسوم هو أنه يحتوي على توزيع طبيعي -إلى حد ما- للأحرف ، بدلاً من استخدام &quot;هنا يوجد محتوى نصي ، هنا يوجد محتوى نصي&quot; ، مما يجعلها تبدو وكأنها إنجليزية قابلة للقراءة. تستخدم العديد من حزم النشر المكتبي ومحرري صفحات الويب الآن Lorem Ipsum كنص نموذج افتراضي ، وسيكشف البحث عن &quot;lorem ipsum&quot; عن العديد من مواقع الويب التي لا تزال في مهدها. تطورت إصدارات مختلفة على مر السنين ، أحيانًا عن طريق الصدفة ، وأحيانًا عن قصد (روح الدعابة وما شابه ذلك).</p>"
/// image : "https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-1.jpg"

class Results {
  int _id;
  String _descriptionEn;
  String _descriptionAr;
  String _image;

  int get id => _id;
  String get descriptionEn => _descriptionEn;
  String get descriptionAr => _descriptionAr;
  String get image => _image;

  Results({int id, String descriptionEn, String descriptionAr, String image}) {
    _id = id;
    _descriptionEn = descriptionEn;
    _descriptionAr = descriptionAr;
    _image = image;
  }

  Results.fromJson(dynamic json) {
    _id = json["id"];
    _descriptionEn = json["description_en"];
    _descriptionAr = json["description_ar"];
    _image = json["image"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["description_en"] = _descriptionEn;
    map["description_ar"] = _descriptionAr;
    map["image"] = _image;
    return map;
  }
}
