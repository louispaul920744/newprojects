import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_maps_webservice/src/core.dart' as L;
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart';
import 'package:home_advisor/ui/success_page/success_page.dart';
import 'package:stacked/stacked.dart';

class SummaryViewModel extends BaseViewModel {
  bool _isCheckBoxSelected = false;

  bool get getCheckBoxSelected => _isCheckBoxSelected;

  final UserService _userService = locator<UserService>();
  OrderModel order;
  List<String> _images = [];

  void bookOrder({
    String locationString,
    int service,
    L.Location location,
    String date,
    String time,
    String comments,
    int amount,
    bool visit,
    List<File> images,
    List<Answers> answers,
    List<Surveys> surveys,
  }) {
    order = OrderModel(
      service: service,
      location: Location(
        addressEn: locationString,
        addressAr: locationString,
        cooridinates: Cooridinates(
          lat: location.lat,
          lng: location.lng,
        ),
      ),
      date: date,
      time: time,
      comments: comments,
      visit: visit,
      answers: answers,
      surveys: surveys,
    );

    _images.addAll(images.map((e) {
      return e.path;
    }));
  }

  set checkBoxSelected(bool isSelected) {
    _isCheckBoxSelected = isSelected;
    notifyListeners();
  }

  void submitAction(BuildContext context) async {
    var response = await APIServices.putOrder(
      order,
      _userService.token,
    );

    if (response != null) {
      if (_images.isNotEmpty) {
        await APIServices.uploadImages(
          _images,
          _userService.token,
          response.id.toString(),
        );

        navigateToPage(context);
      } else {
        navigateToPage(context);
      }
    }
  }

  void navigateToPage(BuildContext context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => SuccessPage(),
      ),
      (Route<dynamic> route) => route.isFirst,
    );
  }
}
