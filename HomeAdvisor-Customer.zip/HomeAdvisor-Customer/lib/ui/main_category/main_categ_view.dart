import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/locationdate/locationdate_view.dart';
import 'package:home_advisor/ui/main_category/main_categ_model.dart';
import 'package:home_advisor/ui/notification_page/notification_page_view.dart';
import 'package:home_advisor/ui/select_location/select_location.dart';
import 'package:home_advisor/ui/survey_page/survey_page_model.dart';
import 'package:home_advisor/ui/survey_page/survey_page_view.dart';
import 'package:home_advisor/ui/widgets/main_category_tile.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:stacked/stacked.dart';

import 'CategorySearchDelegate.dart';
import 'main_categ_viewmodel.dart';

class MainCategView extends StatelessWidget {
  List<DropdownMenuItem> menuitems = List();

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<MainCategViewModel>.reactive(
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          actions: [
            model.isLoading == true
                ? Container(
                    width: 45.w,
                  )
                : Stack(
                    children: [
                      Container(
                        margin: EdgeInsets.only(right: 5),
                        child: IconButton(
                          icon: Container(
                            child: Icon(
                              Icons.notifications_none_outlined,
                              size: 42,
                            ),
                          ),
                          onPressed: () async {
                            bool isVisted = await Navigator.pushNamed(
                              context,
                              NotificationPage.id,
                              arguments: model.isNotificationPageOpened,
                            ) as bool;
                            if (isVisted ?? true) {
                              model.initState();
                            }
                          },
                          color: AppColor.blCommon,
                        ),
                      ),
                      Positioned(
                        right: 4,
                        child: Container(
                          width: 40.w,
                          height: 40.h,
                          margin: EdgeInsets.only(top: 5),
                          child: Center(
                            child: Text(
                              "${model.notReadNotification.isEmpty ? "0" : model.notReadNotification.length}",
                              style: AppTextStyles.textStyle(
                                color: Colors.white,
                                fontType: FontType.bold,
                                size: 20.f,
                              ),
                            ),
                          ),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.red,
                          ),
                        ),
                      ),
                    ],
                  ),
            Container(
              margin: EdgeInsets.only(right: 5),
              child: Text(''),
            ),
          ],
          elevation: 1,
          backgroundColor: Colors.white,
          title: Container(
            width: 125,
            height: 42,
            margin: EdgeInsets.only(left: 5, right: 5),
            child: Image.asset(
              model.logo,
            ),
          ),
        ),
        body: Container(
          color: Colors.white,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(8.0),
                margin: EdgeInsets.symmetric(horizontal: 22),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () async {
                        var selected = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SelectLocation(language.lang),
                          ),
                        );
                        if (selected != null) {
                          model.selectMunicipality(selected);
                        }
                      },
                      child: Row(
                        children: [
                          Text(
                            model.selectedMunicipality['city'] ?? "Select",
                            style: buildTextStyle(),
                          ),
                          Icon(
                            Icons.keyboard_arrow_down,
                            color: buildColor(),
                          )
                        ],
                      ),
                    ),
                    Text(
                      'Change location',
                      style: buildTextStyle(),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(4.0),
                margin: EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                height: 58,
                child: InkWell(
                  onTap: () async {
                    final SearchResult selected =
                        await showSearch<SearchResult>(
                      context: context,
                      delegate: SearchDemoSearchDelegate(model.token),
                    );

                    if (selected != null) {
                      Fluttertoast.showToast(msg: 'Please wait');
                      List<SurveyResults> ss = List();
                      try {
                        ss = (await APIServices.getSurvey(model.token)).results;
                        ss = ss.where((e) => e.service == selected.id).toList();
                        print(ss.length);
                        print('suahil');
                      } catch (e) {
                        print('eeror');
                        print(e);
                        Sentry.captureException(e);
                      }
                      if (ss.length > 0)
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SurveyPage(
                              id: selected.id,
                              appBarName: language.lang == 'ar'
                                  ? selected.nameAr
                                  : selected.name,
                              categId: 0,
                              subCategId: 0,
                              serviceId: selected.id,
                            ),
                          ),
                        );
                      else
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => LocationDatePage(
                              answers: [],
                              surveys: [],
                              sid: selected.id,
                              service: language.lang == 'ar'
                                  ? selected.nameAr
                                  : selected.name,
                            ),
                          ),
                        );
                    }
                    print(selected.toJson());
                  },
                  child: TextField(
                    enabled: false,
                    decoration: new InputDecoration(
                        contentPadding: EdgeInsets.all(8),
                        prefixIcon: Icon(
                          Icons.search_rounded,
                          color: buildColor(),
                        ),
                        disabledBorder: new OutlineInputBorder(
                          borderSide: BorderSide(
                            color: buildColor(),
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        focusedBorder: new OutlineInputBorder(
                          borderSide: BorderSide(
                            color: buildColor(),
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        filled: true,
                        hintStyle: new TextStyle(
                          color: buildColor(),
                        ),
                        hintText: "Search for service",
                        fillColor: Colors.white70),
                  ),
                ),
              ),
              Container(
                height: 300.h,
                width: double.infinity,
                color: Color(0xFF65BDF7),
                child: Container(
                    margin: EdgeInsets.symmetric(vertical: 14),
                    child: FutureBuilder<Response>(
                      future: get('http://backend.homeadvisor.qa/api/banners/'),
                      builder: (context, snapshot) {
                        if (snapshot.hasData && snapshot.data != null) {
                          var data = jsonDecode(
                              utf8.decode(snapshot.data.bodyBytes))['results'];
                          print('suhail');
                          print(data);

                          return PageView(
                            controller: PageController(
                              viewportFraction: .8,
                              initialPage: 0,
                            ),
                            children: [
                              for (int i = 0; i < data.length; i++)
                                Container(
                                  margin: EdgeInsets.only(right: 32),
                                  child: ClipRRect(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8)),
                                    child: Image.network(
                                      data[i]['image'],
                                      height: 235.h,
                                      width: 425.h,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                            ],
                          );
                        }
                        return Text('');
                      },
                    )),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: model.getToken() != null
                      ? FutureBuilder(
                          future: APIServices.getCateg(model.token),
                          builder:
                              (_, AsyncSnapshot<MainCategResponse> snapshot) {
                            if (snapshot.connectionState ==
                                    ConnectionState.done &&
                                snapshot.hasData) {
                              List<MainCategory> categories =
                                  snapshot.data.results;
                              return categories.length > 0
                                  ? GridView.count(
                                      childAspectRatio: (1),
                                      crossAxisCount: 3,
                                      children: List.generate(categories.length,
                                          (index) {
                                        return MainCategoryTile(
                                          name: language.lang == 'ar'
                                              ? categories[index].nameAr
                                              : categories[index].name,
                                          address: categories[index].icon,
                                          title: language.lang == 'ar'
                                              ? categories[index].nameAr
                                              : categories[index].name,
                                          categId: categories[index].id,
                                        );
                                      }),
                                    )
                                  : Center(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            language.lang == 'en'
                                                ? "Hello User !"
                                                : "لا توجد خدمات متاحة",
                                            style: AppTextStyles.s3(
                                              AppColor.blCommon,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 4,
                                          ),
                                          Text(
                                              language.lang == 'en'
                                                  ? "Currently we don't have any services to this location"
                                                  : "لا توجد خدمات متاحة",
                                              style: AppTextStyles.s2(
                                                AppColor.blCommon,
                                              )),
                                        ],
                                      ),
                                    );
                            } else {
                              return Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              );
                            }
                          },
                        )
                      : Center(
                          child: CircularProgressIndicator(
                          backgroundColor: AppColor.rdCommon,
                        )),
                ),
              )
            ],
          ),
        ),
      ),
      viewModelBuilder: () => MainCategViewModel(),
      onModelReady: (model) {
        model.getNotification();
        print("hello");
      },
    );
  }

  Color buildColor() => Color(0xFF14287B);

  TextStyle buildTextStyle() {
    return TextStyle(
        color: buildColor(), fontSize: 15, fontWeight: FontWeight.w700);
  }
}
