import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/notification_page/notification_page_model.dart';
import 'package:stacked/stacked.dart';

class MainCategViewModel extends BaseViewModel {
  UserService _userService = locator<UserService>();
  Notification _notification;
  bool _isLoaded = false;
  List<Results> _notReadNotifications = [];
  bool _openedNotificationPage = false;
  String token;
  String getToken() {
    token = _userService.token;
    return token;
  }

  bool get isNotificationPageOpened => _openedNotificationPage;
  List<Results> get notReadNotification => _notReadNotifications;
  Notification get notification => _notification;
  bool get isLoading => _isLoaded;

  bool _isEmpty = false;

  set visitedNotificationPage(bool visited) {
    _openedNotificationPage = visited;
    notifyListeners();
  }

  set isLoaded(bool loaded) {
    _isLoaded = loaded;
    notifyListeners();
  }

  set isEmpty(bool isEmpty) {
    _isEmpty = isEmpty;
    notifyListeners();
  }

  String logo = "lib/images/logo/logo.png";

  void initState() {
    _notReadNotifications = [];
    getNotification();
  }

  Future getNotification() async {
    isLoaded = true;

    print('suhailtssssss');
    print(
        'sssssssssssssssssssssssssssssssss   ${_userService.user.municipality}');
    print(_userService.user.municipality.toString());
    if (_userService.user.municipality != 0) {
      print('sssssssssssssssssssssss ${_userService.user.municipality}');
      List<Map<String, dynamic>> locaiton = Helper.municipalitiesArray('en')
          .where((element) => element['id'] == _userService.user.municipality)
          .toList();
      print('ssssssssss ..... ${locaiton.first}');

      if (locaiton.length > 0)
        _selectedMunicipality = {
          ...locaiton.first,
          'city': locaiton.first['name']
        };
      notifyListeners();
    }

    _notification = await APIServices.getNotification(_userService.token);
    print(_notification.results);
    isLoaded = false;
    if (_notification != null &&
        _notification.results != null &&
        _notification.results.isNotEmpty) {
      _notification.results.forEach((element) {
        if (element.isRead == false) {
          _notReadNotifications.add(element);
        }
      });
    } else {
      isEmpty = true;
    }
  }

  Map _selectedMunicipality = {};

  get selectedMunicipality => _selectedMunicipality;

  Future<void> selectMunicipality(var selectedMunicipalit) async {
    _isLoaded = true;
    notifyListeners();

    _userService.user.municipality = selectedMunicipalit['id'];
    await APIServices.updateProfile(_userService.user, token);
    _selectedMunicipality = selectedMunicipalit;

    notifyListeners();
    _isLoaded = false;

    notifyListeners();
  }
}
