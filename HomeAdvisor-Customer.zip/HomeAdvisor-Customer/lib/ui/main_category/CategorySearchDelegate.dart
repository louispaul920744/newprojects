import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/widgets/main_category_tile.dart';
import 'package:provider/provider.dart';

class SearchDemoSearchDelegate extends SearchDelegate<SearchResult> {
  final token;

  SearchDemoSearchDelegate(this.token);

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      tooltip: 'Back',
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: () {
        close(context, null);
      },
    );
  }

  Future getSearchResults() async {
    // await Future.delayed(Duration(seconds: 1));
    print('data');
    // print(data);
    if (query.isEmpty) {
      final data = await APIServices.searchTag(token);
      return data;
    } else {
      List<SearchResult> results =
          await APIServices.searchService(token, query);
      return results;
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return FutureBuilder(
      future: getSearchResults(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            alignment: Alignment.center,
            margin: EdgeInsets.all(14),
            child: CircularProgressIndicator(),
          );
        }

        if (snapshot.hasData) {
          if (snapshot.data.length < 1)
            return Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(14),
              child: Text(
                'No Results Found',
              ),
            );
          else
            return _SuggestionList(
              query: query,
              suggestions: snapshot.data,
              onSelected: (dynamic suggestion, bool isTag) {
                if (isTag)
                  query = suggestion;
                else {

                  close(context, suggestion);
                }
                // print('sss');
                // print(suggestion);
                // showResults(context);
              },
            );
        }
        return Text('fffd');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Text('404');
  }

  @override
  List<Widget> buildActions(BuildContext context) {
    return <Widget>[
      if (query.isNotEmpty)
        IconButton(
          tooltip: 'Clear',
          icon: const Icon(Icons.clear),
          onPressed: () {
            query = '';
            showSuggestions(context);
          },
        ),
    ];
  }
}

class _SuggestionList extends StatelessWidget {
  const _SuggestionList({this.suggestions, this.query, this.onSelected});

  final List<dynamic> suggestions;
  final String query;
  final Function onSelected;

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    if (query.isNotEmpty)
      return Container(
        margin: EdgeInsets.all(8),
        child: GridView.count(
          childAspectRatio: (1.5),
          crossAxisSpacing: 10,
          mainAxisSpacing: 20,
          crossAxisCount: 2,
          children: List.generate(suggestions.length, (index) {
            SearchResult searchResult = suggestions[index];
            return MainCategoryTile(
              name: language.lang == 'ar'
                  ? searchResult.nameAr
                  : searchResult.name,
              address: searchResult.icon,
              title: language.lang == 'ar'
                  ? searchResult.nameAr
                  : searchResult.name,
              categId: searchResult.id,
              onSelected: (_) => onSelected(searchResult, false),
            );
          }),
        ),
      );
    else {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        alignment: Alignment.topCenter,
        child: Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: suggestions
              .map(
                (item) => Container(
                  margin: EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: InputChip(
                    labelPadding:
                        EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                    label: Text(item['name']),
                    avatar: CircleAvatar(
                      backgroundImage: NetworkImage(
                          'https://www.clipartmax.com/png/middle/54-543649_round-plumber-icon-with-wrench-and-house-vector-image-repairing-man-icon.png'),
                    ),
                    onSelected: (_) => onSelected(item['name'], true),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              )
              .toList(),
        ),
      );
    }
  }
}

class SearchResult {
  int id;
  String name;
  String nameAr;
  String description;
  String descriptionAr;
  String icon;

  SearchResult(
      {this.id,
      this.name,
      this.nameAr,
      this.description,
      this.descriptionAr,
      this.icon});

  SearchResult.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    nameAr = json['name_ar'];
    description = json['description'];
    descriptionAr = json['description_ar'];
    icon = json['icon'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['name_ar'] = this.nameAr;
    data['description'] = this.description;
    data['description_ar'] = this.descriptionAr;
    data['icon'] = this.icon;
    return data;
  }
}
