class OrderPostModel {
  int id;
  int service;
  String orderNo;
  Location location;
  String date;
  String time;
  String comments;
  bool visit;

  OrderPostModel(
      {this.id,
      this.service,
      this.orderNo,
      this.location,
      this.date,
      this.time,
      this.comments,
      this.visit});

  OrderPostModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    service = json['service'];
    orderNo = json['order_no'];
    location = json['location'] != null
        ? new Location.fromJson(json['location'])
        : null;
    date = json['date'];
    time = json['time'];
    comments = json['comments'];
    visit = json['visit'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['service'] = this.service;
    data['order_no'] = this.orderNo;
    if (this.location != null) {
      data['location'] = this.location.toJson();
    }
    data['date'] = this.date;
    data['time'] = this.time;
    data['comments'] = this.comments;
    data['visit'] = this.visit;
    return data;
  }
}

class Location {
  double lat;
  double lng;

  Location({this.lat, this.lng});

  Location.fromJson(Map<String, dynamic> json) {
    lat = json['lat'];
    lng = json['lng'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    return data;
  }
}