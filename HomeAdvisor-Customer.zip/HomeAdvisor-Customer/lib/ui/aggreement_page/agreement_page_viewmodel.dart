import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';
import 'package:home_advisor/ui/success_page/success_page.dart';
import 'package:stacked/stacked.dart';

import 'order_model.dart' as orderModel;

class AgreementPageViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  orderModel.OrderModel order;
  List<String> _images = [];
  ProfileModel user;
  int _sid;
  bool _buttonState = false;
  bool _isLoading = false;
  String _agreement = '';
  int amount;

  bool get buttonState => _buttonState;

  bool get isLoading => _isLoading;

  String get agreement => _agreement;

  set isLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void setButtonState(bool buttonState) {
    _buttonState = buttonState;
    notifyListeners();
  }

  void orderDetails({
    String locationString,
    int service,
    Location location,
    String date,
    String time,
    String comments,
    bool visit,
    List<File> images,
    List<orderModel.Answers> answers,
    List<orderModel.Surveys> surveys,
  }) {
    order = orderModel.OrderModel(
      service: service,
      location: orderModel.Location(
        addressEn: locationString,
        cooridinates: orderModel.Cooridinates(
          lat: location.lat,
          lng: location.lng,
        ),
      ),
      date: date,
      time: time,
      comments: comments,
      visit: visit,
      answers: answers,
      surveys: surveys,
    );

    _images.addAll(images.map((e) {
      return e.path;
    }));
    _sid = service;
  }

  void init() async {
    isLoading = true;
    String agreement = await APIServices.getAdminUserAgreement(
      _userService.token,
    );
    print("agreement $agreement");
    isLoading = false;
    if (agreement == null) {
      _agreement = '';
    } else {
      _agreement = agreement;
    }
  }

  void submitAction(BuildContext context) async {
    setButtonState(true);

    var response = await APIServices.putOrder(
      order,
      _userService.token,
    );
    if (amount != 0) {
      print('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
      var paymentResponse = await APIServices.postPayment(
        amount,
        response.id,
        _userService.token,
      );
    }
    if (response != null) {
      if (_images.isNotEmpty) {
        await APIServices.uploadImages(
          _images,
          _userService.token,
          response.id.toString(),
        );

        setButtonState(false);
        navigateToPage(context);
      } else {
        setButtonState(false);
        navigateToPage(context);
      }
    }
  }

  void navigateToPage(BuildContext context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => SuccessPage(),
      ),
      (Route<dynamic> route) => route.isFirst,
    );
  }
}
