import 'package:intl/intl.dart';

class OrderModel {
  bool visit;
  int service;
  int amount;
  Location location;
  String date;
  String time;
  String comments;
  List<Answers> answers;
  List<Surveys> surveys;

  OrderModel({
    this.service,
    this.location,
    this.date,
    this.time,
    this.amount,
    this.comments,
    this.answers,
    this.surveys,
    this.visit,
  });

  OrderModel.fromJson(Map<String, dynamic> json) {
    service = json['service'];
    location = json['location'] != null
        ? new Location.fromJson(json['location'])
        : null;
    date = json['date'];
    time = json['time'];

    comments = json['comments'];
    if (json['answers'] != null) {
      answers = new List<Answers>();
      json['answers'].forEach((v) {
        answers.add(new Answers.fromJson(v));
      });
    }
    if (json['surveys'] != null) {
      surveys = new List<Surveys>();
      json['surveys'].forEach((v) {
        surveys.add(new Surveys.fromJson(v));
      });
    }
  }
  String dateConverter(String date) {
    // Input date Format
    try {
      final format = DateFormat("hh:mm a");
      DateTime gettingDate = format.parse(date);
      final DateFormat formatter = DateFormat('HH:mm');
      // Output Date Format
      final String formatted = formatter.format(gettingDate);
      print(formatted);
      return formatted;
    } catch (e, s) {
      print(e);
      print(s);
      return date;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['service'] = this.service;
    if (this.location != null) {
      data['location'] = this.location.toJson();
    }
    data['visit'] = this.visit;
    data['amount'] = this.amount;
    data['date'] = this.date;
    print(this.time);

    data['time'] = dateConverter(this.time);
    data['comments'] = this.comments;
    if (this.answers != null) {
      data['answers'] = this.answers.map((v) => v.toJson()).toList();
    }
    if (this.surveys != null) {
      data['surveys'] = this.surveys.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Location {
  Cooridinates cooridinates;
  String addressEn;
  String addressAr;

  Location({this.cooridinates, this.addressEn, this.addressAr});

  Location.fromJson(Map<String, dynamic> json) {
    cooridinates = json['cooridinates'] != null
        ? new Cooridinates.fromJson(json['cooridinates'])
        : null;
    addressEn = json['address_en'];
    addressAr = json['address_ar'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.cooridinates != null) {
      data['cooridinates'] = this.cooridinates.toJson();
    }
    data['address_en'] = this.addressEn;
    data['address_ar'] = this.addressAr;
    return data;
  }
}

class Cooridinates {
  double lat;
  double lng;

  Cooridinates({this.lat, this.lng});

  Cooridinates.fromJson(Map<String, dynamic> json) {
    lat = json['lat'];
    lng = json['lng'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    return data;
  }
}

class Answers {
  int question;
  String answer;

  Answers({this.question, this.answer});

  Answers.fromJson(Map<String, dynamic> json) {
    question = json['question'];
    answer = json['answer'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['question'] = this.question;
    data['answer'] = this.answer;
    return data;
  }
}

class Surveys {
  int survey;
  int choice;

  Surveys({this.survey, this.choice});

  Surveys.fromJson(Map<String, dynamic> json) {
    survey = json['survey'];
    choice = json['choice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['survey'] = this.survey;
    data['choice'] = this.choice;
    return data;
  }
}
