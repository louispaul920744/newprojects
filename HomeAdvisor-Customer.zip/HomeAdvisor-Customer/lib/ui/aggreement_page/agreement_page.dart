import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:google_maps_webservice/places.dart' as ws;
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'agreement_page_viewmodel.dart';
import 'order_model.dart';

class AgreementPage extends StatelessWidget {
  final String date;
  final ws.Location latLong;
  final String time;
  final String comment;
  final DateTime seldate;
  final int sid;
  final bool visit;
  final String service;
  final List<File> images;
  final String location;
  final List<Surveys> surveys;
  final List<Answers> answers;
  final int amount;

  AgreementPage(
      {this.answers,
      this.surveys,
      this.sid,
      this.visit,
      this.seldate,
      this.date,
      this.time,
      this.latLong,
      this.comment,
      this.service,
      this.images,
      this.location,
      this.amount});

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<AgreementPageViewModel>.reactive(
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            toolbarHeight: 110.h,
            actions: [
              Container(
                margin: EdgeInsets.only(right: 5),
                child:
                    /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                    Text(''),
              )
            ],
            leadingWidth: double.infinity,
            leading: Column(
              children: [
                Container(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        ),
                        Text(
                          language.lang == 'en' ? "Go Back" : "عد",
                          style: AppTextStyles.textStyle(size: 16.f),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            flexibleSpace: Container(
              height: double.maxFinite,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.06,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      language.lang == 'en'
                          ? "Agreement with Admin and user"
                          : "الاتفاق مع المسؤول والمستخدم",
                      style: AppTextStyles.textStyle(
                        color: Colors.white,
                        size: 30.f,
                        fontType: FontType.regular,
                      ),
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    AppColor.blGradient2,
                    AppColor.blGradient1,
                  ],
                ),
              ),
            ),
            elevation: 1,
          ),
          body: model.isLoading == true
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      children: [
                        Html(
                          data: model.agreement,
                        ),
                        SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: model.buttonState == true
                              ? CircularProgressIndicator()
                              : Container(
                                  margin: EdgeInsets.only(left: 20, right: 20),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    gradient: LinearGradient(
                                      colors: [
                                        AppColor.rdGradient2,
                                        AppColor.rdGradient1
                                      ],
                                    ),
                                  ),
                                  height: 50,
                                  child: FlatButton(
                                    onPressed: () {
                                      model.submitAction(context);
                                    },
                                    child: Text(
                                      language.lang == 'en' ? "ACCEPT" : "قبول",
                                      style: TextStyle(fontSize: 40.f),
                                    ),
                                    textColor: Colors.white,
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
        );
      },
      onModelReady: (AgreementPageViewModel model) {
        model.orderDetails(
          locationString: location,
          service: sid,
          location: latLong,
          date: DateFormat("yyyy-MM-dd").format(seldate),
          time: time,
          comments: comment,
          visit: visit,
          answers: answers,
          surveys: surveys,
          images: images,
        );
        model.init();
        model.amount = amount;
      },
      viewModelBuilder: () => AgreementPageViewModel(),
    );
  }
}
