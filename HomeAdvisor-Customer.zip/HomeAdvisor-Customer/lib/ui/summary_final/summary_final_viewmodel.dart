import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_webservice/src/core.dart' as L;
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart' as O;
import 'package:home_advisor/ui/success_page/success_page.dart';
import 'package:stacked/stacked.dart';

enum PaymentOptions { payByCash, creditCard, ibanMoneyTransfer, notSelected }

class SummaryFinalviewModel extends BaseViewModel {
  PaymentOptions _option = PaymentOptions.notSelected;
  final UserService _userService = locator<UserService>();
  OrderModel order;
  List<String> _images = [];

  void orderDetails({
    String locationString,
    int service,
    L.Location location,
    String date,
    String time,
    String comments,
    bool visit,
    List<File> images,
    List<Answers> answers,
    List<Surveys> surveys,
    int amount,
  }) {
    this.amount = amount;
    order = OrderModel(
      service: service,
      location: O.Location(
        addressEn: locationString,
        cooridinates: Cooridinates(
          lat: location.lat,
          lng: location.lng,
        ),
      ),
      date: date,
      time: time,
      comments: comments,
      visit: visit,
      answers: answers.toSet().toList(),
      surveys: surveys.toSet().toList(),
    );

    _images.addAll(images.map((e) {
      return e.path;
    }));
  }

  void showToast(BuildContext context, {@required message}) {
    Fluttertoast.showToast(msg: message);
  }

  PaymentOptions get getOption => _option;
  int amount = 100;

  void changePaymentOption(PaymentOptions option) {
    _option = option;
    notifyListeners();
  }

  bool isSelected() {
    if (_option == PaymentOptions.notSelected) {
      return false;
    } else
      return true;
  }

  bool isPayCash() {
    if (_option == PaymentOptions.payByCash) {
      return true;
    } else
      return false;
  }

  void submitAction(BuildContext context) async {
    var response = await APIServices.putOrder(
      order,
      _userService.token,
    );
    if (amount != 0) {
      print('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
      var paymentResponse = await APIServices.postPayment(
        amount,
        response.id,
        _userService.token,
      );
    }
    if (response != null) {
      if (_images.isNotEmpty) {
        await APIServices.uploadImages(
          _images,
          _userService.token,
          response.id.toString(),
        );

        navigateToPage(context);
      } else {
        navigateToPage(context);
      }
    }
  }

  void navigateToPage(BuildContext context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => SuccessPage(),
      ),
      (Route<dynamic> route) => route.isFirst,
    );
  }
}
