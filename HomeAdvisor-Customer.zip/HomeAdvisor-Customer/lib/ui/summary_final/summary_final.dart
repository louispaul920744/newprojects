import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart' as orderModel;
import 'package:home_advisor/ui/summary_final/summary_final_viewmodel.dart';
import 'package:home_advisor/ui/widgets/summary_card.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class SummaryFinal extends StatelessWidget {
  final String location;
  final String date;
  final String time;
  final String comment;
  final Location latLong;
  final DateTime seldate;
  final String service;
  final int sid;
  final bool visit;
  final List<File> images;
  final List<orderModel.Surveys> surveys;
  final List<orderModel.Answers> answers;

  SummaryFinal(
      {this.surveys,
      this.answers,
      this.sid,
      this.latLong,
      this.visit,
      this.date,
      this.seldate,
      this.time,
      this.comment,
      this.service,
      this.images,
      this.location});

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<SummaryFinalviewModel>.reactive(
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            toolbarHeight: 110.h,
            actions: [
              Container(
                margin: EdgeInsets.only(right: 5),
                child:
                    /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                    Text(''),
              )
            ],
            leadingWidth: double.infinity,
            leading: Column(
              children: [
                Container(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        ),
                        Text(
                          language.lang == 'en' ? "Go Back" : "عد",
                          style: AppTextStyles.textStyle(size: 16.f),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            flexibleSpace: Container(
              height: double.maxFinite,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.06,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      language.lang == 'en' ? "Summary" : 'ملخص',
                      style: AppTextStyles.textStyle(
                          color: Colors.white,
                          size: 30.f,
                          fontType: FontType.regular),
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [AppColor.blGradient2, AppColor.blGradient1],
                ),
              ),
            ),
            elevation: 1,
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                child: Column(
                  children: [
                    SizedBox(
                      height: 10.0,
                    ),
                    SummaryCard(
                      location: location,
                      category: service,
                      date: date,
                      time: time,
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    Text(
                      language.lang == 'en'
                          ? "Inspection Amount"
                          : "مبلغ الفحص",
                      style: AppTextStyles.textStyle(
                        size: 40.f,
                        color: AppColor.blCommon,
                        fontType: FontType.bold,
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Text(
                      model.amount.toString() + " QAR",
                      style: AppTextStyles.textStyle(
                        size: 40.f,
                        color: AppColor.blCommon,
                        fontType: FontType.bold,
                      ),
                    ),
                    SizedBox(
                      height: 30.0,
                    ),
                    RadioListTile(
                      value: PaymentOptions.payByCash,
                      groupValue: model.getOption,
                      onChanged: (value) {
                        model.changePaymentOption(value);
                      },
                      title: Text(
                          language.lang == 'en' ? "Pay by Cash" : "الدفع نقدا"),
                    ),
                    RadioListTile(
                      value: PaymentOptions.creditCard,
                      groupValue: model.getOption,
                      onChanged: (value) {
                        model.changePaymentOption(value);
                      },
                      title: Text(language.lang == 'en'
                          ? "Credit Card"
                          : "بطاقة إئتمان"),
                    ),
                    RadioListTile(
                      value: PaymentOptions.ibanMoneyTransfer,
                      groupValue: model.getOption,
                      onChanged: (value) {
                        model.changePaymentOption(value);
                      },
                      title: Text(language.lang == 'en'
                          ? "IBAN - Money transfer"
                          : "IBAN - تحويل الأموال"),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        margin: EdgeInsets.only(left: 20, right: 20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          gradient: LinearGradient(
                            colors: [
                              AppColor.rdGradient2,
                              AppColor.rdGradient1
                            ],
                          ),
                        ),
                        height: 50,
                        child: FlatButton(
                          onPressed: () {
                            if (model.isSelected()) {
                              print('servefef $service');
                              model.orderDetails(
                                answers: answers,
                                comments: comment,
                                date: DateFormat("yyyy-MM-dd").format(seldate),
                                images: images,
                                locationString: location,
                                location: latLong,
                                service: sid,
                                surveys: surveys,
                                time: time,
                                visit: false,
                                amount: model.isPayCash() ? 0 : model.amount,
                              );
                              model.submitAction(context);
                              //
                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //     builder: (context) {
                              //       return AgreementPage(
                              //         surveys: surveys,
                              //         answers: answers,
                              //         location: location,
                              //         comment: comment,
                              //         latLong: latLong,
                              //         date: date,
                              //         seldate: seldate,
                              //         images: images,
                              //         service: service,
                              //         sid: sid,
                              //         visit: visit,
                              //         time: time,
                              //         amount:
                              //         model.isPayCash() ? 0 : model.amount,
                              //       );
                              //     },
                              //   ),
                              // );
                            } else
                              model.showToast(context,
                                  message: 'Select any payment method');
                          },
                          child: Text(
                            language.lang == 'en' ? "CONFIRM" : "تؤكد",
                            style: TextStyle(fontSize: 40.f),
                          ),
                          textColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => SummaryFinalviewModel(),
    );
  }
}
