import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_view.dart';
import 'package:home_advisor/ui/about_us_page/about_us_view.dart';
import 'package:home_advisor/ui/contact_us_page/contact_us_view.dart';
import 'package:home_advisor/ui/disclaimer_page/disclaimer_view.dart';
import 'package:home_advisor/ui/notification_page/notification_page_view.dart';
import 'package:home_advisor/ui/privacy_policy_page/privacy_policy_view.dart';
import 'package:home_advisor/ui/terms_and_conditions_page/terms_conditions_view.dart';
import 'package:home_advisor/ui/terms_of_use_page/terms_of_use_view.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'profile_viewmodel.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);
    return ViewModelBuilder<ProfileViewModel>.reactive(
      onModelReady: (model) {
        print(model.user.toJson());
      },
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          elevation: 0.w,
          leading: SizedBox(),
          backgroundColor: Colors.white,
          flexibleSpace: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding:
                    EdgeInsets.only(left: 30.0.w, right: 30.0.w, bottom: 10.w),
                child: Image.asset(
                  '${model.logo}',
                  width: 150.w,
                ),
              ),
            ],
          ),
          actions: [],
        ),
        body: model.isBusy
            ? Center(
                child: CircularProgressIndicator(),
              )
            : SingleChildScrollView(
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        model.user.photo == null
                            ? Container(
                                height: 430.h,
                                color: Colors.grey,
                                child: Center(
                                  child: Image.asset(
                                    'assets/user.webp',
                                    height: 100.h,
                                    width: 100.w,
                                  ),
                                ),
                              )
                            : Container(
                                height: 430.h,
                                color: Colors.grey,
                                child: FittedBox(
                                  fit: BoxFit.contain,
                                  child: CachedNetworkImage(
                                    imageUrl: model.user.photo,
                                  ),
                                ),
                              )
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 650.w, top: 10.0.h),
                      child: InkWell(
                        onTap: () => model.openEdit(context),
                        child: Container(
                          height: 50.0.h,
                          width: 60.0.w,
                          child: Image.asset('${model.edit}'),
                          decoration: BoxDecoration(
                              color: Colors.redAccent,
                              borderRadius: BorderRadius.circular(100.0)),
                        ),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 230.0.h),
                        Container(
                            margin:
                                EdgeInsets.only(left: 20.0.h, right: 20.0.h),
                            child: Text(
                              '${model.user.displayName ?? ""} ${model.user.lastName ?? ""}',
                              style: TextStyle(
                                fontSize: 44.f,
                                color: Colors.white,
                              ),
                            )),
                        SizedBox(
                          height: 15.0.h,
                        ),
                        Container(
                          height: MediaQuery.of(context).size.height * 0.16,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5.0),
                              color: Colors.white),
                          margin: EdgeInsets.all(20.0.h),
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  title: Text(
                                    '${model.user?.email ?? ""}',
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                                Divider(
                                  height: 1.h,
                                ),
                                ListTile(
                                  title: Align(
                                    alignment: language.lang == 'en'
                                        ? Alignment.centerLeft
                                        : Alignment.centerRight,
                                    child: Directionality(
                                      textDirection: TextDirection.ltr,
                                      child: Text(
                                        '${model.user.phoneNumber ?? ""}',
                                        style: TextStyle(
                                          fontSize: 30.f,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0.h,
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5.0)),
                          margin: EdgeInsets.all(20.0.h),
                          child: ListView(
                            primary: false,
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            children: [
                              GestureDetector(
                                onTap: () =>
                                    Navigator.pushNamed(context, FAQPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en' ? 'FAQ' : "التعليمات",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, DisclaimerPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Disclaimer'
                                        : "تنصل",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, PrivacyPolicyPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Privacy Policy'
                                        : "سياسة خاصة",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, TermsConditionsPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Terms & Conditions'
                                        : "البنود و الظروف",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, TermsOfUsePage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Terms Of Use'
                                        : "تعليمات الاستخدام",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.pushNamed(
                                    context,
                                    NotificationPage.id,
                                  );
                                },
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Notifications'
                                        : "إشعارات",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, ContactUsPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'Contact Us'
                                        : "اتصل بنا",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, AboutUsPage.id),
                                child: ListTile(
                                  title: Text(
                                    language.lang == 'en'
                                        ? 'About Us'
                                        : "معلومات عنا",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                ),
                              ),
                              Divider(
                                height: 1.h,
                              ),
                              ListTile(
                                  title: Text(
                                    language.lang == 'en' ? 'Arabic' : "عربى",
                                    style: TextStyle(
                                      fontSize: 30.f,
                                    ),
                                  ),
                                  trailing: Consumer<LanguageService>(
                                    builder: (context, model, child) {
                                      return CupertinoSwitch(
                                        onChanged: (isClicked) {
                                          if (isClicked) {
                                            model.setLanguagePreferance('ar');
                                          } else {
                                            model.setLanguagePreferance('en');
                                          }
                                        },
                                        value:
                                            model.lang == 'ar' ? true : false,
                                      );
                                    },
                                  )),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20.0.h,
                        ),
                        Container(
                          margin: EdgeInsets.all(20.0.h),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5.0)),
                          height: 80.0.h,
                          child: ListView(
                            primary: false,
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            children: [
                              ListTile(
                                title: Text(
                                  language.lang == 'en'
                                      ? 'Logout'
                                      : "تسجيل خروج",
                                  style: TextStyle(
                                    fontSize: 30.f,
                                  ),
                                ),
                                onTap: () => model.logout(context),
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
      ),
      viewModelBuilder: () => locator<ProfileViewModel>(),
    );
  }
}
