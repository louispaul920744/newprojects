class ProfileModel {
  String uid;
  String displayName;
  String lastName;
  String photo;
  String businessAddress;
  String areaBusiness;
  String location;
  String zipcode;
  String email;
  String phoneNumber;
  int role;
  int municipality;

  ProfileModel({
    this.uid,
    this.displayName,
    this.lastName,
    this.photo,
    this.businessAddress,
    this.areaBusiness,
    this.location,
    this.zipcode,
    this.email,
    this.phoneNumber,
    this.municipality,
    this.role,
  });

  ProfileModel.fromJson(Map<String, dynamic> json) {
    uid = json['uid'] == null ? null : json['uid'];
    displayName = json['display_name'] == null ? null : json['display_name'];
    lastName = json['last_name'] == null ? null : json['last_name'];
    photo = json['photo'] == null ? null : json['photo'];
    businessAddress =
        json['business_address'] == null ? null : json['business_address'];
    areaBusiness = json['area_business'] == null ? null : json['area_business'];
    location = json['location'] == null ? null : json['location'];
    zipcode = json['zipcode'] == null ? null : json['zipcode'];
    email = json['email'] == null ? null : json['email'];
    phoneNumber = json['phone_number'] == null ? null : json['phone_number'];
    role = json['role'] == null ? null : json['role'];
    municipality = json['municipality'] == null ? null : json['municipality'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['uid'] = this.uid == null ? null : this.uid;
    data['display_name'] = this.displayName == null ? null : this.displayName;
    data['last_name'] = this.lastName == null ? null : this.lastName;
    data['photo'] = this.photo == null ? null : this.photo;
    data['business_address'] =
        this.businessAddress == null ? null : this.businessAddress;
    data['area_business'] =
        this.areaBusiness == null ? null : this.areaBusiness;
    data['location'] = this.location == null ? null : this.location;
    data['zipcode'] = this.zipcode == null ? null : this.zipcode;
    data['email'] = this.email == null ? null : this.email;
    data['phone_number'] = this.phoneNumber == null ? null : this.phoneNumber;
    data['role'] = this.role == null ? null : this.role;
    data['municipality'] = this.municipality == null ? null : this.municipality;
    return data;
  }
}
