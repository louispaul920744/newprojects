import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/auth/firebase_auth_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/login_page/login_view.dart';
import 'package:home_advisor/ui/profile_edit/profile_edit.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';
import 'package:stacked/stacked.dart';


class ProfileViewModel extends BaseViewModel {
  FirebaseAuthService _authService = locator<FirebaseAuthService>();
  UserService _userService = locator<UserService>();
  ProfileModel get user => _userService.user;

  String logo = 'assets/logo.png';
  String edit = 'assets/edit.png';

  void logout(BuildContext context) {
    _authService.signOut();
    Navigator.pushNamedAndRemoveUntil(context, LoginView.id, (route) => false);
  }

  void openEdit(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileEdit(),
      ),
    );
    notifyListeners();
  }
}
