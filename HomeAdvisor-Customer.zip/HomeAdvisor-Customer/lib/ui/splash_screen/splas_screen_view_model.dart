import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/complete_profile/complete_profile_view.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:home_advisor/ui/start_page.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';

class SplashScreenViewModel extends BaseViewModel {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  final UserService _userService = locator<UserService>();
  bool hasMessage = false;

  Future<bool> isTokenUpdated() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isUpdated = prefs.getBool('fcm') ?? false;
    return isUpdated;
  }

  Future updateFCMToken(String token) async {
    await _userService.updateFCMToken(
        token, Platform.isAndroid ? 'android' : 'ios');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('fcm', true);
    return;
  }

  Future setupFirebase() async {
    if (!await isTokenUpdated()) {
      var token = await _firebaseMessaging.getToken();
      await updateFCMToken(token);

      print("FCM Token\n$token");
    }

    if (Platform.isIOS) {
      _firebaseMessaging.requestNotificationPermissions(
          const IosNotificationSettings(sound: true, badge: true, alert: true));
      _firebaseMessaging.onIosSettingsRegistered
          .listen((IosNotificationSettings settings) {
        print("Settings registered: $settings");
      });
    }
    return;
  }

  void initState(BuildContext context) async {
    await Future.delayed(Duration(milliseconds: 3000));
    bool authSucess = FirebaseAuth.instance?.currentUser?.phoneNumber != null;
    if (authSucess == false) {
      Navigator.pushReplacementNamed(context, StartPage.id);
    } else {
      var user = await _userService.getUser();
      await Provider.of<LanguageService>(
        context,
        listen: false,
      ).getLanguagePreferance();
      if (user?.displayName == null) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          CompleteProfileView.id,
          (route) => false,
        );
      } else {
        await setupFirebase();
        if (!hasMessage)
          Navigator.pushNamedAndRemoveUntil(
            context,
            HomePageView.id,
            (route) => false,
          );
      }
    }
  }
}
