import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:home_advisor/ui/splash_screen/splas_screen_view_model.dart';
import 'package:stacked/src/state_management/view_model_builder.dart';

class SplashScreenView extends StatefulWidget {
  static const String id = "SplashScreen";

  @override
  _SplashScreenViewState createState() => _SplashScreenViewState();
}

class _SplashScreenViewState extends State<SplashScreenView> {
  @override
  void initState() {
    super.initState();

    configureFirebase();
  }

  Future<void> configureFirebase() async {
    //--Configure firebase only for logged in users

    final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {},
      onLaunch: (Map<String, dynamic> message) async {
        debugPrint('onLaunch');
        debugPrint("onLaunch: $message");
        debugPrint("onLaunch: ${message['data']['data']}");
        checkAndSetFCMData(message);
      },
      onResume: (Map<String, dynamic> message) async {
        // checkAndSetFCMData(message);
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
    // model.dispose();
  }

  checkAndSetFCMData(message) {
    if (message['data']['type'] == 'chat') {
      model.hasMessage = true;
      Future.delayed(Duration(seconds: 2)).then((value) =>
          Navigator.pushNamedAndRemoveUntil(
              context, HomePageView.id, (route) => false,
              arguments: message));

      // Navigator.push(
      //   context,
      //   MaterialPageRoute(
      //     builder: (context) => ChatScreen(
      //       vendor: User(name: datum['name']),
      //       model: Results(
      //         vendor_uid: datum['vendorUid'],
      //         orderNo: datum['orderId'].toString(),
      //         chat_id: datum['chat_id'],
      //       ),
      //       chatId: datum['chat_id'],
      //     ),
      //   ),
      // );
    }
  }

  SplashScreenViewModel model;
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);
    return ViewModelBuilder<SplashScreenViewModel>.reactive(
      onModelReady: (model) {
        model.initState(context);
        this.model = model;
      },
      builder: (context, model, child) => Scaffold(
        body: Center(
          child: Container(
            height: 200.h,
            child: Image.asset("assets/1/logo.png"),
          ),
        ),
      ),
      viewModelBuilder: () => SplashScreenViewModel(),
    );
  }
}
