import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/orders_page/models/order_get_model.dart';
import 'package:home_advisor/ui/orders_page/models/orders_completed.dart'
    as completedOrder;
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart'
    as ongoingModel;
import 'package:home_advisor/ui/orders_page/orders_page_viewmodel.dart';
import 'package:home_advisor/ui/warranty/warranty_terms.dart';
import 'package:home_advisor/ui/widgets/orders_cards/orders_comp_card.dart';
import 'package:home_advisor/ui/widgets/orders_cards/orders_ongoing_card.dart';
import 'package:home_advisor/ui/widgets/orders_cards/orders_req_card.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class OrdersPage extends StatefulWidget {
  @override
  _OrdersPageState createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage>
    with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    LanguageService lang = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<OrdersPageViewModel>.reactive(
      onModelReady: (model) async {
        model.getToken();
        model.initState(this, lang);
      },
      builder: (context, model, child) => DefaultTabController(
        length: 3,
        child: Scaffold(
            appBar: AppBar(
              actions: [
                Container(
                    margin: EdgeInsets.only(right: 5),
                    child:
                        /* Icon(
                    Icons.search_outlined,
                    color: AppColor.blCommon,
                  ),*/
                        Text(''))
              ],
              elevation: 0,
              backgroundColor: Colors.white,
              leading: Container(
                  margin: EdgeInsets.only(left: 5, right: 5),
                  child: Image.asset(model.logo)),
            ),
            body: Column(
              children: [
                Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 15, right: 15),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.grey[400].withOpacity(0.1),
                    ),
                    child: TabBar(
                      controller: model.tabController,
                      indicator: BoxDecoration(),
                      labelColor: Colors.blue,
                      unselectedLabelColor: Colors.grey,
                      labelStyle: AppTextStyles.textStyle(size: 23.f),
                      tabs: [
                        Tab(
                          text: lang.lang == 'en' ? 'Requested' : "طلب",
                        ),
                        Tab(
                          text: lang.lang == 'en' ? "On Going" : "جاري التنفيذ",
                        ),
                        Tab(
                          text: lang.lang == 'en' ? 'Completed' : "منجز",
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    controller: model.tabController,
                    children: <Widget>[
                      Container(
                        color: Colors.white,
                        child: model.isLoading == false
                            ? model.listOfOrders.isEmpty
                                ? Center(
                                    child: Text(lang.lang == 'en'
                                        ? "No requested orders"
                                        : "لا توجد طلبات مطلوبة"),
                                  )
                                : ListView.builder(
                                    itemCount: model.listOfOrders.length,
                                    itemBuilder: (context, index) {
                                      Results list = model.listOfOrders[index];
                                      print(list.toJson());
                                      return OrdersCard(
                                        handleCancelOrder: (isCanceled) {
                                          model.cancelOrder(
                                            isCanceled,
                                            list.id,
                                            context,
                                          );
                                        },
                                        model: model,
                                        time: list.time,
                                        name: lang.lang == 'ar'
                                            ? list.name.arabic
                                            : list.name.english,
                                        date: list.date,
                                        location: lang.lang == 'ar'
                                            ? list.location.addressAr
                                            : list.location.addressEn,
                                        seriel: "#" + list.id.toString(),
                                        id: "#" + list.orderNo.toString(),
                                      );
                                    })
                            : Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              ),
                      ),
                      Container(
                        color: Colors.white,
                        child: FutureBuilder(
                          future: model.getOngoingOrders(),
                          builder: ((_,
                              AsyncSnapshot<List<ongoingModel.Results>>
                                  snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.active) {
                              return Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              );
                            } else if (snapshot.connectionState ==
                                    ConnectionState.done &&
                                snapshot.hasData) {
                              List<ongoingModel.Results> orders = snapshot.data;
                              if (orders.isEmpty) {
                                return Center(
                                  child: Text(
                                    lang.lang == 'en'
                                        ? "No Ongoing orders"
                                        : "لا توجد أوامر جارية",
                                  ),
                                );
                              }
                              return ListView.builder(
                                itemCount: orders.length,
                                itemBuilder: (mContext, index) {
                                  ongoingModel.Results list = orders[index];
                                  return OrdersOnGCard(
                                    pageContext: context,
                                    handleReport: (issue) async {
                                      await model.reportAnIssue(issue, list.id);
                                      Navigator.of(context).pop();
                                    },
                                    vendor: list.vendor.toString(),
                                    time: list.time,
                                    name: lang.lang == 'en'
                                        ? list.name.english
                                        : list.name.arabic,
                                    date: list.date,
                                    location: lang.lang == 'en'
                                        ? list.location.addressEn
                                        : list.location.addressAr,
                                    seriel: "#" + list.id.toString(),
                                    id: "#" + list.orderNo.toString(),
                                    status: list.status,
                                    model: list,
                                    paymentStatus: list.advancePaid == true
                                        ? "Advance paid"
                                        : "Advance Pending",
                                  );
                                },
                              );
                            } else {
                              return Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              );
                            }
                          }),
                        ),
                      ),
                      Container(
                        color: Colors.white,
                        child: FutureBuilder(
                          future: model.getCompletedOrders(),
                          builder: ((_,
                              AsyncSnapshot<List<completedOrder.Results>>
                                  snapshot) {
                            if (snapshot.data == null) {
                              return Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              );
                            } else if (snapshot.connectionState ==
                                    ConnectionState.done &&
                                snapshot.hasData) {
                              List<completedOrder.Results> orders =
                                  snapshot.data;
                              if (orders.isEmpty) {
                                return Center(
                                  child: Text(
                                    lang.lang == 'en'
                                        ? "No completed orders"
                                        : "لا توجد أوامر جارية",
                                  ),
                                );
                              }
                              return ListView.builder(
                                itemCount: orders.length,
                                shrinkWrap: true,
                                itemBuilder: (mContext, index) {
                                  completedOrder.Results list = orders[index];
                                  return OrdersCompCard(
                                    isReviewLoading: model.isLoadingRequested,
                                    time: list.time,
                                    model: list,
                                    name: lang.lang == 'en'
                                        ? list.name.english
                                        : list.name.arabic,
                                    date: list.date,
                                    isRated: list.reviewed,
                                    location: lang.lang == 'en'
                                        ? list.location.addressEn
                                        : list.location.addressAr,
                                    seriel: "#" + list.id.toString(),
                                    id: "#" + list.orderNo.toString(),
                                    handleReviewAndRating:
                                        (review, rating) async {
                                      await model.postReviewAndRate(
                                        review,
                                        rating,
                                        list.id,
                                      );
                                      model.initState(this, lang);
                                    },
                                    handleWarranty: () async {
                                      model.setLoading(true);
                                      model
                                          .getWarrantyTerms(
                                        list.id,
                                      )
                                          .then((value) {
                                        model.setLoading(false);

                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    WarrantyTerms(
                                                        text: value)));
                                      });
                                    },
                                  );
                                },
                              );
                            } else {
                              return Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ),
                              );
                            }
                          }),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )),
      ),
      viewModelBuilder: () => OrdersPageViewModel(),
    );
  }
}
