class OrderGetModel {
  var next;
  var previous;
  List<Results> results;

  OrderGetModel({this.next, this.previous, this.results});

  OrderGetModel.fromJson(Map<String, dynamic> json) {
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = new List<Results>();
      json['results'].forEach((v) {
        results.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.results != null) {
      data['results'] = this.results.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Results {
  int id;
  String orderNo;
  int service;
  Name name;
  int vendor;
  Location location;
  String date;
  String time;
  String comments;
  bool visit;
  String status;
  String createdAt;
  List<String> images;
  List<Answers> answers;
  List<Surveys> surveys;
  bool accepted;
  String estimatedAmount;
  String paidOrderAdvance;
  bool advancePaid;
  String paidAmount;
  String amountToBePaid;
  bool verified;
  bool canceled;
  var reason;
  bool reviewed;
  List<Vendorqoutes> vendorqoutes;
  List<Milestones> milestones;

  Results(
      {this.id,
      this.orderNo,
      this.service,
      this.name,
      this.vendor,
      this.location,
      this.date,
      this.time,
      this.comments,
      this.visit,
      this.status,
      this.createdAt,
      this.images,
      this.answers,
      this.surveys,
      this.accepted,
      this.estimatedAmount,
      this.paidOrderAdvance,
      this.advancePaid,
      this.paidAmount,
      this.amountToBePaid,
      this.verified,
      this.canceled,
      this.reason,
      this.reviewed,
      this.vendorqoutes,
      this.milestones});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderNo = json['order_no'];
    service = json['service'];
    name = json['name'] != null ? new Name.fromJson(json['name']) : null;
    vendor = json['vendor'];
    location = json['location'] != null
        ? new Location.fromJson(json['location'])
        : null;
    date = json['date'];
    time = json['time'];
    comments = json['comments'];
    visit = json['visit'];
    status = json['status'];
    createdAt = json['created_at'];
    if (json['images'] != null) {
      print('json[');
      images = new List();
      if (json['images'] is List)
        json['images'].forEach((v) {
          images.add(v['image']);
        });
    }
    if (json['answers'] != null) {
      answers = new List<Answers>();
      json['answers'].forEach((v) {
        answers.add(new Answers.fromJson(v));
      });
    }
    if (json['surveys'] != null) {
      surveys = new List<Surveys>();
      json['surveys'].forEach((v) {
        surveys.add(new Surveys.fromJson(v));
      });
    }
    accepted = json['accepted'];
    estimatedAmount = json['estimated_amount'];
    paidOrderAdvance = json['paid_order_advance'];
    advancePaid = json['advance_paid'];
    paidAmount = json['paid_amount'];
    amountToBePaid = json['amount_to_be_paid'];
    verified = json['verified'];
    canceled = json['canceled'];
    reason = json['reason'];
    reviewed = json['reviewed'];
    if (json['vendorqoutes'] != null) {
      vendorqoutes = new List<Vendorqoutes>();
      json['vendorqoutes'].forEach((v) {
        vendorqoutes.add(new Vendorqoutes.fromJson(v));
      });
    }
    if (json['milestones'] != null) {
      milestones = new List<Milestones>();
      json['milestones'].forEach((v) {
        milestones.add(new Milestones.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_no'] = this.orderNo;
    data['service'] = this.service;
    if (this.name != null) {
      data['name'] = this.name.toJson();
    }
    data['vendor'] = this.vendor;
    if (this.location != null) {
      data['location'] = this.location.toJson();
    }
    data['date'] = this.date;
    data['time'] = this.time;
    data['comments'] = this.comments;
    data['visit'] = this.visit;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    if (this.images != null) {
      data['images'] = this.images.map((v) => v).toList();
    }
    if (this.answers != null) {
      data['answers'] = this.answers.map((v) => v.toJson()).toList();
    }
    if (this.surveys != null) {
      data['surveys'] = this.surveys.map((v) => v.toJson()).toList();
    }
    data['accepted'] = this.accepted;
    data['estimated_amount'] = this.estimatedAmount;
    data['paid_order_advance'] = this.paidOrderAdvance;
    data['advance_paid'] = this.advancePaid;
    data['paid_amount'] = this.paidAmount;
    data['amount_to_be_paid'] = this.amountToBePaid;
    data['verified'] = this.verified;
    data['canceled'] = this.canceled;
    data['reason'] = this.reason;
    data['reviewed'] = this.reviewed;
    if (this.vendorqoutes != null) {
      data['vendorqoutes'] = this.vendorqoutes.map((v) => v.toJson()).toList();
    }
    if (this.milestones != null) {
      data['milestones'] = this.milestones.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Name {
  String english;
  String arabic;

  Name({this.english, this.arabic});

  Name.fromJson(Map<String, dynamic> json) {
    english = json['english'];
    arabic = json['arabic'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['english'] = this.english;
    data['arabic'] = this.arabic;
    return data;
  }
}

class Location {
  String addressAr;
  String addressEn;
  Cooridinates cooridinates;

  Location({this.addressAr, this.addressEn, this.cooridinates});

  Location.fromJson(Map<String, dynamic> json) {
    addressAr = json['address_ar'];
    addressEn = json['address_en'];
    cooridinates = json['cooridinates'] != null
        ? new Cooridinates.fromJson(json['cooridinates'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['address_ar'] = this.addressAr;
    data['address_en'] = this.addressEn;
    if (this.cooridinates != null) {
      data['cooridinates'] = this.cooridinates.toJson();
    }
    return data;
  }
}

class Cooridinates {
  double lat;
  double lng;

  Cooridinates({this.lat, this.lng});

  Cooridinates.fromJson(Map<String, dynamic> json) {
    lat = json['lat'];
    lng = json['lng'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    return data;
  }
}

class Answers {
  Question question;
  String answer;

  Answers({this.question, this.answer});

  Answers.fromJson(Map<String, dynamic> json) {
    question = json['question'] != null
        ? new Question.fromJson(json['question'])
        : null;
    answer = json['answer'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.question != null) {
      data['question'] = this.question.toJson();
    }
    data['answer'] = this.answer;
    return data;
  }
}

class Question {
  int id;
  String question;
  String questionAr;
  bool general;
  bool active;
  bool deleted;
  int service;
  var user;

  Question(
      {this.id,
      this.question,
      this.questionAr,
      this.general,
      this.active,
      this.deleted,
      this.service,
      this.user});

  Question.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    question = json['question'];
    questionAr = json['question_ar'];
    general = json['general'];
    active = json['active'];
    deleted = json['deleted'];
    service = json['service'];
    user = json['user'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['question'] = this.question;
    data['question_ar'] = this.questionAr;
    data['general'] = this.general;
    data['active'] = this.active;
    data['deleted'] = this.deleted;
    data['service'] = this.service;
    data['user'] = this.user;
    return data;
  }
}

class Surveys {
  Survey survey;
  Choice choice;

  Surveys({this.survey, this.choice});

  Surveys.fromJson(Map<String, dynamic> json) {
    survey =
        json['survey'] != null ? new Survey.fromJson(json['survey']) : null;
    choice =
        json['choice'] != null ? new Choice.fromJson(json['choice']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.survey != null) {
      data['survey'] = this.survey.toJson();
    }
    if (this.choice != null) {
      data['choice'] = this.choice.toJson();
    }
    return data;
  }
}

class Survey {
  int id;
  String question;
  String questionAr;
  bool active;
  bool deleted;
  int service;
  var user;

  Survey(
      {this.id,
      this.question,
      this.questionAr,
      this.active,
      this.deleted,
      this.service,
      this.user});

  Survey.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    question = json['question'];
    questionAr = json['question_ar'];
    active = json['active'];
    deleted = json['deleted'];
    service = json['service'];
    user = json['user'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['question'] = this.question;
    data['question_ar'] = this.questionAr;
    data['active'] = this.active;
    data['deleted'] = this.deleted;
    data['service'] = this.service;
    data['user'] = this.user;
    return data;
  }
}

class Choice {
  int id;
  String name;
  String nameAr;
  bool deleted;
  int survey;

  Choice({this.id, this.name, this.nameAr, this.deleted, this.survey});

  Choice.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    nameAr = json['name_ar'];
    deleted = json['deleted'];
    survey = json['survey'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['name_ar'] = this.nameAr;
    data['deleted'] = this.deleted;
    data['survey'] = this.survey;
    return data;
  }
}

class Vendorqoutes {
  int id;
  int vendor;
  int order;
  String amount;
  var schedule;
  var startingDate;
  String warranty;
  var warrantyDescription;
  bool isAdvance;
  String advancePercentage;
  String advanceAmount;
  bool advancePaid;
  bool accepted;
  bool rejected;
  bool verified;

  Vendorqoutes(
      {this.id,
      this.vendor,
      this.order,
      this.amount,
      this.schedule,
      this.startingDate,
      this.warranty,
      this.warrantyDescription,
      this.isAdvance,
      this.advancePercentage,
      this.advanceAmount,
      this.advancePaid,
      this.accepted,
      this.rejected,
      this.verified});

  Vendorqoutes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    vendor = json['vendor'];
    order = json['order'];
    amount = json['amount'];
    schedule = json['schedule'];
    startingDate = json['starting_date'];
    warranty = json['warranty'];
    warrantyDescription = json['warranty_description'];
    isAdvance = json['is_advance'];
    advancePercentage = json['advance_percentage'];
    advanceAmount = json['advance_amount'];
    advancePaid = json['advance_paid'];
    accepted = json['accepted'];
    rejected = json['rejected'];
    verified = json['verified'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['vendor'] = this.vendor;
    data['order'] = this.order;
    data['amount'] = this.amount;
    data['schedule'] = this.schedule;
    data['starting_date'] = this.startingDate;
    data['warranty'] = this.warranty;
    data['warranty_description'] = this.warrantyDescription;
    data['is_advance'] = this.isAdvance;
    data['advance_percentage'] = this.advancePercentage;
    data['advance_amount'] = this.advanceAmount;
    data['advance_paid'] = this.advancePaid;
    data['accepted'] = this.accepted;
    data['rejected'] = this.rejected;
    data['verified'] = this.verified;
    return data;
  }
}

class Milestones {
  String name;
  String status;
  bool piad;

  Milestones({this.name, this.status, this.piad});

  Milestones.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    status = json['status'];
    piad = json['piad'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['status'] = this.status;
    data['piad'] = this.piad;
    return data;
  }
}
