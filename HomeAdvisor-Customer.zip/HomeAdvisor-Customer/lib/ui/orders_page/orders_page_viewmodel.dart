import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoder/geocoder.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/orders_page/models/order_get_model.dart';
import 'package:home_advisor/ui/orders_page/models/orders_completed.dart'
    as completedOrder;
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart'
    as ongoingModel;
import 'package:stacked/stacked.dart';

class OrdersInfo {
  String seriel;
  String name;
  String date;
  String time;
  String location;
  final String status;
  final String paymentStatus;
  OrdersInfo({
    this.time,
    this.date,
    this.name,
    this.location,
    this.seriel,
    this.paymentStatus,
    this.status,
  });
}

class OrdersPageViewModel extends BaseViewModel {
  String logo = "lib/images/logo/logo.png";
  UserService _userService = locator<UserService>();

  String _token;
  String address;
  List<Results> _orderRequested = [];
  List<completedOrder.Results> _ordersCompleted = [];

  bool _isLoading = false;
  bool _isLoadingRequested = false;
  bool _reviewButtonLoading = false;

  TabController tabController;
  bool get isLoadingRequested => _isLoadingRequested;
  bool get isLoading => _isLoading;
  bool get reviewButtonLoading => _reviewButtonLoading;

  List<completedOrder.Results> get ordersCompleted => _ordersCompleted;
  List<Results> get listOfOrders => _orderRequested;

  void initState(TickerProvider vsync, LanguageService lang) {
    ValueNotifier<int> FCMPayload = ValueNotifier<int>(lang.payLoad);

    ValueListenableBuilder(
      valueListenable: FCMPayload,
      builder: (context, value, child) {
        getOrders();
        return Text('');
      },
    );
    getOrders();
  }

  set reviewButtonLoading(bool loading) {
    _reviewButtonLoading = loading;
    notifyListeners();
  }

  set isLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  set ordersCompleted(List<completedOrder.Results> orders) {
    _ordersCompleted = orders;
    notifyListeners();
  }

  set ordersRequested(List<Results> orders) {
    _orderRequested = orders;
    notifyListeners();
  }

  Future postReviewAndRate(
    String review,
    double rating,
    int orderId,
  ) async {
    bool status = await APIServices.postRating(
      _userService.token,
      orderId: orderId,
      rating: rating,
      review: review,
    );
    if (status) {
      Fluttertoast.showToast(msg: "Successfully rated your review");
    } else {
      Fluttertoast.showToast(msg: "Something went wrong");
    }
  }

  Future getWarrantyTerms(
    int orderId,
  ) async {
    return await APIServices.getWarrantyTerms(
      _userService.token,
      orderId: orderId,
    );
  }

  Future<void> getOrders() async {
    ordersRequested = [];
    isLoading = true;
    OrderGetModel orderModel = await APIServices.getOrder(
      _userService.token,
      param: "INITIATED",
    );
    if (orderModel != null) {
      if (orderModel.results.isNotEmpty) {
        List<Results> newModel = await getLoc(orderModel);
        ordersRequested = newModel;
        isLoading = false;
      } else {
        ordersRequested = [];
        isLoading = false;
      }
    } else {
      ordersRequested = [];
      isLoading = false;
    }
  }

  Future<List<ongoingModel.Results>> getOngoingOrders() async {
    List<ongoingModel.Results> ongoingOrders = [];
    ongoingModel.OngoingOrder order = await APIServices.getOrder(
      _userService.token,
      param: "IN-PROGRESS",
    );
    if (order != null) {
      if (order.results.isNotEmpty) {
        ongoingOrders = order.results;
      } else {
        ongoingOrders = [];
      }
    } else {
      ongoingOrders = [];
    }
    return ongoingOrders;
  }

  Future<List<completedOrder.Results>> getCompletedOrders() async {
    List<completedOrder.Results> ordersCompleted = [];
    completedOrder.CompletedOrder order = await APIServices.getOrder(
      _userService.token,
      param: "COMPLETED",
    );
    if (order != null) {
      if (order.results.isNotEmpty) {
        ordersCompleted = order.results;
      } else {
        ordersCompleted = [];
      }
    } else {
      ordersCompleted = [];
    }
    return ordersCompleted;
  }

  Future getLoc(OrderGetModel orderModel) async {
    int index = 0;
    // for (Results result in orderModel.results) {
    //   String location = '';
    //   if (result.location?.cooridinates?.lat != null)
    //     location = await getLocation(
    //       result.location.cooridinates.lat,
    //       result.location.cooridinates.lng,
    //     );
    //   orderModel.results[index].locationString = location;
    //   index++;
    // }
    return orderModel.results;
  }

  Future cancelOrder(bool isCanceled, int orderId, BuildContext context) async {
    if (isCanceled) {
      isLoading = true;
      bool response = await APIServices.deleteOrder(_token, orderId);
      if (response) {
        Fluttertoast.showToast(msg: "order successfully canceled");
        await getOrders();
        isLoading = false;
      } else {
        Fluttertoast.showToast(msg: "Failed, Please try again");
        isLoading = false;
      }
    }
  }

  Future<String> getLocation(double lat, double long) async {
    print('lat nad long $lat $long');
    final coordinates = new Coordinates(lat, long);
    var addresses = await Geocoder.local.findAddressesFromCoordinates(
      coordinates,
    );
    var first = addresses.first;
    return ("${first.featureName} : ${first.addressLine}");
  }

  String getToken() {
    _token = _userService.token;
  }

  Future reportAnIssue(String issue, int orderId) async {
    bool status = await APIServices.ReportIssue(
      issue,
      orderId,
      _token,
    );
    if (status) {
      Fluttertoast.showToast(msg: "Successfully submitted your issue");
    } else {
      Fluttertoast.showToast(msg: "Something went wrong please try again");
    }
  }
}
