import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

Alert confirmQuote(BuildContext context, Function confirm) {
  return Alert(
    context: context,
    title: "Confirm",
    style: AlertStyle(
      titleStyle:
          TextStyle(color: AppColor.blCommon, fontWeight: FontWeight.bold),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    desc: "Do you want confirm this request ?",
    buttons: [
      DialogButton(
        color: Colors.white,
        child: Text(
          "No",
          style: TextStyle(
              color: AppColor.rdCommon,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        width: 120,
      ),
      DialogButton(
        color: Colors.white,
        child: Text(
          "Yes",
          style: TextStyle(
              color: AppColor.blLight,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          confirm(true);
          Navigator.pop(context);
        },
        width: 120,
      ),
    ],
  );
}

Alert success(BuildContext context, String message) {
  return Alert(
    context: context,
    title: "Confirm",
    style: AlertStyle(
      titleStyle:
          TextStyle(color: AppColor.blCommon, fontWeight: FontWeight.bold),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    desc: "$message",
    buttons: [
      DialogButton(
        color: Colors.white,
        child: Text(
          "Ok",
          style: TextStyle(
              color: AppColor.rdCommon,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        width: 120,
      ),
    ],
  );
}

Alert cancelQuote(BuildContext context, Function cancel) {
  return Alert(
    context: context,
    title: "Confirm",
    style: AlertStyle(
      titleStyle:
          TextStyle(color: AppColor.blCommon, fontWeight: FontWeight.bold),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    desc: "Do you want confirm this request ?",
    buttons: [
      DialogButton(
        color: Colors.white,
        child: Text(
          "No",
          style: TextStyle(
              color: AppColor.rdCommon,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        width: 120,
      ),
      DialogButton(
        color: Colors.white,
        child: Text(
          "Yes",
          style: TextStyle(
              color: AppColor.blLight,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
          cancelQuoteReason(context, cancel).show();
        },
        width: 120,
      ),
    ],
  );
}

Alert cancelQuoteReason(BuildContext context, Function cancel) {
  String reason;
  return Alert(
    context: context,
    title: "Submit Your Reason for Cancel",
    style: AlertStyle(
      titleStyle: TextStyle(
          color: AppColor.blCommon, fontWeight: FontWeight.bold, fontSize: 20),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    content: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          onChanged: (value) {
            reason = value;
          },
          maxLines: 5,
          decoration: InputDecoration(
            alignLabelWithHint: true,
            hintText: "Enter your reason",
            hintStyle: AppTextStyles.textStyle(size: 25),
            border: OutlineInputBorder(
              borderSide: BorderSide(width: 2.0),
            ),
          ),
        )
      ],
    ),
    buttons: [
      DialogButton(
        gradient: LinearGradient(
          colors: [
            AppColor.rdGradient2,
            AppColor.rdGradient1,
          ],
        ),
        child: Text("SUBMIT",
            style: AppTextStyles.textStyle(
                color: Colors.white, fontType: FontType.regular)),
        onPressed: () {
          if (reason.isEmpty) {
            Fluttertoast.showToast(msg: "Enter a valid reason");
            return;
          }
          cancel(reason, true);
          Navigator.pop(context);
        },
        width: 120,
      ),
    ],
  );
}

Alert rejectQuoteReason(BuildContext context, Function reject) {
  String reason = '';
  return Alert(
    context: context,
    title: "Submit Your Reason for Rejection",
    style: AlertStyle(
      titleStyle: TextStyle(
          color: AppColor.blCommon, fontWeight: FontWeight.bold, fontSize: 20),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    content: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          onChanged: (value) {
            reason = value;
          },
          maxLines: 5,
          decoration: InputDecoration(
            alignLabelWithHint: true,
            hintText: "Enter your reason",
            hintStyle: AppTextStyles.textStyle(size: 25),
            border: OutlineInputBorder(
              borderSide: BorderSide(width: 2.0),
            ),
          ),
        )
      ],
    ),
    buttons: [
      DialogButton(
        gradient: LinearGradient(
          colors: [
            AppColor.rdGradient2,
            AppColor.rdGradient1,
          ],
        ),
        child: Text("SUBMIT",
            style: AppTextStyles.textStyle(
                color: Colors.white, fontType: FontType.regular)),
        onPressed: () {
          if (reason.isEmpty) {
            Fluttertoast.showToast(msg: "Enter a valid reason");
            return;
          }
          reject(reason);
          Navigator.pop(context);
        },
        width: 120,
      ),
    ],
  );
}
