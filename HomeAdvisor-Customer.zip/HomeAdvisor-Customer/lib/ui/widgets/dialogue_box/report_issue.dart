import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:fluttertoast/fluttertoast.dart';

Alert reportIssue(BuildContext context, Function handleReport) {
  String issue;
  return Alert(
    context: context,
    title: "Report an issue on order",
    style: AlertStyle(
      titleStyle: TextStyle(
          color: AppColor.blCommon, fontWeight: FontWeight.bold, fontSize: 20),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    content: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 20, bottom: 15, left: 8),
          child: Text(
            "Enter your issue facing from the vendor side, We will review and take necessary steps to find a better solution",
            style: AppTextStyles.s1(Colors.black),
          ),
        ),
        TextField(
          onChanged: (value) {
            issue = value;
          },
          maxLines: 5,
          decoration: InputDecoration(
              alignLabelWithHint: true,
              hintText: "Enter your reason",
              hintStyle: AppTextStyles.textStyle(size: 25.f),
              border: OutlineInputBorder(
                borderSide: BorderSide(width: 2.0),
              )),
        )
      ],
    ),
    buttons: [
      DialogButton(
        gradient: LinearGradient(
          colors: [
            AppColor.rdGradient2,
            AppColor.rdGradient1,
          ],
        ),
        child: Text("SUBMIT",
            style: AppTextStyles.textStyle(
                color: Colors.white, fontType: FontType.regular)),
        onPressed: () async {
          if (issue != null) {
            await handleReport(issue);
          } else {
            Fluttertoast.showToast(msg: "Please fill all fields");
          }
        },
        width: 120,
      ),
    ],
  );
}
