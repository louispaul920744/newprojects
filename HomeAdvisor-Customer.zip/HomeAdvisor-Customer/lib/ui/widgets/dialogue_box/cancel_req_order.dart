import 'package:flutter/material.dart';
import 'package:grouped_buttons/grouped_buttons.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';

Alert cancelReqOrderReason(BuildContext context) {
  return Alert(
    context: context,
    title: "Submit Your Reason for Cancel",
    style: AlertStyle(
      titleStyle: TextStyle(
          color: AppColor.blCommon, fontWeight: FontWeight.bold, fontSize: 20),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    content: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CheckboxGroup(
            checkColor: Colors.grey,
            activeColor: Colors.grey[100],
            margin: EdgeInsets.all(1),
            labelStyle: AppTextStyles.textStyle(size: 25.f),
            labels: <String>[
              "Wrong Work or Option",
              "Change of Work Description",
              "Others",
            ],
            onSelected: (List<String> checked) => print(checked.toString())),
        TextField(
          maxLines: 5,
          decoration: InputDecoration(
              alignLabelWithHint: true,
              hintText: "Enter your reason",
              hintStyle: AppTextStyles.textStyle(size: 25.f),
              border: OutlineInputBorder(
                borderSide: BorderSide(width: 2.0),
              )),
        )
      ],
    ),
    buttons: [
      DialogButton(
        gradient: LinearGradient(
          colors: [
            AppColor.rdGradient2,
            AppColor.rdGradient1,
          ],
        ),
        child: Text("SUBMIT",
            style: AppTextStyles.textStyle(
                color: Colors.white, fontType: FontType.regular)),
        onPressed: () => Navigator.pop(context),
        width: 120,
      ),
    ],
  );
}

Alert cancelOrderReqConfirmation(
    BuildContext context, Function handleCancelOrder) {
  return Alert(
    context: context,
    title: "Confirm",
    style: AlertStyle(
      titleStyle:
          TextStyle(color: AppColor.blCommon, fontWeight: FontWeight.bold),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    desc: "Are you sure you want cancel this request ?",
    buttons: [
      DialogButton(
        color: Colors.white,
        child: Text(
          "No",
          style: TextStyle(
              color: AppColor.rdCommon,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        width: 120,
      ),
      DialogButton(
        color: Colors.white,
        child: Text(
          "Yes",
          style: TextStyle(
              color: AppColor.blLight,
              fontSize: 15,
              fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pop(context);
          handleCancelOrder(true);
        },
        width: 120,
      ),
    ],
  );
}

