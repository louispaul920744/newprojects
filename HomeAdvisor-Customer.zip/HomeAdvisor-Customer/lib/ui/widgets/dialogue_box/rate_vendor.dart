import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

Alert rateVendor(BuildContext context, Function handleReview) {
  String review = '';
  double rating = 0.0;
  return Alert(
    context: context,
    title: "Rate the vendor",
    style: AlertStyle(
      titleStyle: TextStyle(
        color: AppColor.blCommon,
        fontWeight: FontWeight.bold,
        fontSize: 40.f,
      ),
      descStyle: TextStyle(fontSize: 15),
      alertPadding: EdgeInsets.all(0),
      animationType: AnimationType.grow,
      buttonAreaPadding: EdgeInsets.all(10),
      isCloseButton: false,
    ),
    content: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          "Please rate the vendor and tips offered",
          style: AppTextStyles.s1(Colors.black),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: SmoothStarRating(
              allowHalfRating: false,
              onRated: (v) {
                rating = v;
              },
              starCount: 5,
              rating: 0,
              size: 30.0.h,
              isReadOnly: false,
              color: Colors.orange,
              borderColor: Colors.orange,
              spacing: 0.0),
        ),
        TextField(
          onChanged: (value) {
            review = value;
          },
          maxLines: 5,
          decoration: InputDecoration(
            alignLabelWithHint: true,
            hintText: "Review and tip offered",
            hintStyle: AppTextStyles.textStyle(size: 25.f),
            border: OutlineInputBorder(
              borderSide: BorderSide(width: 2.0),
            ),
          ),
        )
      ],
    ),
    buttons: [
      DialogButton(
        gradient: LinearGradient(
          colors: [
            AppColor.rdGradient2,
            AppColor.rdGradient1,
          ],
        ),
        child: Text("SUBMIT",
            style: AppTextStyles.textStyle(
              color: Colors.white,
              fontType: FontType.regular,
              size: 28.f,
            )),
        onPressed: () async {
          if (review != '' && rating != 0.0) {
            await handleReview(
              review,
              rating,
            );
          } else {
            Fluttertoast.showToast(msg: "Please fill all fields");
          }
        },
        width: 120,
      ),
    ],
  );
}
