import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/style.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/notification_page/notification_page_model.dart';
import 'package:provider/provider.dart';

class NotificationCard extends StatelessWidget {
  final String noti;
  final String date;
  final String time;
  final String image;
  final Results model;

  NotificationCard({this.date, this.noti, this.time, this.image, this.model});

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    print(image);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Container(
          // height: 220.h,
          padding: EdgeInsets.only(left: 10, right: 10, top: 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  border: Border.all(color: Colors.red[300]),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        image == "defautl.png"
                            ? Image.asset(
                                "lib/images/logo/g1.png",
                                height: 80,
                                width: 80,
                              )
                            : CachedNetworkImage(
                                imageUrl: image,
                                height: 80,
                                width: 80,
                              ),
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.all(15),
                            color: Colors.red[300],
                            child: Column(
                              // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              // mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  noti,
                                  style: AppTextStyles.textStyle(
                                      color: Colors.white,
                                      size: 16,
                                      fontType: FontType.bold),
                                ),
                                Html(
                                    data: model.body,
                                    onLinkTap: (url) {
                                      print("Opening $url...");
                                    },
                                    style: {
                                      'body': Style(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w400)
                                    }),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Align(
                                      alignment: language.lang == 'en'
                                          ? Alignment.centerLeft
                                          : Alignment.centerRight,
                                      child: Directionality(
                                        textDirection: TextDirection.ltr,
                                        child: Text(
                                          date,
                                          style: AppTextStyles.textStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '',
                                      style: AppTextStyles.textStyle(
                                          color: Colors.white),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}
