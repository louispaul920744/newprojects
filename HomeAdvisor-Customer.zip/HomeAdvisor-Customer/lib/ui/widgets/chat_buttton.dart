import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/chat_model/resources/auth_methods.dart';
import 'package:home_advisor/chat_model/screens/chatscreens/chat_screen.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';

class ChatButton extends StatefulWidget {
  final model;

  ChatButton(this.model);
  @override
  _ChatButtonState createState() => _ChatButtonState();
}

class _ChatButtonState extends State<ChatButton> {
  AuthMethods authMethods = AuthMethods();

  bool loading = false;
  @override
  Widget build(BuildContext context) {
    final Results model = widget.model;

    return loading
        ? Container(
            width: 24,
            height: 24,
            padding: EdgeInsets.all(4),
            child: CircularProgressIndicator(),
          )
        : InkWell(
            splashColor: Colors.white60,
            onTap: () {
              setState(() {
                loading = true;
              });
              authMethods.requestChat(model).then((vendor) {
                setState(() {
                  loading = false;
                });
                if (vendor != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatScreen(
                          chatId: model.chat_id, vendor: vendor, model: model),
                    ),
                  );
                } else
                  Fluttertoast.showToast(msg: 'Cant initiate chat right now');
                print('value.toMap(value)');
              }).catchError((e) {
                setState(() {
                  loading = false;
                });
                print('ssss $e');
              });
            },
            child: Container(
              height: 32,
              width: 32,
              decoration: BoxDecoration(
                  color: Colors.black38,
                  borderRadius: BorderRadius.circular(8)),
              child: Icon(
                Icons.message_rounded,
                color: Colors.white,
              ),
            ),
          );
  }
}
