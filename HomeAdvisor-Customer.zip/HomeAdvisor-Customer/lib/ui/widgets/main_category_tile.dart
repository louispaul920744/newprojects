import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/ui/sub_category/sub_categ_view.dart';

class MainCategoryTile extends StatelessWidget {
  final String name;
  final String address;

  final String title;
  final int categId;
  final ValueChanged<String> onSelected;

  MainCategoryTile(
      {this.name, this.address, this.title, this.categId, this.onSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(
        horizontal: 10.0,
        vertical: 4.0,
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey,

          width: 1, //                   <--- border width here
        ),
      ),
      child: GestureDetector(
        onTap: () {
          if (onSelected == null)
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => SubCategView(
                  categId: categId,
                  title: title,
                ),
              ),
            );
          else
            onSelected(categId.toString());
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100.w,
              margin: const EdgeInsets.only(
                top: 8.0,
              ),
              alignment: Alignment.center,
              child: CachedNetworkImage(
                fit: BoxFit.fill,
                progressIndicatorBuilder: (context, url, progress) =>
                    CircularProgressIndicator(),
                imageUrl: address,
              ),
            ),
            Text(name,
                style: TextStyle(
                    color: Color(0xFF213482),
                    fontSize: 25.f,
                    fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}
