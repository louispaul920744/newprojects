import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/orders_page/orders_page_viewmodel.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_model.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_view.dart';
import 'package:home_advisor/ui/widgets/dialogue_box/cancel_req_order.dart';
import 'package:provider/provider.dart';

class OrdersCard extends StatelessWidget {
  final String seriel;
  final String name;
  final String date;
  final String time;
  final String location;
  String id;
  Function handleCancelOrder;
  OrdersPageViewModel model;
  OrdersCard({
    this.handleCancelOrder,
    this.seriel,
    this.location,
    this.name,
    this.date,
    this.time,
    this.id,
    this.model,
  });

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Container(
        height: 350.h,
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey, width: 0.5),
            borderRadius: BorderRadius.circular(5)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                id,
                style: AppTextStyles.textStyle(
                    color: AppColor.blCommon, size: 28.f),
              ),
              Text(
                name,
                style: AppTextStyles.textStyle(size: 28.f),
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Date : " : "تاريخ : ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Text(
                    Helper.formatDate(date),
                    style: AppTextStyles.textStyle(size: 28.f),
                  )
                ],
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Time :" : "زمن : ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        time,
                        style: AppTextStyles.textStyle(size: 28.f),
                      ),
                    ),
                  )
                ],
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Location : " : "موقعك :  ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Expanded(
                    child: Text(
                      location ?? '',
                      style: AppTextStyles.textStyle(size: 28.f),
                      softWrap: true,
                    ),
                  )
                ],
              ),
              Divider(
                thickness: 0.5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      cancelOrderReqConfirmation(context, handleCancelOrder)
                          .show();
                    },
                    child: Text(
                      language.lang == 'en' ? "Cancel" : "إلغاء",
                      style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                          size: 26.f),
                    ),
                  ),
                  InkWell(
                    onTap: () async {
                      await Navigator.pushNamed(
                        context,
                        VendorsPage.id,
                        arguments: VendorQuoteDetails(
                          date: date,
                          location: location,
                          orderId: seriel,
                          showingID: id,
                          time: time,
                          type: name,
                        ),
                      );
                      model.getOrders();
                    },
                    child: Text(
                      language.lang == 'en' ? "View vendors" : "عرض البائعين",
                      style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                          size: 26.f),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
