import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/orders_page/models/orders_completed.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart'
    as R;
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../chat_buttton.dart';

class OrdersCompCard extends StatelessWidget {
  bool isReviewLoading;

  final String seriel;
  final String name;
  final String date;
  final String time;
  final String location;
  final String id;
  final bool isRated;
  final Results model;
  Function handleReviewAndRating;
  Function handleWarranty;

  OrdersCompCard({
    this.isReviewLoading,
    this.seriel,
    this.location,
    this.name,
    this.date,
    this.time,
    this.handleReviewAndRating,
    this.handleWarranty,
    this.isRated,
    this.id,
    this.model,
  });

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Container(
        height: 350.h,
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey, width: 0.5),
            borderRadius: BorderRadius.circular(5)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                id ?? 'N/A',
                style: AppTextStyles.textStyle(
                    color: AppColor.blCommon, size: 28.f),
              ),
              Text(
                name ?? 'N/A',
                style: AppTextStyles.textStyle(size: 28.f),
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Date : " : "تاريخ : ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        Helper.formatDate(date) ?? 'N/A',
                        style: AppTextStyles.textStyle(size: 28.f),
                      ),
                    ),
                  )
                ],
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Time :" : "زمن : ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        time ?? 'N/A',
                        style: AppTextStyles.textStyle(size: 28.f),
                      ),
                    ),
                  )
                ],
              ),
              Row(
                children: [
                  Text(
                    language.lang == 'en' ? "Location :" : "موقعك : ",
                    style: AppTextStyles.textStyle(
                        fontType: FontType.bold, size: 28.f),
                  ),
                  Expanded(
                    child: Text(
                      location ?? 'N/A',
                      style: AppTextStyles.textStyle(size: 28.f),
                    ),
                  )
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Divider(
                      thickness: 0.5,
                    ),
                  ),
                  if (model.in_warranty && model.chat_id != null)
                    Container(
                        margin: EdgeInsets.only(left: 4),
                        child: ChatButton(R.Results.fromJson(model.toJson()))),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      handleWarranty();
                    },
                    child: Text(
                      language.lang == 'en' ? "Warranty Terms" : "شروط الكفالة",
                      style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                          size: 26.f),
                    ),
                  ),
                  if (!isRated)
                    InkWell(
                      onTap: () {
                        String review = '';
                        double rating = 0.0;
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: Text("Rate the vendor",
                                  style: TextStyle(
                                    color: AppColor.blCommon,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 40.f,
                                  )),
                              content: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    "Please rate the vendor and tips offered",
                                    style: AppTextStyles.s1(Colors.black),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10),
                                    child: SmoothStarRating(
                                        allowHalfRating: true,
                                        onRated: (v) {
                                          rating = v;
                                        },
                                        starCount: 5,
                                        rating: 0,
                                        size: 30.0.h,
                                        isReadOnly: false,
                                        color: Colors.orange,
                                        borderColor: Colors.orange,
                                        spacing: 0.0),
                                  ),
                                  TextField(
                                    onChanged: (value) {
                                      review = value;
                                    },
                                    maxLines: 5,
                                    decoration: InputDecoration(
                                      alignLabelWithHint: true,
                                      hintText: "Review and tip offered",
                                      hintStyle:
                                          AppTextStyles.textStyle(size: 25.f),
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(width: 2.0),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // width: 240,
                                    alignment: Alignment.center,
                                    child: DialogButton(
                                      gradient: LinearGradient(
                                        colors: [
                                          AppColor.rdGradient2,
                                          AppColor.rdGradient1,
                                        ],
                                      ),
                                      child: Text("SUBMIT",
                                          style: AppTextStyles.textStyle(
                                            color: Colors.white,
                                            fontType: FontType.regular,
                                            size: 28.f,
                                          )),
                                      onPressed: () async {
                                        if (review != '' && rating != 0.0) {
                                          await handleReviewAndRating(
                                            review,
                                            rating,
                                          );
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop(true);
                                        } else {
                                          Fluttertoast.showToast(
                                              msg: "Please fill all fields");
                                        }
                                      },
                                      width: 120,
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                        );
                      },
                      child: Text(
                        language.lang == 'en'
                            ? "Review and Rate"
                            : "مراجعة وتقييم",
                        style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                          size: 26.f,
                        ),
                      ),
                    )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
