import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/chat_model/resources/auth_methods.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';
import 'package:home_advisor/ui/pay_milestone/pay_milestone_view.dart';
import 'package:home_advisor/ui/widgets/dialogue_box/cancel_ongoing_order.dart';
import 'package:home_advisor/ui/widgets/dialogue_box/report_issue.dart';
import 'package:provider/provider.dart';

import '../chat_buttton.dart';

class OrdersOnGCard extends StatelessWidget {
  BuildContext pageContext;
  bool isReady;
  final String seriel;
  String vendor;
  final String name;
  final String date;
  final String time;
  final String location;
  final String status;
  final String paymentStatus;
  final String id;
  final Results model;
  final Function handleReport;

  OrdersOnGCard({
    this.pageContext,
    this.seriel,
    this.vendor,
    this.location,
    this.name,
    this.date,
    this.time,
    this.status,
    this.paymentStatus,
    this.handleReport,
    this.id,
    this.model,
  }) {
    if (status == "IN-PROGRESS") {
      isReady = false;
    } else {
      isReady = true;
    }
  }

  AuthMethods authMethods = AuthMethods();

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    print('model');
    print(model.toJson());
    print(model.in_warranty.toString());
    print(model.chat_id);
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Container(
        height: 350.h,
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey, width: 0.5),
            borderRadius: BorderRadius.circular(5)),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        id,
                        style: AppTextStyles.textStyle(
                            color: AppColor.blCommon, size: 28.f),
                      ),
                      Text(
                        status,
                        style: AppTextStyles.textStyle(
                            fontType: FontType.bold,
                            color: AppColor.blCommon,
                            size: 28.f),
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        name,
                        style: AppTextStyles.textStyle(size: 28.f),
                      ),
                      Text(
                        '',
                        // paymentStatus,
                        style: AppTextStyles.textStyle(size: 23.f),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        language.lang == 'en' ? "Date : " : "تاريخ",
                        style: AppTextStyles.textStyle(
                            fontType: FontType.bold, size: 28.f),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text(
                            Helper.formatDate(date),
                            style: AppTextStyles.textStyle(size: 28.f),
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        language.lang == 'en' ? "Time :" : "زمن",
                        style: AppTextStyles.textStyle(
                            fontType: FontType.bold, size: 28.f),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text(
                            time,
                            style: AppTextStyles.textStyle(size: 28.f),
                          ),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        language.lang == 'en' ? "Location :" : "موقعك",
                        style: AppTextStyles.textStyle(
                            fontType: FontType.bold, size: 28.f),
                      ),
                      Expanded(
                        child: Text(
                          location ?? '',
                          style: AppTextStyles.textStyle(size: 28.f),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: Divider(
                          thickness: 0.5,
                        ),
                      ),
                      if (model.in_warranty && model.chat_id != null)
                        Container(
                            margin: EdgeInsets.only(left: 4),
                            child: ChatButton(model)),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PayMilestonePage(
                                date: date,
                                location: location,
                                orderId: seriel,
                                orderIdShown: id,
                                time: time,
                                vendor: vendor,
                                name: name,
                                price: model.estimatedAmount,
                              ),
                            ),
                          );
                          // Navigator.pushNamed(context, PayMilestonePage.id, ar);
                        },
                        child: Text(
                          language.lang == 'en'
                              ? "View Pay Milestones"
                              : "عرض مراحل الدفع",
                          style: AppTextStyles.textStyle(
                              color: AppColor.blCommon,
                              fontType: FontType.bold,
                              size: 26.f),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          isReady
                              ? cancelOrderOnGConfirmation(context).show()
                              : reportIssue(context, handleReport).show();
                        },
                        child: Text(
                          isReady
                              ? language.lang == 'en'
                                  ? "Cancel"
                                  : "إلغاء"
                              : language.lang == 'en'
                                  ? "Report an Issue"
                                  : "بلغ عن خطأ",
                          style: AppTextStyles.textStyle(
                              color: AppColor.blCommon,
                              fontType: FontType.bold,
                              size: 26.f),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
