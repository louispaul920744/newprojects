import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:provider/provider.dart';

class SummaryCard extends StatelessWidget {
  final String category;
  final String date;
  final String time;
  final String location;

  SummaryCard({Key key, this.date, this.time, this.category, this.location})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return Container(
      decoration: BoxDecoration(
        border: Border(
          left: BorderSide(
            color: Color(0xff65BDF7),
            width: 5.0,
          ),
          right: BorderSide(
            color: Color(0xffC6C6C6),
          ),
          top: BorderSide(
            color: Color(0xffC6C6C6),
          ),
          bottom: BorderSide(
            color: Color(0xffC6C6C6),
          ),
        ),
        // borderRadius: BorderRadius.only(topRight: Radius.circular(55),bottomRight: Radius.circular(55))
      ),
      padding: EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            category,
            style: AppTextStyles.textStyle(
                size: 20, fontType: FontType.bold, color: AppColor.blCommon),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Text(
                language.lang == 'en' ? 'Date  : ' : 'تاريخ : ',
                style: AppTextStyles.textStyle(
                    size: 20,
                    fontType: FontType.bold,
                    color: AppColor.blCommon),
              ),
              Text(
                Helper.formatDate(date),
                style:
                    AppTextStyles.textStyle(size: 20, color: AppColor.blCommon),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Text(
                language.lang == 'en' ? 'Time  : ' : 'زمن : ',
                style: AppTextStyles.textStyle(
                    size: 20,
                    fontType: FontType.bold,
                    color: AppColor.blCommon),
              ),
              Text(
                time.toString(),
                style:
                    AppTextStyles.textStyle(size: 20, color: AppColor.blCommon),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                language.lang == 'en' ? 'Location  : ' : "موقعك : ",
                style: AppTextStyles.textStyle(
                    size: 20,
                    fontType: FontType.bold,
                    color: AppColor.blCommon),
              ),
              Expanded(
                child: Text(
                  location,
                  style: AppTextStyles.textStyle(
                      size: 20, color: AppColor.blCommon),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
