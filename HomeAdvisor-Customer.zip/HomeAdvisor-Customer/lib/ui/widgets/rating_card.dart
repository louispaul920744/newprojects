import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:flutter_screenutil/size_extension.dart';

class RatingCard extends StatelessWidget {
  final String name;
  final String review;
  final double rating;

  RatingCard({this.name, this.review, this.rating});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        padding: EdgeInsets.all(10),
        decoration:
            BoxDecoration(border: Border.all(width: 0.2, color: Colors.grey)),
        child: Column(
          children: [
            Row(
              children: [
                Icon(
                  Icons.account_circle,
                  color: AppColor.blCommon,
                  size: 35,
                ),
                Column(
                  children: [
                    Text(
                      name,
                      style: AppTextStyles.textStyle(color: AppColor.blCommon),
                    ),
                    SmoothStarRating(
                        allowHalfRating: false,
                        onRated: (v) {},
                        starCount: 5,
                        rating: rating,
                        size: 20.0.h,
                        isReadOnly: true,
                        color: Colors.orange,
                        borderColor: Colors.orange,
                        spacing: 0.0)
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Text(review),
          ],
        ),
      ),
    );
  }
}
