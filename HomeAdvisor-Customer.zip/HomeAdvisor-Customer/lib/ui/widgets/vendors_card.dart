import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/vendor_details_page/vendor_details_page_view.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_model.dart';
import 'package:home_advisor/ui/widgets/dialogue_box/quotes.dart';

class VendorsCard extends StatefulWidget {
  final String name;
  final String amount;
  final String quote;
  final String profileUrl;
  final int quoteId;
  final String duration;
  final Results model;
  final String warranty;
  Function handleConfirm;
  Function handleReject;
  Function handlePay;

  VendorsCard({
    this.name,
    this.amount,
    this.quote,
    this.quoteId,
    this.profileUrl,
    this.handleConfirm,
    this.duration,
    this.warranty,
    this.model,
    this.handlePay,
    this.handleReject,
  });

  @override
  _VendorsCardState createState() => _VendorsCardState();
}

class _VendorsCardState extends State<VendorsCard> {
  int viewQuoteFlag = 0;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        padding: EdgeInsets.all(10),
        decoration:
            BoxDecoration(border: Border.all(width: 0.2, color: Colors.grey)),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      VendorDetailsPageView.id,
                    );
                  },
                  child: Row(
                    children: [
                      Container(
                        height: 85,
                        width: 85,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: widget.profileUrl == null
                                  ? AssetImage("lib/images/logo/g1.png")
                                  : CachedNetworkImageProvider(
                                      widget.profileUrl,
                                    ),
                              fit: BoxFit.fill),
                        ),
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(
                        widget.name,
                        style:
                            AppTextStyles.textStyle(color: AppColor.blCommon),
                      ),
                    ],
                  ),
                ),
                Text(
                  "QAR ${widget.amount}",
                  style: AppTextStyles.textStyle(color: AppColor.blCommon),
                )
              ],
            ),
            SizedBox(
              height: 15,
            ),
            // Text(quote),
            SizedBox(
              height: 15,
            ),
            Row(
              children: [
                Text(
                  "Duration :-   ${widget.duration}",
                  textAlign: TextAlign.start,
                  style: AppTextStyles.textStyle(
                    color: AppColor.blCommon,
                    fontType: FontType.bold,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                Text(
                  "Warranty :- ${widget.warranty}",
                  textAlign: TextAlign.start,
                  style: AppTextStyles.textStyle(
                    color: AppColor.blCommon,
                    fontType: FontType.bold,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Divider(
              thickness: 0.6,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (!widget.model.vendor_agree && !widget.model.accepted)
                    GestureDetector(
                      onTap: () {
                        rejectQuoteReason(context, widget.handleReject).show();
                      },
                      child: Text(
                        "Reject",
                        style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                        ),
                      ),
                    ),
                  if (!widget.model.vendor_agree)
                    GestureDetector(
                      onTap: widget.model.accepted
                          ? null
                          : () {
                              confirmQuote(context, (status) {
                                if (status) {
                                  widget.handleConfirm(status);
                                }
                              }).show();
                            },
                      child: Text(
                        widget.model.accepted
                            ? "Awaiting vendor confirmation"
                            : "Confirm",
                        style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                        ),
                      ),
                    ),
                  if (widget.model.is_advance && widget.model.vendor_agree)
                    GestureDetector(
                      onTap: () {
                        widget.handlePay();
                      },
                      child: Text(
                        "Pay QAR ${widget.model.advanceAmount} ",
                        style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
