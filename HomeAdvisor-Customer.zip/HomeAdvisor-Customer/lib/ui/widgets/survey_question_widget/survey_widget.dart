import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/survey_page/survey_page_model.dart';
import 'package:home_advisor/ui/widgets/survey_question_widget/survey_widget_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:provider/provider.dart';

class SurveyWidget extends StatelessWidget {
  final Function getChoice;
  final String question;
  final List<Options> options;
  const SurveyWidget({
    this.options,
    this.question,
    @required this.getChoice,
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<QuestionWidgetViewModel>.reactive(
      builder: (context, model, child) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(6),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.10),
                  offset: Offset(0, 4),
                  blurRadius: 10,
                )
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.query_builder),
                      SizedBox(
                        width: 15.0,
                      ),
                      Expanded(
                        child: Text(
                          question,
                          style: AppTextStyles.textStyle(
                            fontType: FontType.bold,
                            color: AppColor.blCommon,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List<Widget>.generate(options.length, (index) {
                      return Row(
                        children: [
                          Radio(
                            value: index,
                            groupValue: model.getChoice,
                            onChanged: (int choice) {
                              model.setChoice = choice;
                              getChoice(choice, options[index].id);
                            },
                          ),
                          Text(
                            language.lang == 'en'
                                ? options[index].name
                                : options[index].name_ar,
                            style: AppTextStyles.textStyle(
                              fontType: FontType.regular,
                              color: AppColor.blCommon,
                              size: 14,
                            ),
                          )
                        ],
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => QuestionWidgetViewModel(),
    );
  }
}
