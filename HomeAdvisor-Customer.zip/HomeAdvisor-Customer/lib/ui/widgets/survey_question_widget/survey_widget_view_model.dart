import 'package:stacked/stacked.dart';

class QuestionWidgetViewModel extends BaseViewModel {
  int _choice = -1;
  int get getChoice => _choice;

  set setChoice(int choice) {
    _choice = choice;
    notifyListeners();
  }
}
