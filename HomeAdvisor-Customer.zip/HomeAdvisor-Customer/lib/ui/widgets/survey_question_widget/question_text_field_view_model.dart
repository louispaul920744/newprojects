import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class QueestionTextFieldViewModel extends BaseViewModel {
  TextEditingController controller = new TextEditingController();
  final String question;
  QueestionTextFieldViewModel({this.question});
}
