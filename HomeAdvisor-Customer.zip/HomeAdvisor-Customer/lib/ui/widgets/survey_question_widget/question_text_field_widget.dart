import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/widgets/survey_question_widget/question_text_field_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:provider/provider.dart';

class QuestionTextFieldWidget extends StatelessWidget {
  final String question;
  final Function onChanged;
  final formKey;
  QuestionTextFieldWidget({
    this.formKey,
    this.onChanged,
    this.question,
  });

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<QueestionTextFieldViewModel>.reactive(
      builder: (context, model, child) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(6),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.10),
                  offset: Offset(0, 4),
                  blurRadius: 10,
                )
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 8.0,
                vertical: 20.0,
              ),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.query_builder),
                      SizedBox(
                        width: 20.0,
                      ),
                      Expanded(
                        child: Text(
                          model.question,
                          style: AppTextStyles.textStyle(
                            fontType: FontType.bold,
                            color: AppColor.blCommon,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      Expanded(
                        child: TextFormField(
                          validator: (answer) {
                            if (answer.isEmpty) {
                              return language.lang == 'en'
                                  ? "Please fill the field"
                                  : "يرجى ملء الحقل";
                            } else
                              return null;
                          },
                          decoration:
                              InputDecoration(border: OutlineInputBorder()),
                          onChanged: (v) {
                            onChanged(v);
                          },
                          controller: model.controller,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => QueestionTextFieldViewModel(question: question),
    );
  }
}
