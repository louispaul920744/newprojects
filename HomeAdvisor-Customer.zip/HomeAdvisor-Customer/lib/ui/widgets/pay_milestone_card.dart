import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/pay_milestone/pay_milestone_model.dart';

class PayMileStoneCard extends StatelessWidget {
  final String name;
  final String date;
  final String status;
  final String price;
  final Milestone requested;
  final Function pay;
  bool paid;

  PayMileStoneCard({
    this.name,
    this.date,
    this.price,
    this.status,
    this.paid,
    this.requested,
    this.pay,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey, width: 0.2),
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: AppTextStyles.textStyle(
                color: AppColor.blCommon,
                size: 28.f,
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Text(requested.description ?? 'Description not available',
                style: AppTextStyles.textStyle(
                  color: AppColor.blCommon,
                  size: 24.f,
                )),
            SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "$price QAR",
                  style: AppTextStyles.textStyle(
                    color: AppColor.blCommon,
                    size: 28.f,
                  ),
                ),
                Text(
                  Helper.formatDate(date),
                  style: AppTextStyles.textStyle(
                    color: AppColor.blCommon,
                    size: 28.f,
                  ),
                ),
                paid == true
                    ? Container(
                        padding: const EdgeInsets.only(right: 25),
                        child: Text(
                          'Paid',
                          style: AppTextStyles.textStyle(
                            color: AppColor.blCommon,
                            size: 28.f,
                          ),
                        ),
                      )
                    : requested.requested
                        ? Container(
                            height: 35,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              gradient: LinearGradient(
                                colors: [
                                  AppColor.rdGradient2,
                                  AppColor.rdGradient1
                                ],
                              ),
                            ),
                            child: FlatButton(
                              onPressed: () => pay(requested),
                              child: Text(
                                "Pay",
                                style: AppTextStyles.textStyle(
                                  color: Colors.white,
                                  size: 28.f,
                                ),
                              ),
                            ),
                          )
                        : Container(
                            height: 35,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.grey),
                            child: FlatButton(
                              onPressed: () {},
                              child: Text(
                                "Pay",
                                style: AppTextStyles.textStyle(
                                  color: Colors.white,
                                  size: 28.f,
                                ),
                              ),
                            ),
                          )
              ],
            )
          ],
        ),
      ),
    );
  }
}
