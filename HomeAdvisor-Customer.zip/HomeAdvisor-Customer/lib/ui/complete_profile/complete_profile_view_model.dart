import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';
import 'package:stacked/stacked.dart';

class CompleteProfileViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ProfileModel _user;

  CompleteProfileViewModel() {
    _user = _userService.user;
  }

  ProfileModel get getUser => _user;

  set setUserName(String firstName) {
    _user.displayName = firstName;
  }

  set setLastName(String lastName) {
    _user.lastName = lastName;
  }

  set setEmail(String email) {
    _user.email = email;
  }

  set setAddress(String address) {
    _user.businessAddress = address;
  }

  set setZipCode(String zipCode) {
    _user.zipcode = zipCode;
  }

  var _selectedMunicipality;

  get selectedMunicipality => _selectedMunicipality;

  Future<void> selectMunicipality(var selectedMunicipality) async {
    _user.municipality = selectedMunicipality;

    notifyListeners();
  }

  void submitAction(BuildContext context) async {
    if (formKey.currentState.validate()) {
      if (await APIServices.checkEmail(
        _userService.token,
        _user.email,
      )) {
        var response = await APIServices.updateProfile(
          _user,
          _userService.token,
          isCompleteProfile: true,
        );
        if (response != null) {
          _userService.user = response;
          Navigator.pushNamed(context, HomePageView.id);
        }
      } else
        Fluttertoast.showToast(msg: 'Email already exist');
    } else
      Fluttertoast.showToast(msg: 'Fields are mandatory');
  }
}
