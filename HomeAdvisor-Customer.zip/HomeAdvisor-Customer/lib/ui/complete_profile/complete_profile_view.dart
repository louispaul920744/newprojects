import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/complete_profile/complete_profile_view_model.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class CompleteProfileView extends StatelessWidget {
  static const id = "CompleteProfile";

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    ScreenUtil.init(
      context,
      designSize: Size(750, 1334),
      allowFontScaling: false,
    );
    return ViewModelBuilder<CompleteProfileViewModel>.reactive(
      viewModelBuilder: () => CompleteProfileViewModel(),
      builder: (context, model, child) => Scaffold(
        body: SingleChildScrollView(
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20.h,
                ),
                Center(
                  child: Container(
                    height: 100.h,
                    child: Image.asset("assets/1/logo.png"),
                  ),
                ),
                SizedBox(
                  height: 70.h,
                ),
                Container(
                  margin: EdgeInsets.only(left: 20),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      language.lang == 'en'
                          ? "Complete Profile"
                          : "الملف الشخصي الكامل",
                      style: TextStyle(
                        fontSize: 18.f,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(25.0),
                  child: Form(
                    key: model.formKey,
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: language.lang == 'en'
                                  ? 'First Name'
                                  : "الاسم الاول"),
                          keyboardType: TextInputType.text,
                          onChanged: (text) {
                            model.setUserName = text;
                          },
                          validator: (value) {
                            if (value.isEmpty)
                              return language.lang == 'en'
                                  ? "First Name is required"
                                  : "مطلوب اسم";
                            else
                              return null;
                          },
                        ),
                        SizedBox(
                          height: 10.h,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: language.lang == 'en'
                                  ? 'Last Name'
                                  : "الكنية"),
                          keyboardType: TextInputType.text,
                          onChanged: (text) {
                            model.setLastName = text;
                          },
                          validator: (value) {
                            if (value.isEmpty)
                              return language.lang == 'en'
                                  ? "Last Name is required"
                                  : "مطلوب اسم";
                            else
                              return null;
                          },
                        ),
                        SizedBox(
                          height: 10.h,
                        ),
                        TextFormField(
                            decoration: InputDecoration(
                                labelText: language.lang == 'en'
                                    ? 'Email'
                                    : "البريد الإلكتروني"),
                            keyboardType: TextInputType.emailAddress,
                            onChanged: (text) {
                              model.setEmail = text;
                            },
                            validator: (value) {
                              if (!EmailValidator.validate(value)) {
                                return language.lang == 'en'
                                    ? "E-mail is not valid"
                                    : "البريد الإلكتروني غير صالح";
                              } else
                                return null;
                            }),
                        SizedBox(
                          height: 10.h,
                        ),
                        TextFormField(
                          maxLines: 2,
                          decoration: InputDecoration(
                              labelText:
                                  language.lang == 'en' ? 'Address' : "عنوان"),
                          keyboardType: TextInputType.text,
                          onChanged: (text) => model.setAddress = text,
                        ),
                        SizedBox(
                          height: 10.h,
                        ),
                        DropdownButtonFormField(
                          value: model.selectedMunicipality,
                          // icon: const Icon(Icons.arrow_downward),
                          // iconSize: 24,
                          style: const TextStyle(color: Colors.deepPurple),
                          hint: Text(
                            'Select your location',
                            style: TextStyle(fontSize: 18),
                          ),
                          validator: (value) => value == null
                              ? language.lang == 'en'
                                  ? "Please choose your location"
                                  : "البريد الإلكتروني غير صالح"
                              : null,

                          onChanged: (newValue) {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            model.selectMunicipality(newValue);
                          },
                          items: Helper().municipalitiess(
                              language.lang, AppColor.blCommon),
                        ),
                        // TextFormField(
                        //     decoration:
                        //         const InputDecoration(labelText: 'Address2'),
                        //     keyboardType: TextInputType.text,
                        //     onChanged: (text) => model.address1 = text,
                        //     validator: (value) {
                        //       return null;
                        //     }),
                        // SizedBox(
                        //   height: 10.h,
                        // ),
                        // TextFormField(
                        //     decoration:
                        //         const InputDecoration(labelText: 'Area'),
                        //     keyboardType: TextInputType.text,
                        //     validator: (value) {
                        //       if (value.length < 2) {
                        //         return "Area name is not long Enough";
                        //       } else
                        //         return "";
                        //     }),
                        // SizedBox(
                        //   height: 10.h,
                        // ),

                        SizedBox(
                          height: 10.h,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  margin: EdgeInsets.only(left: 20, right: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    gradient: LinearGradient(
                      colors: [
                        AppColor.blGradient2,
                        AppColor.blGradient1,
                      ],
                    ),
                  ),
                  height: 100.h,
                  width: 400.w,
                  child: FlatButton(
                    onPressed: () => model.submitAction(context),
                    child: Text(
                      language.lang == 'en' ? "Submit" : "إرسال",
                      style: TextStyle(fontSize: 20),
                    ),
                    textColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
