import 'package:flutter/material.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/auth/auth_service.dart';
import 'package:home_advisor/core/services/auth/firebase_auth_service.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/complete_profile/complete_profile_view.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:stacked/stacked.dart';

class LoginViewModel extends BaseViewModel {
  PhoneNumber number = PhoneNumber(isoCode: 'QA');
  AuthService _authService = locator<FirebaseAuthService>();
  UserService _userService = locator<UserService>();

  PhoneAuthenticationSteps _currentStep = PhoneAuthenticationSteps.INIT;

  TextEditingController textController = TextEditingController();

  PhoneAuthenticationSteps get currentStep => _currentStep;

  bool get isTimeout =>
      currentStep == PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT;

  set currentStep(PhoneAuthenticationSteps currentStep) {
    _currentStep = currentStep;
    switch (_currentStep) {
      case PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS:
        setBusy(false);
        break;
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED:
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED_NETWWORK:
      case PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT:
      case PhoneAuthenticationSteps.INVALID_OTP_ENTERED:
      case PhoneAuthenticationSteps.INIT:
        setBusy(false);
        break;
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
      case PhoneAuthenticationSteps.CODE_SENT:
        setBusy(false);
        break;
    }
    notifyListeners();
  }

  initState(BuildContext context) {
    _authService.onPhoneAuthenticationStepChanged.listen((event) {
      print(event);
      if (event == PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS) {
        {
          textController.text = "******";
          notifyListeners();
          authSucessAction(context);
        }
      } else if (event == PhoneAuthenticationSteps.INVALID_OTP_ENTERED) {
        otpValid = true;
        notifyListeners();
      } else {
        otpValid = false;
        notifyListeners();
      }
      currentStep = event;
    });
  }

  String _phoneNumber;

  String _otp;

  bool _isOtpRequested = false;

  bool get isOtpRequested => _isOtpRequested;

  bool otpValid = false;

  set isOtpRequested(bool isOtpRequested) {
    _isOtpRequested = isOtpRequested;
    notifyListeners();
  }

  String get phoneNumber => _phoneNumber;

  set phoneNumber(String initialMobileValue) {
    _phoneNumber = initialMobileValue;
    notifyListeners();
  }

  String get otp => _otp;

  set otp(String value) {
    _otp = value;
    notifyListeners();
  }

  bool _isMobileNoValid = false;

  bool get isMobileNoValid => _isMobileNoValid;

  set isMobileNoValid(bool isMobileNoValid) {
    _isMobileNoValid = isMobileNoValid;
    notifyListeners();
  }

  void validatePhone() {
    setBusy(true);
    _authService.signInWithPhone(phoneNumber);
  }

  Future<bool> checkUserType() async {
    print('jgjgjgn');
    return await APIServices.checkUserType(_userService.token, phoneNumber);
  }

  void validateOtp() {
    print(otp);
    try {
      _authService.validatePhoneOtp(otp);
    } catch (e) {
      print(e);
    }
  }

  String getHeaderText(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    switch (currentStep) {
      case PhoneAuthenticationSteps.INIT:

      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED:
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED_NETWWORK:
        return language.lang == 'en'
            ? "Welcome Back\nHome Advisor"
            : "مرحبًا بك مرة أخرى \n مستشار المنزل";
      case PhoneAuthenticationSteps.INVALID_OTP_ENTERED:
      case PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT:
      case PhoneAuthenticationSteps.CODE_SENT:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
      case PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
        return language.lang == 'en'
            ? "Enter OTP Received"
            : "أدخل OTP المستلم";
    }
    return language.lang == 'en'
        ? "Welcome Back\nHome Advisor"
        : "مرحبًا بك مرة أخرى \n مستشار المنزل";
  }

  String getButtonText(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    switch (currentStep) {
      case PhoneAuthenticationSteps.INIT:

      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED:
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED_NETWWORK:
        return language.lang == 'en' ? "SUBMIT" : "إرسال";
      case PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT:
      case PhoneAuthenticationSteps.INVALID_OTP_ENTERED:
      case PhoneAuthenticationSteps.CODE_SENT:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
      case PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
        return language.lang == 'en' ? "CONFIRM" : "تؤكد";
    }
    return language.lang == 'en' ? "SUBMIT" : "إرسال";
  }

  bool showOtp() {
    Sentry.captureMessage(
        'show otpstate ${currentStep.toString()} ${currentStep.index}');

    switch (currentStep) {
      case PhoneAuthenticationSteps.INIT:
      // case PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT:
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED:
      case PhoneAuthenticationSteps.AUTHENTICATION_FAILED_NETWWORK:
        return false;
      case PhoneAuthenticationSteps.INVALID_OTP_ENTERED:
      case PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
      case PhoneAuthenticationSteps.CODE_SENT:
      case PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS:
      case PhoneAuthenticationSteps.AUTO_RETRIEVING_CODE:
        return true;
    }
    return false;
  }

  Future<void> buttonAction(BuildContext context) async {
    if (currentStep == PhoneAuthenticationSteps.INIT) {
      validatePhone();
    } else if (currentStep == PhoneAuthenticationSteps.INVALID_OTP_ENTERED) {
    } else if (currentStep == PhoneAuthenticationSteps.INVALID_OTP_ENTERED ||
        currentStep == PhoneAuthenticationSteps.CODE_SENT ||
        currentStep == PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS) {
      validateOtp();
    } else if (currentStep == PhoneAuthenticationSteps.AUTHENTICATION_FAILED ||
        currentStep == PhoneAuthenticationSteps.AUTO_RETRIVAL_TIMEOUT ||
        currentStep ==
            PhoneAuthenticationSteps.AUTHENTICATION_FAILED_NETWWORK) {
      validatePhone();
    } else if (currentStep == PhoneAuthenticationSteps.AUTHENTICATION_SUCCESS) {
      authSucessAction(context);
    }
    return true;
  }

  void authSucessAction(BuildContext context) async {
    var user = await _userService.getUser();
    if (user?.displayName == null) {
      Navigator.pushNamedAndRemoveUntil(
          context, CompleteProfileView.id, (route) => false);
    } else
      Navigator.pushNamedAndRemoveUntil(
          context, HomePageView.id, (route) => false);
  }
}
