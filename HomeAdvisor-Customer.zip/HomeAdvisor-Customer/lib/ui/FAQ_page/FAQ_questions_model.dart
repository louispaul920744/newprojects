/// count : 1
/// next : ""
/// previous : ""
/// results : [{"id":1,"Question_en":"<p>What is Lorem Ipsum?</p>","Question_ar":"<p>ما هو لوريم إيبسوم؟</p>","answer_en":"<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>","answer_ar":"<p>لوريم إيبسوم هو ببساطة نص شكلي يستخدم في صناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من النوع وتدافعت عليه لعمل كتاب عينة. لقد نجت ليس فقط خمسة قرون ، ولكن أيضًا القفزة في التنضيد الإلكتروني ، وظلت دون تغيير جوهري. تم نشره في الستينيات من القرن الماضي بإصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخرًا مع برامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.</p>"}]

class FAQQuestionsModel {
  int _count;
  String _next;
  String _previous;
  List<Ques> _results;

  int get count => _count;
  String get next => _next;
  String get previous => _previous;
  List<Ques> get results => _results;

  FAQQuestionsModel(
      {int count, String next, String previous, List<Ques> results}) {
    _count = count;
    _next = next;
    _previous = previous;
    _results = results;
  }

  FAQQuestionsModel.fromJson(dynamic json) {
    _count = json["count"];
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(Ques.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["count"] = _count;
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 1
/// Question_en : "<p>What is Lorem Ipsum?</p>"
/// Question_ar : "<p>ما هو لوريم إيبسوم؟</p>"
/// answer_en : "<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>"
/// answer_ar : "<p>لوريم إيبسوم هو ببساطة نص شكلي يستخدم في صناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من النوع وتدافعت عليه لعمل كتاب عينة. لقد نجت ليس فقط خمسة قرون ، ولكن أيضًا القفزة في التنضيد الإلكتروني ، وظلت دون تغيير جوهري. تم نشره في الستينيات من القرن الماضي بإصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخرًا مع برامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.</p>"

class Ques {
  int _id;
  String _questionEn;
  String _questionAr;
  String _answerEn;
  String _answerAr;

  int get id => _id;
  String get questionEn => _questionEn;
  String get questionAr => _questionAr;
  String get answerEn => _answerEn;
  String get answerAr => _answerAr;

  Ques(
      {int id,
      String questionEn,
      String questionAr,
      String answerEn,
      String answerAr}) {
    _id = id;
    _questionEn = questionEn;
    _questionAr = questionAr;
    _answerEn = answerEn;
    _answerAr = answerAr;
  }

  Ques.fromJson(dynamic json) {
    _id = json["id"];
    _questionEn = json["Question_en"];
    _questionAr = json["Question_ar"];
    _answerEn = json["answer_en"];
    _answerAr = json["answer_ar"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["Question_en"] = _questionEn;
    map["Question_ar"] = _questionAr;
    map["answer_en"] = _answerEn;
    map["answer_ar"] = _answerAr;
    return map;
  }
}
