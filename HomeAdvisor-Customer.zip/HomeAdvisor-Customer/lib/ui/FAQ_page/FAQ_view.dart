import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_model.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_questions_model.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_view_model.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class FAQPage extends StatelessWidget {
  static const String id = "FAQPage";

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<FAQViewModel>.reactive(
        viewModelBuilder: () => FAQViewModel(),
        builder: (context, model, child) => Scaffold(
              appBar: AppBar(
                toolbarHeight: 110.h,
                actions: [
                  Container(
                    margin: EdgeInsets.only(right: 5),
                    child:
                        /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                        Text(''),
                  )
                ],
                leadingWidth: double.infinity,
                leading: Column(
                  children: [
                    Container(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Row(
                          children: [
                            Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                            Text(
                              language.lang == 'en' ? 'Go Back' : "عد",
                              style: AppTextStyles.s1(Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                flexibleSpace: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.06,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          language.lang == 'en' ? "FAQ" : "التعليمات",
                          style: AppTextStyles.textStyle(
                              color: Colors.white,
                              size: 30.f,
                              fontType: FontType.regular),
                        ),
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                        AppColor.blGradient2,
                        AppColor.blGradient1
                      ])),
                ),
                elevation: 1,
              ),
              body: Container(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: model.getToken() != null
                      ? SingleChildScrollView(
                          primary: true,
                          child: Column(
                            children: [
                              FutureBuilder(
                                future: APIServices.getFAQ(model.token),
                                builder: (_, AsyncSnapshot<FAQModel> snapshot) {
                                  if (snapshot.connectionState ==
                                          ConnectionState.done &&
                                      snapshot.hasData) {
                                    List<Results> faqs = snapshot.data.results;

                                    return faqs.length > 0
                                        ? SingleChildScrollView(
                                            child: Html(
                                              data: language.lang == 'ar'
                                                  ? faqs.first.descriptionAr
                                                  : faqs.first.descriptionEn,
                                              onLinkTap: (url) {
                                                print("Opening $url...");
                                              },
                                            ),
                                          )
                                        : Center(
                                            child: Text(
                                              language.lang == 'en'
                                                  ? "check connection and retry"
                                                  : "تحقق من الاتصال وأعد المحاولة",
                                              style: AppTextStyles.s2(
                                                  Colors.black),
                                            ),
                                          );
                                  } else {
                                    return SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.35,
                                    );
                                  }
                                },
                              ),
                              FutureBuilder(
                                future:
                                    APIServices.getFAQQuestions(model.token),
                                builder: (_,
                                    AsyncSnapshot<FAQQuestionsModel> snapshot) {
                                  if (snapshot.connectionState ==
                                          ConnectionState.done &&
                                      snapshot.hasData) {
                                    List<Ques> faqs = snapshot.data.results;

                                    return faqs.length > 0
                                        ? ListView.builder(
                                            primary: false,
                                            shrinkWrap: true,
                                            itemCount: faqs.length,
                                            itemBuilder: (context, index) =>
                                                Column(
                                              children: [
                                                Html(
                                                  data: language.lang == 'en'
                                                      ? faqs[index].questionEn
                                                      : faqs[index].questionAr,
                                                  onLinkTap: (url) {
                                                    print("Opening $url...");
                                                  },
                                                ),
                                                Html(
                                                  data: language.lang == 'en'
                                                      ? faqs[index].answerEn
                                                      : faqs[index].answerAr,
                                                  onLinkTap: (url) {
                                                    print("Opening $url...");
                                                  },
                                                ),
                                                Divider()
                                              ],
                                            ),
                                          )
                                        : Center(
                                            child: Text(
                                              language.lang == 'en'
                                                  ? "check connection and retry"
                                                  : "تحقق من الاتصال وأعد المحاولة",
                                              style: AppTextStyles.s2(
                                                  Colors.black),
                                            ),
                                          );
                                  } else {
                                    return Center(
                                      child: CircularProgressIndicator(
                                        backgroundColor: AppColor.rdCommon,
                                      ),
                                    );
                                  }
                                },
                              )
                            ],
                          ),
                        )
                      : Center(
                          child: CircularProgressIndicator(
                          backgroundColor: AppColor.rdCommon,
                        )),
                ),
              ),
            ));
  }
}
