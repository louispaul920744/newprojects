class FAQModel {
  int _count;
  String _next;
  String _previous;
  List<Results> _results;

  int get count => _count;
  String get next => _next;
  String get previous => _previous;
  List<Results> get results => _results;

  FAQModel({int count, String next, String previous, List<Results> results}) {
    _count = count;
    _next = next;
    _previous = previous;
    _results = results;
  }

  FAQModel.fromJson(dynamic json) {
    _count = json["count"];
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["count"] = _count;
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 4
/// description_en : "<p><strong>FAQ</strong></p>\r\n\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>"
/// description_ar : "<p>حيث أنها لا تأتي من؟<br />\r\nخلافًا للاعتقاد الشائع ، فإن Lorem Ipsum ليس مجرد نص عشوائي. لها جذور في قطعة من الأدب اللاتيني الكلاسيكي من 45 قبل الميلاد ، مما يجعلها أكثر من 2000 عام. قام ريتشارد مكلينتوك ، أستاذ اللغة اللاتينية في كلية هامبدن سيدني في فيرجينيا ، بالبحث عن واحدة من أكثر الكلمات اللاتينية غموضًا ، consectetur ، من مقطع لوريم إيبسوم ، وتصفح اقتباسات الكلمة في الأدب الكلاسيكي ، اكتشف المصدر الذي لا شك فيه. يأتي لوريم إيبسوم من القسمين 1.10.32 و 1.10.33 من &quot;de Finibus Bonorum et Malorum&quot; (أقصى الخير والشر) بقلم شيشرون ، وكُتب عام 45 قبل الميلاد. هذا الكتاب عبارة عن أطروحة حول نظرية الأخلاق ، وقد حظيت بشعبية كبيرة خلال عصر النهضة. السطر الأول من Lorem Ipsum ، &quot;Lorem ipsum dolor sit amet ..&quot; ، يأتي من سطر في القسم 1.10.32.</p>"
/// image : "https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-1.jpg"

class Results {
  int _id;
  String _descriptionEn;
  String _descriptionAr;
  String _image;

  int get id => _id;
  String get descriptionEn => _descriptionEn;
  String get descriptionAr => _descriptionAr;
  String get image => _image;

  Results({int id, String descriptionEn, String descriptionAr, String image}) {
    _id = id;
    _descriptionEn = descriptionEn;
    _descriptionAr = descriptionAr;
    _image = image;
  }

  Results.fromJson(dynamic json) {
    _id = json["id"];
    _descriptionEn = json["description_en"];
    _descriptionAr = json["description_ar"];
    _image = json["image"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["description_en"] = _descriptionEn;
    map["description_ar"] = _descriptionAr;
    map["image"] = _image;
    return map;
  }
}
