/// count : 1
/// next : ""
/// previous : ""
/// results : [{"id":1,"description_en":"<p><strong>About Us</strong></p>\r\n\r\n<p><em>Home Advisor&nbsp;is a digital platform where hundreds of services comes together. We will act as</em>service providers hub for customers. Whatever the service type may be; , Electricians, Carpenters, Cleaning, beauty, spa, mobile and other appliance repairs etc.</p>\r\n\r\n<p>People do search for various categories for various requirements like Repair and maintenance, Building &amp; Construction, Handyman Services, utilityServices, Local services. you have the solution with few clicks on your mobile and the service will be there at on your doorstep. We make sure that the service availed is at its best. we make sure that we reach every possible village in India and increase the job opportunity and affect the common man&rsquo;s life in a very positive way.</p>\r\n\r\n<p>We are providing an opportunity for a service provider to come out of his natural market and explore himself and by helping a customer to save his time,energy and money.<em>Home Advisor</em>&nbsp;stands for serving the people and adding value to build the nation.</p>","description_ar":"<p>About Us</p>\r\n\r\n<p>Home Advisor عبارة عن منصة رقمية حيث تتجمع مئات الخدمات معًا. سنعمل كمحور لمقدمي الخدمات للعملاء. مهما كان نوع الخدمة ؛ والكهربائيين والنجارين والتنظيف والجمال والسبا والجوال وإصلاح الأجهزة الأخرى وما إلى ذلك ، يبحث الناس عن فئات مختلفة لمتطلبات مختلفة مثل الإصلاح والصيانة والبناء والتشييد وخدمات العامل الماهر وخدمات المرافق والخدمات المحلية. لديك الحل بنقرات قليلة على هاتفك المحمول وستكون الخدمة على عتبة داركم. نتأكد من أن الخدمة المتوفرة في أفضل حالاتها</p>\r\n\r\n<p>. نتأكد من أننا نصل إلى كل قرية ممكنة في الهند ونزيد من فرص العمل ونؤثر على حياة الرجل العادي بطريقة إيجابية للغاية. نحن نوفر فرصة لمزود الخدمة للخروج من سوقه الطبيعي واستكشاف نفسه ومساعدة العميل على توفير وقته وطاقته وأمواله. Home Advisor يرمز إلى خدمة الناس وإضافة القيمة لبناء الأمة.</p>","image":"https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-2.jpg"}]

class AboutUsModel {
  int _count;
  String _next;
  String _previous;
  List<Results> _results;

  int get count => _count;
  String get next => _next;
  String get previous => _previous;
  List<Results> get results => _results;

  AboutUsModel(
      {int count, String next, String previous, List<Results> results}) {
    _count = count;
    _next = next;
    _previous = previous;
    _results = results;
  }

  AboutUsModel.fromJson(dynamic json) {
    _count = json["count"];
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["count"] = _count;
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 1
/// description_en : "<p><strong>About Us</strong></p>\r\n\r\n<p><em>Home Advisor&nbsp;is a digital platform where hundreds of services comes together. We will act as</em>service providers hub for customers. Whatever the service type may be; , Electricians, Carpenters, Cleaning, beauty, spa, mobile and other appliance repairs etc.</p>\r\n\r\n<p>People do search for various categories for various requirements like Repair and maintenance, Building &amp; Construction, Handyman Services, utilityServices, Local services. you have the solution with few clicks on your mobile and the service will be there at on your doorstep. We make sure that the service availed is at its best. we make sure that we reach every possible village in India and increase the job opportunity and affect the common man&rsquo;s life in a very positive way.</p>\r\n\r\n<p>We are providing an opportunity for a service provider to come out of his natural market and explore himself and by helping a customer to save his time,energy and money.<em>Home Advisor</em>&nbsp;stands for serving the people and adding value to build the nation.</p>"
/// description_ar : "<p>About Us</p>\r\n\r\n<p>Home Advisor عبارة عن منصة رقمية حيث تتجمع مئات الخدمات معًا. سنعمل كمحور لمقدمي الخدمات للعملاء. مهما كان نوع الخدمة ؛ والكهربائيين والنجارين والتنظيف والجمال والسبا والجوال وإصلاح الأجهزة الأخرى وما إلى ذلك ، يبحث الناس عن فئات مختلفة لمتطلبات مختلفة مثل الإصلاح والصيانة والبناء والتشييد وخدمات العامل الماهر وخدمات المرافق والخدمات المحلية. لديك الحل بنقرات قليلة على هاتفك المحمول وستكون الخدمة على عتبة داركم. نتأكد من أن الخدمة المتوفرة في أفضل حالاتها</p>\r\n\r\n<p>. نتأكد من أننا نصل إلى كل قرية ممكنة في الهند ونزيد من فرص العمل ونؤثر على حياة الرجل العادي بطريقة إيجابية للغاية. نحن نوفر فرصة لمزود الخدمة للخروج من سوقه الطبيعي واستكشاف نفسه ومساعدة العميل على توفير وقته وطاقته وأمواله. Home Advisor يرمز إلى خدمة الناس وإضافة القيمة لبناء الأمة.</p>"
/// image : "https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-2.jpg"

class Results {
  int _id;
  String _descriptionEn;
  String _descriptionAr;
  String _image;

  int get id => _id;
  String get descriptionEn => _descriptionEn;
  String get descriptionAr => _descriptionAr;
  String get image => _image;

  Results({int id, String descriptionEn, String descriptionAr, String image}) {
    _id = id;
    _descriptionEn = descriptionEn;
    _descriptionAr = descriptionAr;
    _image = image;
  }

  Results.fromJson(dynamic json) {
    _id = json["id"];
    _descriptionEn = json["description_en"];
    _descriptionAr = json["description_ar"];
    _image = json["image"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["description_en"] = _descriptionEn;
    map["description_ar"] = _descriptionAr;
    map["image"] = _image;
    return map;
  }
}
