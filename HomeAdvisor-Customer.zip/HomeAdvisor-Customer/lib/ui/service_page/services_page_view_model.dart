import 'package:home_advisor/app/locator.dart';
import 'package:stacked/stacked.dart';
import 'package:home_advisor/core/services/user_service.dart';

class ServicesPageViewModel extends BaseViewModel {
  UserService _userService = locator<UserService>();
  String token;
  String getToken() {
    token = _userService.token;
    return token;
  }
}
