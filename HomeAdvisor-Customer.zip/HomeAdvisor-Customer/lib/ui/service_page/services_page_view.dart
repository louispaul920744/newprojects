import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/locationdate/locationdate_view.dart';
import 'package:home_advisor/ui/survey_page/survey_page_model.dart';
import 'package:home_advisor/ui/survey_page/survey_page_view.dart';
import 'package:home_advisor/ui/widgets/service_tile.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:stacked/stacked.dart';

import 'services_page_model.dart';
import 'services_page_view_model.dart';

class ServicesPage extends StatelessWidget {
  final String title;
  final int subCategId;
  final int categId;
  final String name;

  ServicesPage({this.subCategId, this.title, this.categId, this.name});

  @override
  Widget build(BuildContext context) {
    LanguageService lang = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<ServicesPageViewModel>.reactive(
      builder: (context, model, child) => Scaffold(
          appBar: AppBar(
            toolbarHeight: 110.h,
            actions: [
              Container(
                margin: EdgeInsets.only(right: 5),
                child:
                    /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                    Text(''),
              )
            ],
            leadingWidth: double.infinity,
            leading: Column(
              children: [
                Container(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        ),
                        Text(
                          lang.lang == 'en' ? "Go Back" : 'عد',
                          style: AppTextStyles.textStyle(size: 16.f),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            flexibleSpace: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.0575,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      name,
                      style: AppTextStyles.textStyle(
                          color: Colors.white,
                          size: 30.f,
                          fontType: FontType.regular),
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [AppColor.blGradient2, AppColor.blGradient1])),
            ),
            elevation: 1,
          ),
          body: Container(
            color: Colors.white,
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: Align(
                    alignment: lang.lang == 'en'
                        ? Alignment.topLeft
                        : Alignment.topRight,
                    child: Text(
                      lang.lang == 'en' ? "Choose your Category" : "اختر فئتك",
                      style: AppTextStyles.textStyle(
                          color: AppColor.blCommon,
                          fontType: FontType.bold,
                          size: 28.f),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: model.getToken() != null
                        ? FutureBuilder(
                            future: APIServices.getServices(model.token),
                            // future: APIServices.getServices(model.token),
                            builder:
                                (_, AsyncSnapshot<ServicesPageModel> snapshot) {
                              if (snapshot.connectionState ==
                                      ConnectionState.done &&
                                  snapshot.hasData) {
                                List<Serve> services = snapshot.data.results;
                                services.removeWhere((element) =>
                                    element.subCategory.id != subCategId);
                                return services.length > 0
                                    ? GridView.count(
                                        childAspectRatio: (8 / 9),
                                        crossAxisSpacing: 10,
                                        mainAxisSpacing: 20,
                                        crossAxisCount: 2,
                                        children: List.generate(services.length,
                                            (index) {
                                          return ServicesTile(
                                            categoryName: lang.lang == 'ar'
                                                ? services[index].nameAr
                                                : services[index].name,
                                            url: services[index].icon,
                                            onTap: () async {
                                              // print('sssssss');
                                              Fluttertoast.showToast(
                                                  msg: 'Please wait');
                                              List<SurveyResults> ss = List();
                                              try {
                                                ss = (await APIServices
                                                        .getSurvey(model.token))
                                                    .results;
                                                ss = ss
                                                    .where((e) =>
                                                        e.service ==
                                                        services[index].id)
                                                    .toList();
                                                print(ss.length);
                                                print('suahil');
                                              } catch (e) {
                                                print('eeror');
                                                print(e);
                                                Sentry.captureException(e);
                                              }
                                              if (ss.length > 0)
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        SurveyPage(
                                                      id: services[index].id,
                                                      appBarName:
                                                          lang.lang == 'ar'
                                                              ? services[index]
                                                                  .nameAr
                                                              : services[index]
                                                                  .name,
                                                      categId: categId,
                                                      subCategId: subCategId,
                                                      serviceId:
                                                          services[index].id,
                                                    ),
                                                  ),
                                                );
                                              else
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        LocationDatePage(
                                                      answers: [],
                                                      surveys: [],
                                                      sid: services[index].id,
                                                      service: lang.lang == 'ar'
                                                          ? services[index]
                                                              .nameAr
                                                          : services[index]
                                                              .name,
                                                    ),
                                                  ),
                                                );
                                            },
                                          );
                                        }),
                                      )
                                    // ? StaggeredGridView.countBuilder(
                                    //     crossAxisCount: 4,
                                    //     itemCount: services.length,
                                    //     itemBuilder:
                                    //         (BuildContext context, int index) {
                                    //       if (services[index].subCategory.id ==
                                    //               subCategId &&
                                    //           services[index]
                                    //                   .subCategory
                                    //                   .category
                                    //                   .id ==
                                    //               categId) {
                                    //         return ServicesTile(
                                    //           categoryName:
                                    //               services[index].name,
                                    //           url: services[index].icon,
                                    //           onTap: () {
                                    //             Navigator.push(
                                    //               context,
                                    //               MaterialPageRoute(
                                    //                 builder: (context) =>
                                    //                     SurveyPage(
                                    //                   id: services[index].id,
                                    //                   appBarName:
                                    //                       services[index].name,
                                    //                   categId: categId,
                                    //                   subCategId: subCategId,
                                    //                   serviceId:
                                    //                       services[index].id,
                                    //                 ),
                                    //               ),
                                    //             );
                                    //           },
                                    //         );
                                    //       } else {
                                    //         return SizedBox();
                                    //       }
                                    //     },
                                    //     staggeredTileBuilder: (int index) =>
                                    //         new StaggeredTile.fit(2),
                                    //     mainAxisSpacing: 15.0,
                                    //     crossAxisSpacing: 15.0,
                                    //   )
                                    : Center(
                                        child: Text(
                                          lang.lang == 'en'
                                              ? "No Services Available"
                                              : "لا توجد خدمات متاحة",
                                          style: AppTextStyles.s2(Colors.black),
                                        ),
                                      );
                              } else {
                                return Center(
                                    child: CircularProgressIndicator(
                                  backgroundColor: AppColor.rdCommon,
                                ));
                              }
                            },
                          )
                        : Center(
                            child: CircularProgressIndicator(
                            backgroundColor: AppColor.rdCommon,
                          )),
                  ),
                )
              ],
            ),
          )),
      viewModelBuilder: () => ServicesPageViewModel(),
    );
  }
}
