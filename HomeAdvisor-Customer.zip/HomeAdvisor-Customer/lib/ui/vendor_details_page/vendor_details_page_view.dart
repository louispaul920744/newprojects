import 'package:flutter/material.dart';
import 'package:flutter_screenutil/size_extension.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/vendor_details_page/vendor_details_page_view_model.dart';
import 'package:home_advisor/ui/widgets/rating_card.dart';
import 'package:stacked/stacked.dart';

class VendorDetailsPageView extends StatelessWidget {
  static const String id = "VendorDetailsPageView";

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<VendorDetailsPageViewModel>.reactive(
      builder: (context, model, child) => DefaultTabController(
        length: 3,
        child: Scaffold(
            appBar: AppBar(
              toolbarHeight: 66,
              actions: [
                Container(
                  margin: EdgeInsets.only(right: 5),
                  child:
                      /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                      Text(''),
                )
              ],
              leadingWidth: 90,
              leading: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      child: Row(
                        children: [
                          Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          Text(
                            "Go Back",
                            style: AppTextStyles.textStyle(size: 11),
                          )
                        ],
                      ),
                    ),
                  ),
                  Text(
                    "Review",
                    style: AppTextStyles.textStyle(
                        size: 18, fontType: FontType.regular),
                  )
                ],
              ),
              flexibleSpace: Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [AppColor.blGradient2, AppColor.blGradient1])),
              ),
              elevation: 1,
            ),
            body: Column(
              children: [
                Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 15, right: 15),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.grey[400].withOpacity(0.1),
                    ),
                    child: TabBar(
                      indicator: BoxDecoration(),
                      labelColor: Colors.blue,
                      unselectedLabelColor: Colors.grey,
                      tabs: [
                        Tab(
                          text: 'Profile',
                        ),
                        Tab(
                          text: "Services",
                        ),
                        Tab(
                          text: 'Review',
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: <Widget>[
                      Center(child: Text("Profile")),
                      Center(child: Text("Services")),
                      Container(
                        color: Colors.white,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              Container(
                                padding: EdgeInsets.all(10),
                                child: Text(model.descr),
                              ),
                              Divider(),
                              Container(
                                padding: EdgeInsets.all(10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Achievements",
                                      style:
                                          AppTextStyles.s2(AppColor.blCommon),
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 10.h),
                                      child: Text(model.achiev),
                                    ),
                                    Row(
                                      children: [
                                        Image.asset(
                                          "lib/images/logo/g1.png",
                                          width: 70,
                                        ),
                                        Image.asset(
                                          "lib/images/logo/g1.png",
                                          width: 70,
                                        ),
                                        Image.asset(
                                          "lib/images/logo/g1.png",
                                          width: 70,
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              Divider(),
                              Text(
                                "Reviews",
                                style: AppTextStyles.s2(AppColor.blCommon),
                              ),
                              ListView.builder(
                                primary: false,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return RatingCard(
                                    rating: model.details[index].rating,
                                    name: model.details[index].name,
                                    review: model.details[index].desc,
                                  );
                                },
                                itemCount: model.details.length,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )),
      ),
      viewModelBuilder: () => VendorDetailsPageViewModel(),
    );
  }
}
