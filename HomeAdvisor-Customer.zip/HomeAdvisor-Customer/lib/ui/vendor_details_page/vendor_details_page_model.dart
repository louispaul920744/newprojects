class VendorDetailsModel {
  final String name;
  final String desc;
  final double rating;
  VendorDetailsModel({this.name, this.desc, this.rating});
}
