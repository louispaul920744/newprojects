import 'package:stacked/stacked.dart';
import 'package:home_advisor/ui/vendor_details_page/vendor_details_page_model.dart';

class VendorDetailsPageViewModel extends BaseViewModel {
  List<VendorDetailsModel> details = [
    VendorDetailsModel(
        rating: 2,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
    VendorDetailsModel(
        rating: 3,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
    VendorDetailsModel(
        rating: 1,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
    VendorDetailsModel(
        rating: 5,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
    VendorDetailsModel(
        rating: 4,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
    VendorDetailsModel(
        rating: 5,
        name: "Smith Franzen",
        desc:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
  ];
  String descr =
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy";
  String achiev =
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy";
}
