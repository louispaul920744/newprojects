class SurveyModel {
  String _next;
  String _previous;
  List<SurveyResults> _results;

  String get next => _next;
  String get previous => _previous;
  List<SurveyResults> get results => _results;

  SurveyModel({String next, String previous, List<SurveyResults> results}) {
    _next = next;
    _previous = previous;
    _results = results;
  }

  SurveyModel.fromJson(dynamic json) {
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(SurveyResults.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class SurveyResults {
  int _id;
  int _service;
  String _question;
  List<Options> _options;
  String _question_ar;

  int get id => _id;
  int get service => _service;
  String get question => _question;
  List<Options> get options => _options;
  String get question_ar => _question_ar;

  SurveyResults(
      {int id,
      int service,
      String question,
      List<Options> options,
      String question_ar}) {
    _id = id;
    _service = service;
    _question = question;
    _options = options;
    _question_ar = question_ar;
  }

  SurveyResults.fromJson(dynamic json) {
    _id = json["id"];
    _service = json["service"];
    _question = json["question"];
    _question_ar = json["question_ar"];
    if (json["options"] != null) {
      _options = [];
      json["options"].forEach((v) {
        _options.add(Options.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["service"] = _service;
    map["question"] = _question;
    map["question_ar"] = _question_ar;
    if (_options != null) {
      map["options"] = _options.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class Options {
  int _id;
  String _name;
  int _survey;
  String _name_ar;

  int get id => _id;
  String get name => _name;
  int get survey => _survey;
  String get name_ar => _name_ar;

  Options({int id, String name, int survey}) {
    _id = id;
    _name = name;
    _survey = survey;
    _name_ar = name_ar;
  }

  Options.fromJson(dynamic json) {
    _id = json["id"];
    _name = json["name"];
    _survey = json["survey"];
    _name_ar = json["name_ar"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["name"] = _name;
    map["survey"] = _survey;
    map["name_ar"] = _name_ar;
    return map;
  }
}

class QuestionsModel {
  String _next;
  String _previous;
  List<QuestionResults> _results;

  String get next => _next;
  String get previous => _previous;
  List<QuestionResults> get results => _results;

  QuestionsModel(
      {String next, String previous, List<QuestionResults> results}) {
    _next = next;
    _previous = previous;
    _results = results;
  }

  QuestionsModel.fromJson(dynamic json) {
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(QuestionResults.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class QuestionResults {
  int _id;
  int _service;
  String _question;
  String _questionAr;
  bool _general;
  bool _active;

  int get id => _id;
  int get service => _service;
  String get question => _question;
  String get questionAr => _questionAr;
  bool get general => _general;
  bool get active => _active;

  QuestionResults(
      {int id,
      int service,
      String question,
      String questionAr,
      bool general,
      bool active}) {
    _id = id;
    _service = service;
    _question = question;
    _questionAr = questionAr;
    _general = general;
    _active = active;
  }

  QuestionResults.fromJson(dynamic json) {
    _id = json["id"];
    _service = json["service"];
    _question = json["question"];
    _questionAr = json["question_ar"];
    _general = json["general"];
    _active = json["active"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["service"] = _service;
    map["question"] = _question;
    map["question_ar"] = _questionAr;
    map["general"] = _general;
    map["active"] = _active;
    return map;
  }
}
