import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/locationdate/locationdate_view.dart';
import 'package:home_advisor/ui/survey_page/survey_page_model.dart';
import 'package:home_advisor/ui/survey_page/survey_page_view_model.dart';
import 'package:home_advisor/ui/widgets/survey_question_widget/question_text_field_widget.dart';
import 'package:home_advisor/ui/widgets/survey_question_widget/survey_widget.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class SurveyPage extends StatelessWidget {
  final String appBarName;
  final int id;
  final int subCategId;
  final int categId;
  final int serviceId;
  final _formKey = GlobalKey<FormState>();

  SurveyPage(
      {this.appBarName,
      this.categId,
      this.serviceId,
      this.subCategId,
      this.id});

  @override
  Widget build(BuildContext context) {
    LanguageService lang = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<SurveyPageViewModel>.reactive(
        builder: (context, model, child) {
          return Scaffold(
            appBar: AppBar(
              toolbarHeight: 110.h,
              actions: [
                Container(
                  margin: EdgeInsets.only(right: 5),
                  child:
                      /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                      Text(''),
                )
              ],
              leadingWidth: double.infinity,
              leading: Column(
                children: [
                  Container(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          Text(
                            lang.lang == 'en' ? "Go Back" : "عد",
                            style: AppTextStyles.textStyle(size: 16.f),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              flexibleSpace: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.06,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        appBarName,
                        style: AppTextStyles.textStyle(
                          color: Colors.white,
                          size: 30.f,
                          fontType: FontType.regular,
                        ),
                      ),
                    ),
                  ],
                ),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [AppColor.blGradient2, AppColor.blGradient1])),
              ),
              elevation: 1,
            ),
            body: model.getToken() != null
                ? SingleChildScrollView(
                    padding: EdgeInsets.all(15),
                    primary: true,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          FutureBuilder(
                            future: APIServices.getQuestions(model.token),
                            builder:
                                (_, AsyncSnapshot<QuestionsModel> snapshot) {
                              if (snapshot.hasData) {
                                List<QuestionResults> questions =
                                    snapshot.data.results;
                                return ListView.builder(
                                  primary: false,
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return questions[index].service == serviceId
                                        ? QuestionTextFieldWidget(
                                            formKey: _formKey,
                                            question: lang.lang == 'ar'
                                                ? questions[index].questionAr
                                                : questions[index].question,
                                            onChanged: (answer) {
                                              model.getQuestion(model.que,
                                                  questions[index].id);
                                              model.que.add({
                                                "question": questions[index].id,
                                                "answer": answer
                                              });
                                            },
                                          )
                                        : SizedBox.shrink();
                                  },
                                  itemCount: questions.length,
                                );
                              } else {
                                return Column(
                                  children: [
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.45,
                                    ),
                                    Center(
                                      child: CircularProgressIndicator(
                                        backgroundColor: AppColor.rdCommon,
                                      ),
                                    ),
                                  ],
                                );
                              }
                            },
                          ),
                          FutureBuilder(
                            future: APIServices.getSurvey(model.token),
                            builder: (_, AsyncSnapshot<SurveyModel> snapshot) {
                              if (snapshot.hasData) {
                                List<SurveyResults> questions =
                                    snapshot.data.results;
                                return Column(
                                  children: [
                                    ListView.builder(
                                      primary: false,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        if (questions[index].service ==
                                            serviceId) {
                                          return SurveyWidget(
                                            options: questions[index].options,
                                            question: lang.lang == 'en'
                                                ? questions[index].question
                                                : questions[index].question_ar,
                                            getChoice:
                                                (choice, selectedChoice) {
                                              model.getSurvey(
                                                model.sur,
                                                questions[index].id,
                                              );
                                              model.sur.add({
                                                "survey": questions[index].id,
                                                "choice": selectedChoice
                                              });
                                            },
                                          );
                                        } else {
                                          return SizedBox.shrink();
                                        }
                                      },
                                      itemCount: questions.length,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        margin: EdgeInsets.only(
                                            left: 20, right: 10),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          gradient: LinearGradient(
                                            colors: [
                                              AppColor.rdGradient2,
                                              AppColor.rdGradient1
                                            ],
                                          ),
                                        ),
                                        height: 50,
                                        child: FlatButton(
                                          onPressed: () {
                                            print(model.que);
                                            print(model.sur);
                                            if (_formKey.currentState
                                                .validate()) {
                                              model.length = 0;
                                              for (int i = 0;
                                                  i < questions.length;
                                                  i++) {
                                                if (questions[i].service ==
                                                    serviceId) {
                                                  model.length++;
                                                }
                                              }

                                              if (model.sur.length ==
                                                  model.length) {
                                                model.convertToModel();
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        LocationDatePage(
                                                      answers: model.answers,
                                                      surveys: model.surveys,
                                                      sid: id,
                                                      service: appBarName,
                                                    ),
                                                  ),
                                                );
                                              } else {
                                                model.showToast(context,
                                                    message: lang.lang == 'en'
                                                        ? "Please answer every question"
                                                        : "الرجاء الإجابة على كل سؤال");
                                              }
                                            }
                                          },
                                          child: Text(
                                            lang.lang == 'en'
                                                ? "Submit"
                                                : "إرسال",
                                            style: TextStyle(
                                              fontSize: 30.f,
                                            ),
                                          ),
                                          textColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              } else {
                                return SizedBox.shrink();
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  )
                : Center(
                    child: CircularProgressIndicator(
                    backgroundColor: AppColor.rdCommon,
                  )),
          );
        },
        viewModelBuilder: () => SurveyPageViewModel());
  }
}
