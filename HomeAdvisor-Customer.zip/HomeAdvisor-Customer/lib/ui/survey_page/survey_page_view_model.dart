import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart';
import 'package:stacked/stacked.dart';

class SurveyPageViewModel extends BaseViewModel {
  String token;
  List sur = [];
  List toRemove = [];
  int length = 0;
  List que = [];
  List quesToRem = [];
  UserService _userService = locator<UserService>();
  List<Surveys> surveys = [];
  List<Answers> answers = [];

  String getToken() {
    token = _userService.token;
    return token;
  }

  void getSurvey(
    sur,
    questionId,
  ) {
    for (var map in sur) {
      if (map.containsKey("survey")) {
        if (map["survey"] == questionId) {
          toRemove.add(map);
        }
      }
    }
    sur.removeWhere((e) => toRemove.contains(e));
  }

  void getQuestion(que, questionId) {
    for (var map in que) {
      if (map.containsKey("question")) {
        if (map["question"] == questionId) {
          quesToRem.add(map);
        }
      }
    }
    que.removeWhere((e) => quesToRem.contains(e));
  }

  void convertToModel() {
    surveys.clear();
    answers.clear();
    // for (int i = 0; i < que.length; i++) {
    //   answers
    //       .add(Answers(question: que[i], answer: que[i].containsKey("answer")));
    // }
    // Surveys s = Surveys(choice: 1, survey: 123);
    // surveys = [s];
    // print(surveys[0]);

    for (var map in sur) {
      if (map.containsKey("survey")) {
        surveys.add(Surveys(survey: map["survey"], choice: map["choice"]));
      }
    }
    for (var map in que) {
      if (map.containsKey("question")) {
        answers.add(Answers(question: map["question"], answer: map["answer"]));
      }
    }
  }

  void showToast(BuildContext context, {@required message}) {
    Fluttertoast.showToast(msg: message);
  }
}
