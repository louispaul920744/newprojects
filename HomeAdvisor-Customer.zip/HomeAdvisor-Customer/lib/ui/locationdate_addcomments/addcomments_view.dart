import 'package:flutter/material.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart' as orderModel;
import 'package:home_advisor/ui/locationdate_addcomments/addcomments_viewmodel.dart';
import 'package:home_advisor/ui/summary/summary_view.dart';
import 'package:home_advisor/ui/widgets/summary_card.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class AddComments extends StatelessWidget {
  final String date;
  final String time;
  final String service;
  final DateTime seldate;
  final int sid;
  final String location;
  final Location latLong;
  final List<orderModel.Surveys> surveys;
  final List<orderModel.Answers> answers;
  final String timeFormated;

  AddComments(
      {this.time,
      this.date,
      this.service,
      this.latLong,
      this.seldate,
      this.sid,
      this.location,
      this.surveys,
      this.answers,
      this.timeFormated});

  final TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<AddCommentsViewModel>.reactive(
        builder: (context, model, child) => Scaffold(
              appBar: AppBar(
                toolbarHeight: 110.h,
                actions: [
                  Container(
                    margin: EdgeInsets.only(right: 5),
                    child:
                        /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                        Text(''),
                  )
                ],
                leadingWidth: double.infinity,
                leading: Column(
                  children: [
                    Container(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Row(
                          children: [
                            Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                            Text(
                              language.lang == 'en' ? "Go Back" : "عد",
                              style: AppTextStyles.textStyle(size: 16.f),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                flexibleSpace: Container(
                  height: double.maxFinite,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.06,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          language.lang == 'en'
                              ? "Location and Date, Time"
                              : "الموقع والتاريخ والوقت",
                          style: AppTextStyles.textStyle(
                            color: Colors.white,
                            size: 30.f,
                            fontType: FontType.regular,
                          ),
                        ),
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                        AppColor.blGradient2,
                        AppColor.blGradient1
                      ])),
                ),
                elevation: 1,
              ),
              body: SingleChildScrollView(
                child: Container(
                    child: Padding(
                  padding: EdgeInsets.all(15.0),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      SummaryCard(
                        location: location,
                        category: service,
                        date: date,
                        time: timeFormated,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        child: TextField(
                          controller: controller,
                          maxLines: 7,
                          decoration: InputDecoration(
                              hintText: language.lang == 'en'
                                  ? 'Add Comments'
                                  : "أضف التعليقات",
                              border: OutlineInputBorder()),
                        ),
                      ),
                      SizedBox(
                        height: 50,
                      ),
                      model.images.isNotEmpty
                          ? GridView.count(
                              crossAxisCount: 3,
                              mainAxisSpacing: 8.0,
                              crossAxisSpacing: 8.0,
                              shrinkWrap: true,
                              primary: false,
                              children: List<Widget>.generate(
                                  model.images.length, (index) {
                                return Stack(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(1),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey,
                                              blurRadius: 2.0,
                                              spreadRadius: 2),
                                        ],
                                        image: DecorationImage(
                                          fit: BoxFit.fill,
                                          image: FileImage(model.images[index]),
                                        ),
                                      ),
                                    ),
                                    GestureDetector(
                                      child: Container(
                                          color: Colors.black.withOpacity(0.5),
                                          child: Icon(
                                            Icons.close,
                                            color: Colors.white,
                                          )),
                                      onTap: () {
                                        model.deleteImage(index);
                                      },
                                    ),
                                  ],
                                );
                              }),
                            )
                          : Container(),
                      SizedBox(
                        height: 20,
                      ),
                      GestureDetector(
                        onTap: () {
                          model.addPhoto();
                        },
                        child: Container(
                          height: 50,
                          width: 400,
                          decoration: BoxDecoration(
                              border: Border.all(color: AppColor.blLight)),
                          child: Center(
                              child: Text(
                            language.lang == 'en' ? 'Add Photo' : 'إضافة صورة',
                            style: AppTextStyles.textStyle(
                                size: 30.f, color: AppColor.blLight),
                          )),
                        ),
                      ),
                      SizedBox(
                        height: 100,
                      ),
                      FlatButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Summary(
                                answers: answers,
                                surveys: surveys,
                                location: location,
                                latLong: latLong,
                                service: service,
                                sid: sid,
                                date: date,
                                seldate: seldate,
                                time: time,
                                timeFormated: timeFormated,
                                comment: controller.text,
                                images: model.images,
                              ),
                            ),
                          );
                        },
                        child: Ink(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppColor.rdGradient2,
                                  AppColor.rdGradient1
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(5.0)),
                          child: Container(
                            constraints: BoxConstraints(
                                maxWidth: 165.0, minHeight: 50.0),
                            alignment: Alignment.center,
                            child: Text(
                              language.lang == 'en' ? "CONTINUE" : "استمر",
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
              ),
            ),
        viewModelBuilder: () => AddCommentsViewModel());
  }
}
