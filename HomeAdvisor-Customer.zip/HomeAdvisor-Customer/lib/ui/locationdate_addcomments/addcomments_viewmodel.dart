import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:stacked/stacked.dart';
import 'package:file_picker/file_picker.dart';

class AddCommentsViewModel extends BaseViewModel {
  final _picker = ImagePicker();
  List<File> _images = new List<File>();

  List<File> get images => _images;

  set setImages(List<File> images) {
    _images.addAll(images);
    notifyListeners();
  }

  deleteImage(int index) {
    images.removeAt(index);
    notifyListeners();
  }

  Future<void> addPhoto() async {
    List<File> images = [];
    FilePickerResult result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg'],
    );
    if (result != null) {
      List<File> files = result.paths.map((path) => File(path)).toList();
      images.addAll(files);
      setImages = images;
    } else {
      print("image: user canceled");
    }
  }
}
