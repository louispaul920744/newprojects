import 'package:flutter/material.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter_platform_interface/src/types/location.dart';
import 'package:google_maps_place_picker/google_maps_place_picker.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:google_maps_webservice/src/core.dart' as C;
import 'package:google_static_maps_controller/google_static_maps_controller.dart';
import 'package:google_static_maps_controller/google_static_maps_controller.dart'
    as Location;
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart';
import 'package:home_advisor/ui/locationdate_addcomments/addcomments_view.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'locationdate_view_model.dart';

class LocationDatePage extends StatefulWidget {
  static const String id = "LocationDatePage";
  final String service;
  final int sid;
  final List<Surveys> surveys;
  final List<Answers> answers;

  LocationDatePage({this.service, this.sid, this.answers, this.surveys});

  @override
  _LocationDatePageState createState() => _LocationDatePageState();
}

class _LocationDatePageState extends State<LocationDatePage> {
  Prediction prediction;
  LocationDatePageViewModel model;

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );

    return ViewModelBuilder<LocationDatePageViewModel>.reactive(
        builder: (context, model, child) {
          this.model = model;
          return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              toolbarHeight: 110.h,
              actions: [
                Container(
                  margin: EdgeInsets.only(right: 5),
                  child:
                      /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                      Text(''),
                )
              ],
              leadingWidth: double.infinity,
              leading: Column(
                children: [
                  Container(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          Text(
                            language.lang == 'en' ? "Go Back" : 'عد',
                            style: AppTextStyles.textStyle(size: 16.f),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              flexibleSpace: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.06,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        language.lang == 'en'
                            ? "Location and Date, Time"
                            : "الموقع والتاريخ والوقت",
                        style: AppTextStyles.textStyle(
                          color: Colors.white,
                          size: 30.f,
                          fontType: FontType.regular,
                        ),
                      ),
                    ),
                  ],
                ),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [AppColor.blGradient2, AppColor.blGradient1])),
              ),
              elevation: 1,
            ),
            body: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                primary: true,
                child: Column(
                  children: [
                    SizedBox(
                      height: 20.0,
                    ),
                    Padding(
                      padding: EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          TextField(
                              readOnly: true,
                              controller: model.controller,
                              decoration: InputDecoration(
                                suffixIcon: Icon(Icons.location_on),
                                hintText: language.lang == 'en'
                                    ? "Enter Location"
                                    : "إدخال الدولة",
                                border: OutlineInputBorder(),
                              ),
                              onTap: () async {
                                getSuggestion();
                              }),
                          if (model.latLong != null)
                            InkWell(
                              onTap: () async {
                                getSuggestion();
                              },
                              child: Container(
                                height: 450.w,
                                color: Colors.white,
                                child: StaticMap(
                                  scaleToDevicePixelRatio: true,
                                  zoom: 15,
                                  googleApiKey:
                                      "AIzaSyBoZGYmNd8jvV1111TETjQUY5EziI65p6k",
                                  markers: <Marker>[
                                    Marker(
                                      // color: Colors.lightBlue,
                                      // label: "A",
                                      locations: [
                                        Location.Location(model.latLong.lat,
                                            model.latLong.lng),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 8.0,
                    ),
                    Container(
                      height: 200.0,
                      child: CalendarCarousel(
                        onDayPressed: (date, events) {
                          model.assignDate(date, events);
                          model.setDate();
                        },
                        weekFormat: true,
                        weekdayTextStyle: TextStyle(color: Color(0xff14287B)),
                        weekendTextStyle: TextStyle(color: Color(0xff14287B)),
                        daysHaveCircularBorder: false,
                        selectedDayButtonColor: Color(0xff65BDF7),
                        selectedDayBorderColor: Colors.grey,
                        thisMonthDayBorderColor: Colors.grey,
                        iconColor: Colors.grey,
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    Padding(
                      padding: EdgeInsets.all(10.0),
                      child: SizedBox(
                        height: 220.0,
                        child: GridView.builder(
                          primary: false,
                          itemCount: 8,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            mainAxisSpacing: 20.0,
                            crossAxisSpacing: 20.0,
                            childAspectRatio: 5 / 2.5,
                          ),
                          itemBuilder: (context, index) => GestureDetector(
                            onTap: () {
                              print(model.time[index]);
                              print(model.timeAr[index]);
                              model.selectedP(index, language.lang);

                              if (model.seldate == null) {
                                model.setDateNow();
                              }
                              model.setDate();
                            },
                            child: GridViewItem(
                              language.lang == 'en'
                                  ? model.time[index]
                                  : model.timeAr[index],
                              model.selectedTime == model.time[index] ||
                                  model.selectedTime == model.timeAr[index],
                              true,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      child: FlatButton(
                        onPressed: () {
                          if (model.selectedDate != null &&
                              model.selectedTime != null &&
                              model.location != null &&
                              model.seldate.isAfter(DateTime.now())) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AddComments(
                                  surveys: widget.surveys,
                                  answers: widget.answers,
                                  location: model.location,
                                  latLong: model.latLong,
                                  time: model.selectedTime,
                                  timeFormated: model.selectedTimeFormated,
                                  date: model.selectedDate,
                                  seldate: model.seldate,
                                  service: widget.service,
                                  sid: widget.sid,
                                ),
                              ),
                            );
                          } else {
                            if (model.selectedDate == null) {
                              model.showToast(
                                context,
                                message: language.lang == 'en'
                                    ? "Please select date"
                                    : "الرجاء تحديد التاريخ",
                              );
                            } else if (model.selectedTime == null) {
                              model.showToast(
                                context,
                                message: language.lang == 'en'
                                    ? "Please select time"
                                    : "الرجاء تحديد الوقت",
                              );
                            } else if (model.location == null) {
                              model.showToast(
                                context,
                                message: language.lang == 'en'
                                    ? "Please select location"
                                    : "الرجاء تحديد الموقع",
                              );
                            } else if (model.seldate.isBefore(DateTime.now())) {
                              print('sssssssssssssssssss  ${model.seldate}');
                              model.showToast(
                                context,
                                message: language.lang == 'en'
                                    ? "Please choose the correct date/time-slot"
                                    : "الرجاء اختيار التاريخ / الفترة الزمنية الصحيحة",
                              );
                            }
                          }
                        },
                        child: Ink(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppColor.rdGradient2,
                                  AppColor.rdGradient1
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(5.0)),
                          child: Container(
                            constraints: BoxConstraints(
                                maxWidth: 165.0, minHeight: 50.0),
                            alignment: Alignment.center,
                            child: Text(
                              language.lang == 'en' ? "CONTINUE" : "استمر",
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        viewModelBuilder: () => LocationDatePageViewModel());
  }

  Position position;

  void _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      Fluttertoast.showToast(msg: 'Please enable gps');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.deniedForever) {
        Fluttertoast.showToast(msg: 'Please enable permission manually');
      }

      if (permission == LocationPermission.denied) {
        Fluttertoast.showToast(msg: 'Please enable permission manually');
      }
    }

    if ((permission == LocationPermission.always ||
            permission == LocationPermission.whileInUse) &&
        !serviceEnabled) {
      await Geolocator.isLocationServiceEnabled();
    }
    Position position = await Geolocator.getCurrentPosition();

    model.latLong = C.Location(position.latitude, position.longitude);
    getLocationn(position.latitude, position.longitude);
  }

  Future<String> getLocationn(double lat, double long) async {
    print('lat nad long $lat $long');
    final coordinates = new Coordinates(lat, long);
    var addresses =
        await Geocoder.google('AIzaSyBoZGYmNd8jvV1111TETjQUY5EziI65p6k')
            .findAddressesFromCoordinates(
      coordinates,
    );
    var first = addresses.first;
    print(first.toMap());
    model.location = first.addressLine;
    model.controller.text = model.location;
    setState(() {});
    return ("${first.featureName} : ${first.addressLine}");
  }

  @override
  void initState() {
    super.initState();

    print("survey length ${widget.surveys.length}");
    print("answers length ${widget.answers.length}");
    _determinePosition();
  }

  void getSuggestion() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return PlacePicker(
            apiKey: 'AIzaSyBoZGYmNd8jvV1111TETjQUY5EziI65p6k',
            initialPosition: model.latLong != null
                ? LatLng(model.latLong.lat, model.latLong.lng)
                : LatLng(25.3548, 51.1839),
            useCurrentLocation: model.latLong != null,
            enableMyLocationButton: false,
            selectInitialPosition: true,
            //usePlaceDetailSearch: true,
            onPlacePicked: (result) {
              model.latLong = C.Location(
                  result.geometry.location.lat, result.geometry.location.lng);
              model.location = result.formattedAddress;
              model.controller.text = model.location;

              setState(() {});
              Navigator.of(context).pop();
            },
            //forceSearchOnZoomChanged: true,
            //automaticallyImplyAppBarLeading: false,
            //autocompleteLanguage: "ko",
            //region: 'au',

            selectedPlaceWidgetBuilder:
                (_, selectedPlace, state, isSearchBarFocused) {
              print("state: $state, isSearchBarFocused: $isSearchBarFocused");
              return isSearchBarFocused
                  ? Container()
                  : FloatingCard(
                      bottomPosition: 0.0,
                      // MediaQuery.of(context) will cause rebuild. See MediaQuery document for the information.
                      leftPosition: 0.0,
                      rightPosition: 0.0,
                      borderRadius: BorderRadius.circular(12.0),
                      child: state == SearchingState.Searching
                          ? Center(child: CircularProgressIndicator())
                          : Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                              child: RaisedButton(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  child: Text(
                                    "Select",
                                  ),
                                ),
                                onPressed: () {
                                  model.latLong = C.Location(
                                      selectedPlace.geometry.location.lat,
                                      selectedPlace.geometry.location.lng);
                                  model.location =
                                      selectedPlace.formattedAddress;
                                  model.controller.text = model.location;
                                  print(
                                      "do something with [selectedPlace] data");
                                  setState(() {});

                                  Navigator.of(context).pop();
                                },
                              ),
                            ),
                    );
            },

            // pinBuilder: (context, state) {
            //   if (state == PinState.Idle) {
            //     return Icon(Icons.favorite_border);
            //   } else {
            //     return Icon(Icons.favorite);
            //   }
            // },
          );
        },
      ),
    );
    setState(() {});
  }
}

class GridViewItem extends StatelessWidget {
  final String _time;
  final bool _isSelected;
  final bool _isActive;

  GridViewItem(this._time, this._isSelected, this._isActive);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
          child: Text(
        _time,
        style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: _isSelected && _isActive ? Colors.white : Color(0xff14287B)),
      )),
      height: 50.0,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        color: _isSelected && _isActive ? Color(0xff65BDF7) : Colors.white,
      ),
    );
  }
}
