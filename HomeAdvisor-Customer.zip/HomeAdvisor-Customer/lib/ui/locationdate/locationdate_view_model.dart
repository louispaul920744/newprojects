import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';

class LocationDatePageViewModel extends BaseViewModel {
  String location;
  Location latLong;
  TextEditingController controller = TextEditingController();
  String selectedWeekDay;
  String selectedMonth;
  String selectedDay;
  String selectedDate;
  DateTime seldate;
  String selectedTime;
  String selectedTimeFormated;

  void showToast(BuildContext context, {@required message}) {
    Fluttertoast.showToast(msg: message);
  }

  void setDateNow() {
    DateTime now = DateTime.now();
    seldate = now.subtract(Duration(
        hours: now.hour,
        microseconds: now.microsecond,
        minutes: now.minute - 1,
        seconds: now.second,
        milliseconds: now.millisecond));

    assignDate(seldate, null);
    notifyListeners();
  }

  void setDate() {
    seldate = seldate.subtract(Duration(
        hours: seldate.hour,
        minutes: seldate.minute,
        milliseconds: seldate.millisecond,
        seconds: seldate.second,
        microseconds: seldate.microsecond));

    switch (selectedTime) {
      case '09:00 AM':
        seldate = seldate.add(Duration(hours: 9));
        break;
      case '10:00 AM':
        seldate = seldate.add(Duration(hours: 10));
        break;
      case '11:00 AM':
        seldate = seldate.add(Duration(hours: 11));
        break;
      case '12:00 PM':
        seldate = seldate.add(Duration(hours: 12));
        break;
      case '02:00 PM':
        seldate = seldate.add(Duration(hours: 14));
        break;
      case '03:00 PM':
        seldate = seldate.add(Duration(hours: 15));
        break;
      case '04:00 PM':
        seldate = seldate.add(Duration(hours: 16));
        break;
      case '05:00 PM':
        seldate = seldate.add(Duration(hours: 17));
        break;
    }
    print(DateFormat('MM/dd/yyyy hh:mm a').format(seldate));
  }

  List<String> time = [
    '09:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '02:00 PM',
    '03:00 PM',
    '04:00 PM',
    '05:00 PM'
  ];

  List<String> timeAr = [
    '09:00 صباحا',
    '10:00 صباحا',
    '11:00 صباحا',
    '12:00 مساء',
    '02:00 مساء',
    '03:00 مساء',
    '04:00 مساء',
    '05:00 مساء'
  ];

  selectedP(index, String lang) {
    selectedTimeFormated = lang == 'en' ? time[index] : timeAr[index];
    selectedTime = time[index];

    notifyListeners();
  }

  assignDate(DateTime date, events) {
    print('sssssssssssssssss');
    print(date.weekday);
    switch (date.weekday) {
      case 0:
      case 7:
        selectedWeekDay = 'Sun';
        break;
      case 1:
        selectedWeekDay = 'Mon';
        break;
      case 2:
        selectedWeekDay = 'Tue';
        break;
      case 3:
        selectedWeekDay = 'Wed';
        break;
      case 4:
        selectedWeekDay = 'Thu';
        break;
      case 5:
        selectedWeekDay = 'Fri';
        break;
      case 6:
        selectedWeekDay = 'Sat';
        break;
    }
    // print(selectedWeekDay);
    switch (date.month) {
      case 1:
        selectedMonth = "January";
        break;
      case 2:
        selectedMonth = "February";
        break;
      case 3:
        selectedMonth = "March";
        break;
      case 4:
        selectedMonth = "April";
        break;
      case 5:
        selectedMonth = "May";
        break;
      case 6:
        selectedMonth = "June";
        break;
      case 7:
        selectedMonth = "July";
        break;
      case 8:
        selectedMonth = "August";
        break;
      case 9:
        selectedMonth = "September";
        break;
      case 10:
        selectedMonth = "October";
        break;
      case 11:
        selectedMonth = "November";
        break;
      case 12:
        selectedMonth = "December";
        break;
    }
    seldate = date;

    selectedDay = date.day.toString();
    selectedDate =
        "$selectedMonth" + " , " + "$selectedWeekDay" + " , " + "$selectedDay";
  }
}
