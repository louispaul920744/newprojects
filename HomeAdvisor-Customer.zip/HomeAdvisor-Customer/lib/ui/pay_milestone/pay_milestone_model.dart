class MileStoneModel {
  String name;
  String date;

  String status;
  String price;
  MileStoneModel({this.name, this.date, this.price, this.status});
}

class MileStone {
  int count;
  var next;
  var previous;
  List<Results> results;

  MileStone({this.count, this.next, this.previous, this.results});

  MileStone.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = new List<Results>();
      json['results'].forEach((v) {
        results.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.results != null) {
      data['results'] = this.results.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Results {
  int id;
  Vendor vendor;
  int order;
  String amount;
  var schedule;
  String duration;
  var startingDate;
  String warranty;
  int milestones;
  bool isAdvance;
  String milestonePercentage;
  String advancePercentage;
  String advanceAmount;
  bool advancePaid;
  bool accepted;
  bool vendorAgree;
  bool rejected;
  List<Milestone> milestone;

  Results(
      {this.id,
      this.vendor,
      this.order,
      this.amount,
      this.schedule,
      this.duration,
      this.startingDate,
      this.warranty,
      this.milestones,
      this.isAdvance,
      this.milestonePercentage,
      this.advancePercentage,
      this.advanceAmount,
      this.advancePaid,
      this.accepted,
      this.vendorAgree,
      this.rejected,
      this.milestone});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    vendor =
        json['vendor'] != null ? new Vendor.fromJson(json['vendor']) : null;
    order = json['order'];
    amount = json['amount'];
    schedule = json['schedule'];
    duration = json['duration'];
    startingDate = json['starting_date'];
    warranty = json['warranty'];
    milestones = json['milestones'];
    isAdvance = json['is_advance'];
    milestonePercentage = json['milestone_percentage'];
    advancePercentage = json['advance_percentage'];
    advanceAmount = json['advance_amount'];
    advancePaid = json['advance_paid'];
    accepted = json['accepted'];
    vendorAgree = json['vendor_agree'];
    rejected = json['rejected'];
    if (json['milestone'] != null) {
      milestone = new List<Milestone>();
      json['milestone'].forEach((v) {
        milestone.add(new Milestone.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.vendor != null) {
      data['vendor'] = this.vendor.toJson();
    }
    data['order'] = this.order;
    data['amount'] = this.amount;
    data['schedule'] = this.schedule;
    data['duration'] = this.duration;
    data['starting_date'] = this.startingDate;
    data['warranty'] = this.warranty;
    data['milestones'] = this.milestones;
    data['is_advance'] = this.isAdvance;
    data['milestone_percentage'] = this.milestonePercentage;
    data['advance_percentage'] = this.advancePercentage;
    data['advance_amount'] = this.advanceAmount;
    data['advance_paid'] = this.advancePaid;
    data['accepted'] = this.accepted;
    data['vendor_agree'] = this.vendorAgree;
    data['rejected'] = this.rejected;
    if (this.milestone != null) {
      data['milestone'] = this.milestone.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Vendor {
  String vendorName;
  int id;
  int avgResponseTime;
  int rating;
  String profileUrl;

  Vendor(
      {this.vendorName,
      this.id,
      this.avgResponseTime,
      this.rating,
      this.profileUrl});

  Vendor.fromJson(Map<String, dynamic> json) {
    vendorName = json['vendor_name'];
    id = json['id'];
    avgResponseTime = json['avg_response_time'];
    rating = json['rating'];
    profileUrl = json['profile_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['vendor_name'] = this.vendorName;
    data['id'] = this.id;
    data['avg_response_time'] = this.avgResponseTime;
    data['rating'] = this.rating;
    data['profile_url'] = this.profileUrl;
    return data;
  }
}

class Milestone {
  int id;
  String name;
  int quote;
  int order;
  String percentage;
  String description;
  var date;
  String status;
  bool paid;
  String amount;
  bool verified;
  bool requested;

  Milestone(
      {this.id,
      this.name,
      this.quote,
      this.order,
      this.percentage,
      this.description,
      this.date,
      this.status,
      this.paid,
      this.amount,
      this.verified,
      this.requested});

  Milestone.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    quote = json['quote'];
    order = json['order'];
    percentage = json['percentage'];
    description = json['description'];
    date = json['date'];
    status = json['status'];
    paid = json['paid'];
    amount = json['amount'];
    verified = json['verified'];
    requested = json['requested'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['quote'] = this.quote;
    data['order'] = this.order;
    data['percentage'] = this.percentage;
    data['description'] = this.description;
    data['date'] = this.date;
    data['status'] = this.status;
    data['paid'] = this.paid;
    data['amount'] = this.amount;
    data['verified'] = this.verified;
    data['requested'] = this.requested;
    return data;
  }
}
