import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/pay_milestone/pay_milestone_model.dart';
import 'package:stacked/stacked.dart';

class PayMileStoneViewModel extends BaseViewModel {
  List<MileStoneModel> list = [
    MileStoneModel(
        name: "Advance Pay (10 %)",
        date: "01-10-2020",
        status: "Paid",
        price: "125 QAR"),
    MileStoneModel(
        name: "MileStone 1 (20 %)",
        date: "01-10-2020",
        status: "Paid",
        price: "125 QAR"),
    MileStoneModel(
        name: "MileStone 2 (30 %)",
        date: "01-10-2020",
        status: "",
        price: "125 QAR"),
    MileStoneModel(
        name: "MileStone 3 (40 %)",
        date: "01-10-2020",
        status: "",
        price: "125 QAR")
  ];

  UserService _userService = locator<UserService>();

  bool _isLoading = false;
  List<Results> _listOfMilestone = [];

  bool get isLoading => _isLoading;
  List<Results> get listOfMilestone => _listOfMilestone;

  set isLoading(bool status) {
    _isLoading = status;
    notifyListeners();
  }

  Future<void> payMileStone(Milestone pay) async {
    await APIServices.payMileStone(_userService.token, pay);
  }

  Future<void> getMileStone(String orderId) async {
    isLoading = true;
    MileStone mileStone =
        await APIServices.getMilestone(_userService.token, orderId);
    if (mileStone.results.isNotEmpty) {
      _listOfMilestone = mileStone.results;
    } else {
      _listOfMilestone = [];
    }
    isLoading = false;
  }
}
