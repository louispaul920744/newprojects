class NotificationPageModel {
  String noti;
  String date;
  String time;
  String image;
  NotificationPageModel({this.date, this.noti, this.time, this.image});
}

class Notification {
  int count;
  String next;
  var previous;
  List<Results> results;

  Notification({this.count, this.next, this.previous, this.results});

  Notification.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = new List<Results>();
      json['results'].forEach((v) {
        results.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.results != null) {
      data['results'] = this.results.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Results {
  int id;
  String url;
  String notificationType;
  String icon;
  String header;
  String headerAr;
  String body;
  String bodyAr;
  bool isRead;
  var extraUrl;
  String createdAt;

  Results(
      {this.id,
      this.url,
      this.notificationType,
      this.icon,
      this.header,
      this.headerAr,
      this.body,
      this.bodyAr,
      this.isRead,
      this.extraUrl,
      this.createdAt});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    url = json['url'];
    notificationType = json['notification_type'];
    icon = json['icon'];
    header = json['header'];
    headerAr = json['header_ar'];
    body = json['body'];
    bodyAr = json['body_ar'];
    isRead = json['is_read'];
    extraUrl = json['extra_url'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['url'] = this.url;
    data['notification_type'] = this.notificationType;
    data['icon'] = this.icon;
    data['header'] = this.header;
    data['header_ar'] = this.headerAr;
    data['body'] = this.body;
    data['body_ar'] = this.bodyAr;
    data['is_read'] = this.isRead;
    data['extra_url'] = this.extraUrl;
    data['created_at'] = this.createdAt;
    return data;
  }
}
