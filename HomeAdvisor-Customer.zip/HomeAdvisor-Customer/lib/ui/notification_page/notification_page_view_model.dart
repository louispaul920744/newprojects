import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:stacked/stacked.dart';
import 'package:home_advisor/ui/notification_page/notification_page_model.dart';

class NotificationPageViewModel extends BaseViewModel {
  String _token;
  UserService _userService = locator<UserService>();
  List<Results> _notifications = [];
  Notification _notification;
  bool _isLoaded = false;
  bool _isEmpty = false;
  bool get isLoaded => _isLoaded;
  List<Results> get notifications => _notifications;
  bool get isEmpty => _isEmpty;

  set isEmpty(bool isEmpty) {
    _isEmpty = isEmpty;
    notifyListeners();
  }

  set isLoaded(bool loaded) {
    _isLoaded = loaded;
    notifyListeners();
  }

  String setToken() {
    _token = _userService.token;
  }

  void init() async {
    setToken();
    getNotification();
  }

  List<int> updateNotificationStatus() {
    List<int> notificationList = [];
    _notification.results.forEach((element) {
      if (element.isRead == false) {
        notificationList.add(element.id.toInt());
      }
    });
    return notificationList;
  }

  Future getNotification() async {
    List<int> notificationList = [];
    isLoaded = true;
    _notification = await APIServices.getNotification(_token);
    if (_notification.results.isNotEmpty) {
      _notifications = _notification.results;
      notificationList = updateNotificationStatus();
      if (notificationList.isNotEmpty) {
        await APIServices.postNotificationStatus(_token, notificationList);
      }
      isLoaded = false;
    } else {
      isEmpty = true;
      isLoaded = false;
    }
  }
}
