import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/notification_page/notification_page_view_model.dart';
import 'package:home_advisor/ui/widgets/notification_card.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';
import 'package:timeago/timeago.dart' as timeago;

class NotificationPage extends StatelessWidget {
  static const String id = "NotificationPage";
  bool isVisited;
  NotificationPage({this.isVisited});
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<NotificationPageViewModel>.reactive(
        onModelReady: (model) {
          isVisited = true;
          model.init();
        },
        viewModelBuilder: () => NotificationPageViewModel(),
        builder: (context, model, child) => Scaffold(
              backgroundColor: Colors.white,
              appBar: AppBar(
                toolbarHeight: 110.h,
                actions: [
                  Container(
                    margin: EdgeInsets.only(right: 5),
                    child:
                        /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/

                        Text(''),
                  )
                ],
                leadingWidth: double.infinity,
                leading: Column(
                  children: [
                    Container(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(
                            context,
                            isVisited,
                          );
                        },
                        child: Row(
                          children: [
                            Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                            Text(
                              language.lang == 'en' ? 'Go Back' : "عد",
                              style: AppTextStyles.s1(Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                flexibleSpace: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.06,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          language.lang == 'en' ? "NOTIFICATIONS" : "إشعارات",
                          style: AppTextStyles.textStyle(
                              color: Colors.white,
                              size: 30.f,
                              fontType: FontType.regular),
                        ),
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                        AppColor.blGradient2,
                        AppColor.blGradient1
                      ])),
                ),
                elevation: 1,
              ),
              body: model.isLoaded
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : model.isEmpty
                      ? Center(
                          child: Text("No notifications"),
                        )
                      : Container(
                          color: Colors.white,
                          child: ListView.builder(
                            primary: false,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              print(DateTime.parse(model.notifications
                                  .elementAt(index)
                                  .createdAt));
                              print(Helper.timeAgoSinceDate(model.notifications
                                  .elementAt(index)
                                  .createdAt));
                              return NotificationCard(
                                date: timeago.format(
                                    DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                                        .parse((model.notifications
                                            .elementAt(index)
                                            .createdAt))),
                                image:
                                    model.notifications.elementAt(index).icon,
                                noti:
                                    model.notifications.elementAt(index).header,
                                model: model.notifications.elementAt(index),
                                time: DateFormat('hh:mm').format(DateTime.parse(
                                    model.notifications
                                        .elementAt(index)
                                        .createdAt)),
                              );
                            },
                            itemCount: model.notifications.length,
                          ),
                        ),
            ));
  }
}
