import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme//screen_util-extension.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:home_advisor/core/services/language_service.dart';
import '../../app_theme/app_colors.dart';
import '../../app_theme/text_styles.dart';
import 'chatlist_viewmodel.dart';
import 'chatlisttile.dart';

class ChatList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<ChatListModel>.reactive(
      builder: (context, chat, child) => Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.square(100.h),
          child: AppBar(
            leading: SizedBox(),
            flexibleSpace: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                colors: [AppColor.blGradient2, AppColor.blGradient1],
                begin: Alignment.bottomLeft,
                end: Alignment.topRight,
              )),
              child: Padding(
                padding: EdgeInsets.only(left: 25.w),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 40.h,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, HomePageView.id);
                      },
                      child: Row(
                        children: [
                          Icon(Icons.arrow_back_outlined, color: Colors.white),
                          Text(
                            language.lang == 'en' ? 'Go Back' : "عد",
                            style: AppTextStyles.textStyle(
                              size: 20.f,
                              color: Colors.white,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 18.h,
                    ),
                    Text(
                      language.lang == "en" ? 'Chat' : "دردشة",
                      style: TextStyle(
                        fontSize: 30.f,
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
        body: Container(
          child: Container(
            child: ListView.builder(
                itemCount: chat.chatList.length,
                itemBuilder: (context, index) {
                  return ChatListViewItem(
                    index: index,
                    hasUnreadMessage: chat.chatList[index]["hasUnread"],
                    image: AssetImage(chat.chatList[index]["image"]),
                    lastMessage: chat.chatList[index]["lastMsg"],
                    name: chat.chatList[index]["name"],
                    newMessageCount: chat.chatList[index]["unRead"],
                    time: chat.chatList[index]["time"],
                  );
                }),
          ),
        ),
      ),
      viewModelBuilder: () => ChatListModel(),
    );
  }
}
