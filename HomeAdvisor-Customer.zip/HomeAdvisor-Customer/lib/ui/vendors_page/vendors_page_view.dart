import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:home_advisor/ui/aggreement_page/agreement_page_dummy.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_model.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_view_model.dart';
import 'package:home_advisor/ui/widgets/vendors_card.dart';
import 'package:stacked/stacked.dart';

class VendorsPage extends StatelessWidget {
  static const String id = "VendorsPage";

  @override
  Widget build(BuildContext context) {
    final VendorQuoteDetails args = ModalRoute.of(context).settings.arguments;

    return ViewModelBuilder<VendorsPageViewModel>.reactive(
      onModelReady: (model) {
        model.init(args);
      },
      viewModelBuilder: () => VendorsPageViewModel(),
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          toolbarHeight: 66,
          actions: [
            Container(
              margin: EdgeInsets.only(right: 5),
              child:
                  /*Icon(
                      Icons.search_outlined,
                      color: Colors.white,
                    )*/
                  Text(''),
            )
          ],
          leadingWidth: 90,
          leading: Column(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  child: Row(
                    children: [
                      Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      ),
                      Text(
                        "Go Back",
                        style: AppTextStyles.textStyle(size: 11),
                      )
                    ],
                  ),
                ),
              ),
              Text(
                "Quote",
                style: AppTextStyles.textStyle(
                    size: 18, fontType: FontType.regular),
              )
            ],
          ),
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [AppColor.blGradient2, AppColor.blGradient1])),
          ),
          elevation: 1,
        ),
        body: model.isLoaded == true
            ? Center(
                child: CircularProgressIndicator(),
              )
            : model.isEmpty == true
                ? Center(
                    child: Text("No vendor Quotes"),
                  )
                : Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(10.0),
                    child: ListView(
                      children: [
                        Text(
                          "${args.showingID} ${args.type}",
                          style: AppTextStyles.textStyle(
                              color: AppColor.blCommon, size: 16),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 10,
                            ),
                            Text(" ${Helper.formatDate(args.date)}",
                                style: AppTextStyles.textStyle(
                                    color: AppColor.blCommon)),
                            SizedBox(
                              height: 10,
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Directionality(
                                textDirection: TextDirection.ltr,
                                child: Text(
                                  "${args.time}",
                                  style: AppTextStyles.textStyle(
                                      color: AppColor.blCommon),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              args.location ?? '',
                              style: AppTextStyles.textStyle(
                                color: AppColor.blCommon,
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        ListView.builder(
                          primary: false,
                          shrinkWrap: true,
                          itemBuilder: (mContext, index) {
                            return VendorsCard(
                              name: model.vendorQuotes[index].vendor.vendorName,
                              amount: model.vendorQuotes[index].amount,
                              profileUrl:
                                  model.vendorQuotes[index].vendor.profileUrl,
                              quoteId: model.vendorQuotes[index].id,
                              duration: model.vendorQuotes[index].duration,
                              warranty: model.vendorQuotes[index].warranty,
                              model: model.vendorQuotes[index],
                              handleConfirm: (status) async {
                                print(model.vendorQuotes[index].id);
                                model.isLoaded = true;

                                String aggrmnt =
                                    await model.getVendorUserAgreement();
                                bool isAccepted =
                                    await Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => AgreementPageDummy(
                                        agreement: aggrmnt,
                                        tittle:
                                            'Agreement with Vendor and user'),
                                  ),
                                );
                                model.isLoaded = false;

                                if (isAccepted == null || !isAccepted) {
                                  Fluttertoast.showToast(
                                    msg: 'Please accept the agreement',
                                  );
                                  return;
                                }

                                model
                                    .handleConfirm(
                                        model.vendorQuotes[index].id, status)
                                    .then((value) {
                                  Future.delayed(Duration(milliseconds: 300))
                                      .then((value) {
                                    model.init(args);

                                    Navigator.of(context).pop();
                                  });
                                });
                              },
                              handleReject: (String reason) {
                                print(reason);
                                model
                                    .handleReject(
                                        model.vendorQuotes[index].id, reason)
                                    .then((value) => Future.delayed(
                                            Duration(milliseconds: 300))
                                        .then((value) =>
                                            Navigator.of(context).pop()));
                              },
                              handlePay: () async {
                                model.isLoaded = true;

                                String aggrmnt =
                                    await model.getAdminUserAgreement();

                                bool isAccepted =
                                    await Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => AgreementPageDummy(
                                      agreement: aggrmnt,
                                      tittle: 'Agreement with Admin and user',
                                    ),
                                  ),
                                );
                                model.isLoaded = false;

                                if (isAccepted == null || !isAccepted) {
                                  Fluttertoast.showToast(
                                    msg: 'Please accept the agreement',
                                  );
                                  return;
                                }

                                print(model.vendorQuotes[index].id);
                                model
                                    .handleAdvancePay(
                                        args.orderId.replaceAll('#', ''),
                                        model.vendorQuotes[index].advanceAmount)
                                    .then((value) => Future.delayed(
                                                Duration(milliseconds: 300))
                                            .then((value) {
                                          model.init(args);
                                          Navigator.of(context).pop();
                                        }));
                              },
                            );
                          },
                          itemCount: model.vendorQuotes.length,
                        )
                      ],
                    ),
                  ),
      ),
    );
  }
}
