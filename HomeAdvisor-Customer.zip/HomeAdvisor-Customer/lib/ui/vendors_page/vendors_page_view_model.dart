import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_model.dart';
import 'package:stacked/stacked.dart';

class VendorsPageViewModel extends BaseViewModel {
  String _token;
  UserService _userService = locator<UserService>();
  List<Results> _vendors = [];
  bool _isLoaded = false;
  bool _isEmpty = false;
  bool get isLoaded => _isLoaded;
  List<Results> get vendorQuotes => _vendors;
  bool get isEmpty => _isEmpty;

  set isEmpty(bool isEmpty) {
    _isEmpty = isEmpty;
    notifyListeners();
  }

  set isLoaded(bool loaded) {
    _isLoaded = loaded;
    notifyListeners();
  }

  void init(VendorQuoteDetails args) async {
    _token = _userService.token;
    getVendorQuotes(args);
  }

  Future getVendorQuotes(VendorQuoteDetails args) async {
    isLoaded = true;
    VendorQuote vendorQuote = await APIServices.getVendorQuote(
        _token, args.orderId?.replaceFirst("#", ''));
    isLoaded = false;
    if (vendorQuote.results != null && vendorQuote.results.isNotEmpty) {
      isEmpty = false;
      _vendors = vendorQuote.results;
    } else {
      isEmpty = true;
    }
  }

  Future handleConfirm(int quoteId, bool status) async {
    if (status) {
      isLoaded = true;
      bool isConfirmed = await APIServices.confirmQuote(quoteId, _token);
      isLoaded = false;
      if (isConfirmed) {
        Fluttertoast.showToast(msg: 'Please wait for vendor confirmation');
      } else {
        Fluttertoast.showToast(msg: "Something went wrong\n please try again");
      }
    }
  }

  Future getVendorUserAgreement() async {
    String agreement = await APIServices.getVendorUserAgreement(
      _userService.token,
    );
    return agreement;
  }

  Future getAdminUserAgreement() async {
    String agreement = await APIServices.getAdminUserAgreement(
      _userService.token,
    );
    return agreement;
  }

  Future handleReject(int quoteId, String reason) async {
    isLoaded = true;
    bool isConfirmed = await APIServices.rejectQuote(quoteId, _token, reason);
    isLoaded = false;
    if (isConfirmed) {
      Fluttertoast.showToast(msg: "You have rejected the quote");
    } else {
      Fluttertoast.showToast(msg: "Something went wrong\n please try again");
    }
  }

  Future handleAdvancePay(String quoteId, String amount) async {
    print('handleAdvancePay');
    isLoaded = true;
    bool isConfirmed = await APIServices.payQuote(quoteId, _token, amount);
    isLoaded = false;
    if (isConfirmed) {
      Fluttertoast.showToast(msg: "Your request successfully submitted");
    } else {
      Fluttertoast.showToast(msg: "Something went wrong\n please try again");
    }
  }
}
