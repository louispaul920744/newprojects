class VendorsPageModel {
  String name;
  String amount;
  String quote;

  VendorsPageModel({this.name, this.amount, this.quote});
}

class VendorQuote {
  int count;
  String next;
  var previous;
  var order;
  List<Results> results;

  VendorQuote({this.count, this.next, this.previous, this.results});

  VendorQuote.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    next = json['next'];
    previous = json['previous'];
    order = json['order'];
    if (json['results'] != null) {
      results = new List<Results>();
      json['results'].forEach((v) {
        results.add(new Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    data['next'] = this.next;
    data['previous'] = this.previous;
    if (this.results != null) {
      data['results'] = this.results.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Results {
  int id;
  Vendor vendor;
  int order;
  String amount;
  int schedule;
  String duration;
  bool vendor_agree;
  var startingDate;
  String warranty;
  int milestones;
  String milestonePercentage;
  String advancePercentage;
  String advanceAmount;
  bool advancePaid;
  bool is_advance;
  bool accepted;
  bool rejected;
  List<dynamic> milestone;

  Results(
      {this.id,
      this.vendor,
      this.order,
      this.amount,
      this.schedule,
      this.is_advance,
      this.vendor_agree,
      this.duration,
      this.startingDate,
      this.warranty,
      this.milestones,
      this.milestonePercentage,
      this.advancePercentage,
      this.advanceAmount,
      this.advancePaid,
      this.accepted,
      this.rejected,
      this.milestone});

  Results.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    vendor =
        json['vendor'] != null ? new Vendor.fromJson(json['vendor']) : null;
    order = json['order'];
    amount = json['amount'];
    schedule = json['schedule'];
    duration = json['duration'];
    is_advance = json['is_advance'];
    vendor_agree = json['vendor_agree'];
    startingDate = json['starting_date'];
    warranty = json['warranty'];
    milestones = json['milestones'];
    milestonePercentage = json['milestone_percentage'];
    advancePercentage = json['advance_percentage'];
    advanceAmount = json['advance_amount'];
    advancePaid = json['advance_paid'];
    accepted = json['accepted'];
    rejected = json['rejected'];
    // if (json['milestone'] != null) {
    //   milestone = new List<var>();
    //   json['milestone'].forEach((v) {
    //     milestone.add(new var.fromJson(v));
    //   });
    // }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.vendor != null) {
      data['vendor'] = this.vendor.toJson();
    }
    data['order'] = this.order;
    data['amount'] = this.amount;
    data['schedule'] = this.schedule;
    data['duration'] = this.duration;
    data['vendor_agree'] = this.vendor_agree;
    data['starting_date'] = this.startingDate;
    data['warranty'] = this.warranty;
    data['milestones'] = this.milestones;
    data['milestone_percentage'] = this.milestonePercentage;
    data['advance_percentage'] = this.advancePercentage;
    data['advance_amount'] = this.advanceAmount;
    data['advance_paid'] = this.advancePaid;
    data['accepted'] = this.accepted;
    data['rejected'] = this.rejected;
    // if (this.milestone != null) {
    //   data['milestone'] = this.milestone.map((v) => v.toJson()).toList();
    // }
    return data;
  }
}

class Vendor {
  String vendorName;
  int id;
  int avgResponseTime;
  int rating;
  String profileUrl;

  Vendor(
      {this.vendorName,
      this.id,
      this.avgResponseTime,
      this.rating,
      this.profileUrl});

  Vendor.fromJson(Map<String, dynamic> json) {
    vendorName = json['vendor_name'];
    id = json['id'];
    avgResponseTime = json['avg_response_time'];
    rating = json['rating'];
    profileUrl = json['profile_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['vendor_name'] = this.vendorName;
    data['id'] = this.id;
    data['avg_response_time'] = this.avgResponseTime;
    data['rating'] = this.rating;
    data['profile_url'] = this.profileUrl;
    return data;
  }
}

class VendorQuoteDetails {
  String orderId;
  String type;
  String date;
  String time;
  String location;
  String showingID;

  VendorQuoteDetails({
    this.date,
    this.location,
    this.orderId,
    this.time,
    this.type,
    this.showingID,
  });
}
