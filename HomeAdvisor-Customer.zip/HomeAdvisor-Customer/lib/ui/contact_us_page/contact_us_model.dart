/// count : 1
/// next : ""
/// previous : ""
/// results : [{"id":1,"description_en":"<p><strong>Contact Us</strong></p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>","description_ar":"<p><strong>ما هو لوريم إيبسوم؟</strong></p>\r\n\r\n<p>لوريم إيبسوم هو ببساطة نص شكلي يستخدم في صناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من النوع وتدافعت عليه لعمل كتاب عينة. لقد نجت ليس فقط خمسة قرون ، ولكن أيضًا القفزة في التنضيد الإلكتروني ، وظلت دون تغيير جوهري. تم نشره في الستينيات من القرن الماضي بإصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخرًا مع برامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.</p>","image":"https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-1.jpg"}]

class ContactUsModel {
  int _count;
  String _next;
  String _previous;
  List<Results> _results;

  int get count => _count;
  String get next => _next;
  String get previous => _previous;
  List<Results> get results => _results;

  ContactUsModel(
      {int count, String next, String previous, List<Results> results}) {
    _count = count;
    _next = next;
    _previous = previous;
    _results = results;
  }

  ContactUsModel.fromJson(dynamic json) {
    _count = json["count"];
    _next = json["next"];
    _previous = json["previous"];
    if (json["results"] != null) {
      _results = [];
      json["results"].forEach((v) {
        _results.add(Results.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["count"] = _count;
    map["next"] = _next;
    map["previous"] = _previous;
    if (_results != null) {
      map["results"] = _results.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 1
/// description_en : "<p><strong>Contact Us</strong></p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>"
/// description_ar : "<p><strong>ما هو لوريم إيبسوم؟</strong></p>\r\n\r\n<p>لوريم إيبسوم هو ببساطة نص شكلي يستخدم في صناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من النوع وتدافعت عليه لعمل كتاب عينة. لقد نجت ليس فقط خمسة قرون ، ولكن أيضًا القفزة في التنضيد الإلكتروني ، وظلت دون تغيير جوهري. تم نشره في الستينيات من القرن الماضي بإصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخرًا مع برامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.</p>"
/// image : "https://home-advisor.s3.amazonaws.com/media/orders/images/carousel-1.jpg"

class Results {
  int _id;
  String _descriptionEn;
  String _descriptionAr;
  String _image;

  int get id => _id;
  String get descriptionEn => _descriptionEn;
  String get descriptionAr => _descriptionAr;
  String get image => _image;

  Results({int id, String descriptionEn, String descriptionAr, String image}) {
    _id = id;
    _descriptionEn = descriptionEn;
    _descriptionAr = descriptionAr;
    _image = image;
  }

  Results.fromJson(dynamic json) {
    _id = json["id"];
    _descriptionEn = json["description_en"];
    _descriptionAr = json["description_ar"];
    _image = json["image"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["description_en"] = _descriptionEn;
    map["description_ar"] = _descriptionAr;
    map["image"] = _image;
    return map;
  }
}
