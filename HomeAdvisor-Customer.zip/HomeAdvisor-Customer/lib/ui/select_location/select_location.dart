import 'dart:async';

import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:home_advisor/core/services/api_services.dart';

class SelectLocation extends StatefulWidget {
  static const id = "11";
  final lang;
  SelectLocation(this.lang);

  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<SelectLocation> {
  var gKey = GlobalKey<ScaffoldState>();
  final GlobalKey<ScaffoldState> _formKey = GlobalKey<ScaffoldState>();

  bool _isLoading = false;
  TextEditingController _officialNameController;
  TextEditingController _displayNameController;
  TextEditingController _uploadLogo;
  TextEditingController _phoneNumberController;
  TextEditingController _businessAddressController;
  TextEditingController _areaBusinessController;

  List<CheckBoxModal> coverages = [
    CheckBoxModal(name: 'Al Shamal'),
    CheckBoxModal(name: 'Al Khor'),
    CheckBoxModal(name: 'Al Shahaniya'),
    CheckBoxModal(name: 'Al Daayen'),
    CheckBoxModal(name: 'Doha'),
    CheckBoxModal(name: 'Al Rayyan'),
    CheckBoxModal(name: 'Al Wakrah')
  ];
  List<CheckBoxModal> categories = [
    CheckBoxModal(name: 'Wholesaler'),
    CheckBoxModal(name: 'Promotion'),
    CheckBoxModal(name: 'Fit Outs'),
    CheckBoxModal(name: 'Build Materials'),
    CheckBoxModal(name: 'Inspection'),
    CheckBoxModal(name: 'Pest Control'),
    CheckBoxModal(name: 'Engineering'),
    CheckBoxModal(name: 'Maintenance'),
  ];

  String _phoneCode = "+91";
  CountryCode phoneCountryCode;
  bool _validatemobile = false;

  bool isOffline = false;

  @override
  Widget build(BuildContext context) {
    // _isLoading=false;
    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);
    return Scaffold(
        key: gKey,
        body: SingleChildScrollView(
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        margin: EdgeInsets.only(
                          left: 8,
                          top: 4,
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.arrow_back),
                            Text(
                              'Go Back',
                              style: TextStyle(
                                  color: Color(0xFF14287B),
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      alignment: Alignment.bottomCenter,
                      padding: EdgeInsets.all(4),
                      height: 76.h,
                      child: Image.asset("assets/1/logo.png"),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Container(
                  height: 90.h,
                  width: double.infinity,
                  color: Color(0xFF65BDF7),
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.only(left: 24, top: 8, bottom: 8),
                  child: Text(
                    "Select your location",
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                FutureBuilder(
                  future: APIServices().getLocationAndCategories(),
                  builder: (context, snapshot) {
                    print('_RegisterState.build');

                    if (snapshot.hasData && snapshot.data != null) {
                      print('_RegisterState.build sss');
                      print(snapshot.data);

                      return Wrap(
                        children: [
                          ...snapshot.data.map((e) => Container(
                                margin: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 10),
                                child: InkWell(
                                  onTap: () => Navigator.of(context).pop(e),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(14.0),
                                        child: Image.network(
                                          e['icon'] ?? '',
                                          width: 100,
                                          height: 100,
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 6,
                                      ),
                                      Text(
                                        e['city'],
                                        style: TextStyle(
                                            color: Color(0xFF213482),
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ))
                        ],
                      );
                    }
                    if (snapshot.hasError) return Text('Can\'t fetch Location');
                    return CircularProgressIndicator();
                  },
                ),
              ],
            ),
          ),
        ));
  }

  Container buildCoverage(String title, List coverages) {
    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
                fontSize: 16,
                color: Color(0xFF14287B),
                fontWeight: FontWeight.w500),
          ),
          Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(left: 14),
            child: Wrap(
              direction: Axis.horizontal,
              children: [
                ...coverages.map(
                  (e) => Container(
                    width: 150,
                    child: Row(
                      children: [
                        Container(
                          width: 100,
                          child: Text(
                            e.name,
                            style: TextStyle(
                                color: Color(0xFF14287B),
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                        Checkbox(
                          value: e.isChecked,
                          onChanged: (value) {
                            setState(() {
                              e.isChecked = !e.isChecked;
                            });
                          },
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  _valid() {
    if (_displayNameController.text.trim().isEmpty) {
      // Utils.showSnackBar(gKey, L.of(context).invalidUsername);
      return false;
    }

    if (_officialNameController.text.trim().isEmpty ||
        !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
            .hasMatch(_officialNameController.text.trim())) {
      // Utils.showSnackBar(gKey, L.of(context).invalidEmail);
      return false;
    }
    // if (_passwordController.text.isEmpty) {
    // //   Utils.showSnackBar(_formKey, invalidCrfNumber);
    //   return false;
    // }
    if (_businessAddressController.text.trim().isEmpty) {
      // Utils.showSnackBar(gKey, L.of(context).invalidBusinessAddress);
      return false;
    }

    if (_areaBusinessController.text.trim().isEmpty) {
      // Utils.showSnackBar(gKey, L.of(context).invalidAreaOfBusiness);
      return false;
    }
    if (_phoneNumberController.text.trim().isEmpty) {
      // Utils.showSnackBar(gKey, L.of(context).invalidPhoneNumberLength);
      return false;
    }
    return true;
  }

  @override
  void initState() {
    super.initState();

    _displayNameController = new TextEditingController();
    _officialNameController = new TextEditingController();
    _businessAddressController = new TextEditingController();
    _uploadLogo = new TextEditingController();

    _phoneNumberController = new TextEditingController();
    _areaBusinessController = new TextEditingController();
    //_zipController = TextEditingController();
  }

  void onSignUpButtonPressed() async {
    if (_valid()) {
      FocusScope.of(context).requestFocus(new FocusNode());

      if (isOffline) {
        // Utils.showSnackBar(_formKey, L.of(context).networkNotAvailable);
        return;
      }
      await _loginSMS(context);

//       var body = {
//         'display_name': _displayNameController.text,
//         'email': _emailController.text,
//         'password': _passwordController.text,
//         'business_address': _businessAddressController.text,
//         'phone_number': _phoneCode + _phoneNumberController.text,
//         'area_business': _areaBusinessController.text
//       };
//
//       print("bodyprint" + body.toString());
//
//       post(body: body).then((res) async {
//         print('hhhhh' + res.toString());
//         //   final String token = res['token'];
// //        final snackBar = SnackBar(content: Text(res['message'].toString()));
// //        gKey.currentState.showSnackBar(snackBar);
//         Future.delayed(Duration(milliseconds: 1500)).whenComplete(() async {});
//       });
    }
  }

  Widget buildLoadingView() {}

  void showLoading() {
    setState(() {
      _isLoading = true;
    });
  }

  void hideLoading() {
    setState(() {
      _isLoading = false;
    });
  }

  void connectionChanged(dynamic hasConnection) {
    setState(() {
      isOffline = !hasConnection;
    });
  }

//   Future<dynamic> post({var body}) async {
//     Map<String, String> headers = {
//       'Content-Type': 'application/json;charset=UTF-8',
//       'Charset': 'utf-8'
//     };
//     var response = await http.post('http://backend.homeadvisor.qa/auth/users/',
//         body: body);
//     print("gvg" + response.body.toString());
//     if (response.statusCode == 201) {
//       print(response.statusCode);
//       var responseJson = json.decode(response.body);
//
//       print(responseJson);
//       redirectToLoginScreen();
//       return responseJson;
//     } else {
//       setState(() {
//         final snackBar = SnackBar(
//             content: Text(
//                 'A user with this email address/phone number already exists'));
//         gKey.currentState.showSnackBar(snackBar);
//       });
//
//       // If that call was not successful, throw an error.
// //      throw Exception('Failed to load post');
//     }
//   }

  // void redirectToLoginScreen() {
  //   Navigator.of(_formKey.currentContext).pushReplacementNamed(login.id);
  // }

  Future<void> _loginSMS(context) async {}
}

class CheckBoxModal {
  String name;
  bool isChecked;

  CheckBoxModal({this.name, this.isChecked = false});
}
