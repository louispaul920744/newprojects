import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';
import 'package:stacked/stacked.dart';

class ProfileEditModel extends BaseViewModel {
  bool isLoading = false;
  bool isnameNull = true;
  bool islastName = true;

  UserService _userService = locator<UserService>();
  final _picker = ImagePicker();
  File _image;
  String logo = 'assets/logo.png';
  bool picSelected = false;
  ProfileModel get user => _userService.user;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  File get image => _image;

  void changeLoading() {
    isLoading = true;
    notifyListeners();
  }

  set image(File image) {
    _image = image;
    picSelected = true;
    notifyListeners();
  }

  Future<void> addPhoto() async {
    PickedFile _image = await _picker.getImage(
      source: ImageSource.gallery,
    );

    if (_image != null) {
      File pickedFile = File(_image.path);
      image = pickedFile;
    }
  }

  void updateAction(BuildContext context) async {
    if (formKey.currentState.validate()) {
      print(user.toJson());

      debugPrint('user.toJson()');
      debugPrint(user.toJson().toString());

      if (image != null) {
        await APIServices.updateProfileImage(
          image.path,
          basename(image.path),
          _userService.token,
        );
      }
      var response = await APIServices.updateProfile(
        user,
        _userService.token,
        isCompleteProfile: false,
      );
      if (response != null) {
        _userService.user = await _userService.getUser();
        showToast(
          context,
          message: "Updated Successfully",
        );
        Navigator.pop(context);
      }
    }
  }

  void showToast(BuildContext context, {@required message}) {
    Fluttertoast.showToast(msg: message);
  }
}
