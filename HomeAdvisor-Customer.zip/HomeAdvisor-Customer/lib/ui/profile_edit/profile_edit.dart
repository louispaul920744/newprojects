import 'package:cached_network_image/cached_network_image.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme//screen_util-extension.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/profile_edit/profile_editmodel.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class ProfileEdit extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return ViewModelBuilder<ProfileEditModel>.reactive(
        builder: (context, model, child) => Scaffold(
              appBar: AppBar(
                leading: SizedBox(),
                elevation: 0.w,
                backgroundColor: Colors.white,
                flexibleSpace: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          left: 30.0.w, right: 30.0.w, bottom: 10.w),
                      child: Image.asset(
                        '${model.logo}',
                        width: 150.w,
                      ),
                    ),
                  ],
                ),
                actions: [
                  IconButton(
                      icon: Icon(
                        Icons.search,
                        color: AppColor.blCommon,
                        size: 60.w,
                      ),
                      onPressed: () {})
                ],
              ),
              body: Stack(
                children: [
                  SingleChildScrollView(
                      child: Column(
                    children: [
                      Stack(
                        children: [
                          (model.picSelected == false &&
                                  model.user.photo == null)
                              ? InkWell(
                                  onTap: () {
                                    model.addPhoto();
                                  }, //Implement Image Picker
                                  child: Container(
                                    height: 430.h,
                                    color: Colors.grey,
                                    child: Center(
                                      child: Image.asset(
                                        'assets/user.webp',
                                        height: 100.h,
                                        width: 100.w,
                                      ),
                                    ),
                                  ),
                                )
                              : (model.user.photo != null &&
                                      model.picSelected == false)
                                  ? InkWell(
                                      onTap: () {
                                        model.addPhoto();
                                      },
                                      child: Container(
                                        height: 430.h,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        color: Colors.grey,
                                        child: Center(
                                          child: CachedNetworkImage(
                                            fit: BoxFit.fill,
                                            imageUrl: model.user.photo,
                                          ),
                                        ),
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () {
                                        model.addPhoto();
                                      },
                                      child: Container(
                                        height: 430.h,
                                        padding: EdgeInsets.all(1),
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            fit: BoxFit.cover,
                                            image: FileImage(model.image),
                                          ),
                                        ),
                                      ),
                                    ),
                          Padding(
                            padding: EdgeInsets.all(20.0.h),
                            child: Container(
                              child: InkWell(
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.arrow_back_outlined,
                                        color: Colors.white,
                                      ),
                                      Text(
                                        language.lang == 'en'
                                            ? 'Go Back'
                                            : "عد",
                                        style: TextStyle(color: Colors.white),
                                      )
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.pop(context);
                                  }),
                            ),
                          )
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.all(20.0.h),
                        child: Form(
                          key: model.formKey,
                          child: Column(
                            children: [
                              SizedBox(
                                height: 40.h,
                              ),
                              TextFormField(
                                initialValue: model.user.displayName,
                                onChanged: (value) {
                                  print(value);
                                  model.user.displayName =
                                      value.trim().replaceAll('â', '');
                                },
                                decoration: InputDecoration(
                                    border: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: AppColor.blCommon),
                                    ),
                                    hintText: language.lang == 'en'
                                        ? 'First Name'
                                        : "الاسم الاول",
                                    hintStyle:
                                        TextStyle(color: AppColor.blCommon)),
                                validator: (value) {
                                  if (value.isEmpty) {
                                    model.isnameNull = true;
                                    return language.lang == 'en'
                                        ? "First name is required"
                                        : "الإسم الأول مطلوب";
                                  } else {
                                    model.isnameNull = false;
                                    return null;
                                  }
                                },
                              ),
                              SizedBox(
                                height: 40.h,
                              ),
                              TextFormField(
                                initialValue: model.user.lastName,
                                onChanged: (value) => model.user.lastName =
                                    value.trim().replaceAll('â', ''),
                                decoration: InputDecoration(
                                    border: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: AppColor.blCommon),
                                    ),
                                    hintText: language.lang == 'en'
                                        ? 'Last Name'
                                        : "الكنية",
                                    hintStyle:
                                        TextStyle(color: AppColor.blCommon)),
                              ),
                              SizedBox(
                                height: 40.h,
                              ),
                              TextFormField(
                                initialValue: model.user.email,
                                onChanged: (value) =>
                                    model.user.email = value.trim(),
                                decoration: InputDecoration(
                                    border: UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: AppColor.blCommon,
                                      ),
                                    ),
                                    hintText: language.lang == 'en'
                                        ? 'Email'
                                        : "البريد الإلكتروني",
                                    hintStyle:
                                        TextStyle(color: AppColor.blCommon)),
                                validator: (value) {
                                  if (!EmailValidator.validate(value)) {
                                    model.isLoading = false;
                                    return language.lang == 'en'
                                        ? "E-mail is not valid"
                                        : "البريد الإلكتروني غير صالح";
                                  } else {
                                    model.changeLoading();

                                    return null;
                                  }
                                },
                              ),
                              SizedBox(
                                height: 40.h,
                              ),
                              FlatButton(
                                onPressed: () {
                                  model.updateAction(context);
                                },
                                child: Ink(
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          AppColor.rdGradient2,
                                          AppColor.rdGradient1
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ),
                                      borderRadius: BorderRadius.circular(5.0)),
                                  child: Container(
                                    constraints: BoxConstraints(
                                        maxWidth: 165.0, minHeight: 50.0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      language.lang == 'en'
                                          ? "UPDATE"
                                          : "تحديث",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 40.f,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  )),
                  (model.isLoading && !model.islastName && !model.isnameNull)
                      ? Center(
                          child: CircularProgressIndicator(
                            backgroundColor: AppColor.rdCommon,
                          ),
                        )
                      : SizedBox.shrink()
                ],
              ),
            ),
        viewModelBuilder: () => ProfileEditModel());
  }
}
