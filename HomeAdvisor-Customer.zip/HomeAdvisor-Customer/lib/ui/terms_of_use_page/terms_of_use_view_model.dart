import 'package:home_advisor/app/locator.dart';
import 'package:stacked/stacked.dart';
import 'package:home_advisor/core/services/user_service.dart';

class TermsOfUseViewModel extends BaseViewModel {
  String token;
  UserService _userService = locator<UserService>();

  String getToken() {
    token = _userService.token;
    return token;
  }
}
