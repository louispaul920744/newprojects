import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/chat_model/provider/user_provider.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'home_page_viewmodel.dart';

class HomePageView extends StatefulWidget {
  static const id = "HomePage";
  final int index;

  HomePageView({this.index = 0});

  @override
  _HomePageViewState createState() => _HomePageViewState();
}

class _HomePageViewState extends State<HomePageView> {
  UserProvider userProvider;

  @override
  void initState() {
    super.initState();

    SchedulerBinding.instance.addPostFrameCallback((_) async {
      userProvider = Provider.of<UserProvider>(context, listen: false);
      await userProvider.refreshUser();
    });
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> args = ModalRoute.of(context).settings.arguments;

    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    DateTime currentBackPressTime;
    Future<bool> onWillPop(model) {
      if (model.currentIndex == 0) {
        DateTime now = DateTime.now();
        if (currentBackPressTime == null ||
            now.difference(currentBackPressTime) > Duration(seconds: 2)) {
          currentBackPressTime = now;
          Fluttertoast.showToast(msg: 'Press again to exit');

          return Future.value(false);
        }
        SystemChannels.platform.invokeMethod('SystemNavigator.pop');

        return Future.value(true);
      } else if (model.currentIndex == 1) {
        model.setIndex(0);
      } else if (model.currentIndex == 2) {
        model.setIndex(1);
      }
      // else if (model.currentIndex == 3) {
      //   model.setIndex(2);
      // }
    }

    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);
    return ViewModelBuilder<HomePageViewModel>.reactive(
      builder: (context, model, child) => WillPopScope(
        onWillPop: () => onWillPop(model),
        child: Scaffold(
          key: model.scaffoldkey,
          body: Stack(
            fit: StackFit.expand,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 110.h),
                child: model.getViewForIndex(model.currentIndex),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 100.h,
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      InkWell(
                        onTap: () {
                          model.setIndex(0);
                        },
                        child: Column(
                          children: [
                            Icon(
                              Icons.home_outlined,
                              color: Color(0xFF14287B),
                              size: 38,
                            ),
                            Text(language.lang == 'en'
                                ? "Home"
                                : "الصفحة الرئيسية")
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          model.setIndex(1);
                        },
                        child: Column(
                          children: [
                            Image.asset(
                              model.orderIcon,
                              color: Color(0xFF14287B),
                              width: 38,
                              height: 38,
                            ),
                            Text(language.lang == 'en' ? "Orders" : "طلب")
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          model.setIndex(2);
                        },
                        child: Column(
                          children: [
                            Icon(
                              Icons.account_circle_outlined,
                              color: Color(0xFF14287B),
                              size: 38,
                            ),
                            Text(language.lang == 'en'
                                ? "Profile"
                                : "الملف الشخصي")
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
      viewModelBuilder: () => HomePageViewModel(),
      onModelReady: (model) {
        model.setPyaloaListner(language);

        model.setupFirebase(context);
        model.configureNotifications(context);

        if (args != null && args.isNotEmpty)
          Future.delayed(Duration(seconds: 1))
              .then((value) => model.handlemessages(args));

        if (widget.index != 0) {
          model.setIndex(widget.index);
        }
      },
    );
  }
}
