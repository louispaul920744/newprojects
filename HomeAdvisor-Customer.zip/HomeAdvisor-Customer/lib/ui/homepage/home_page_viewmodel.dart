import 'dart:convert';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:home_advisor/app/locator.dart';
import 'package:home_advisor/chat_model/models/user.dart';
import 'package:home_advisor/chat_model/screens/chatscreens/chat_screen.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/main_category/main_categ_view.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';
import 'package:home_advisor/ui/orders_page/orders_page_view.dart';
import 'package:home_advisor/ui/profile_view/profile_view.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';

class HomePageViewModel extends IndexTrackingViewModel {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();

  final UserService _userService = locator<UserService>();
  BuildContext context;
  final GlobalKey<ScaffoldState> scaffoldkey = new GlobalKey<ScaffoldState>();

  Future<bool> isTokenUpdated() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isUpdated = prefs.getBool('fcm') ?? false;
    return isUpdated;
  }

  LanguageService language;

  Future setPyaloaListner(LanguageService language) async {
    this.language = language;
  }

  Future updateFCMToken(String token) async {
    await _userService.updateFCMToken(
        token, Platform.isAndroid ? 'android' : 'ios');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('fcm', true);
    return;
  }

  Future setupFirebase(BuildContext context) async {
    if (!await isTokenUpdated()) {
      var token = await _firebaseMessaging.getToken();
      await updateFCMToken(token);

      print("FCM Token\n$token");
    }
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print(message);

        // setState(() {});
        print("onMessage: $message");
        language?.setPayloadListner(1);
        showNotificationWithDefaultSound(
            title: message['notification']['title'] ?? 'HomeAdvisor',
            body: message['notification']['body'] ?? '',
            payload: json.encode(message));
      },
      onLaunch: (Map<String, dynamic> message) async {
        // setState(() {});
        print("onLaunch: $message");
      },
      onResume: (Map<String, dynamic> message) async {
        /*
         {notification: {}, data: {data: {"profilePhoto":"https:\/\/home-advisor.s3.amazonaws.com\/media\/profile\/images_1.jpeg",
         "orderId":"225933756","vendor_id":"hrz6eXpNKaRxxSJPbr7S13lb5cV2","name":"suhail","type":"vendor",
         "email":"jk@gmail.com","chat_id":"chat:225933756","user_uid":"46EnowfE4kVjDS6gZJt3uRELk8h2"},
          google.original_priority: high, google.sent_time: 1620717039357, google.delivered_priority: high,
           sound: default, body: hiis, type: chat, title: suhail, click_action: FLUTTER_NOTIFICATION_CLICK,
           google.message_id: 0:1620717039371460%d8ff34ffd8ff34ff,
         collapse_key: com.home_advisor.customer, google.ttl: 2419200, from: 1020160607922}}
        */
        print("onResume: $message");
        print("onResume: ${message['data']['data']}");
        handlemessages(message);
      },
    );
    if (Platform.isIOS) {
      _firebaseMessaging.requestNotificationPermissions(
          const IosNotificationSettings(sound: true, badge: true, alert: true));
      _firebaseMessaging.onIosSettingsRegistered
          .listen((IosNotificationSettings settings) {
        print("Settings registered: $settings");
      });
    }
    return;
  }

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  Future onSelectNotificationUpdated(String payload) async {
    print('payload');
    print(payload);
    Map<String, dynamic> message = jsonDecode(payload);
    handlemessages(message);
  }

  void handlemessages(Map<String, dynamic> message) {
    print(message['data']['type']);

    var datum = json.decode(message['data']['data']);

    if (message['data']['type'] == 'chat')
      Navigator.push(
        scaffoldkey.currentContext,
        MaterialPageRoute(
          builder: (context) => ChatScreen(
            vendor: User(name: datum['name']),
            model: Results(
              vendor_uid: datum['vendorUid'],
              orderNo: datum['orderId'].toString(),
              chat_id: datum['chat_id'],
            ),
            chatId: datum['chat_id'],
          ),
        ),
      );
  }

  Future<void> showNotificationWithDefaultSound(
      {@required String title, @required String body, payload}) async {
    var androidPlatformChannelSpecifics = new AndroidNotificationDetails(
        'com.home_advisor.customer',
        'amble_notifications',
        'Displaying order notifications',
        importance: Importance.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('notification'),
        priority: Priority.high);
    var iOSPlatformChannelSpecifics = new IOSNotificationDetails();
    var platformChannelSpecifics = new NotificationDetails(
        android: androidPlatformChannelSpecifics,
        iOS: iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      platformChannelSpecifics,
      payload: payload,
    );
  }

  Future<void> configureNotifications(BuildContext context) async {
    var initializationSettingsAndroid =
        new AndroidInitializationSettings('ic_launcher');
    var initializationSettingsIOS = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
        android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: onSelectNotificationUpdated);
  }

  String homeIcon = "lib/images/bottom_nav/home.png";
  String chatIcon = "lib/images/bottom_nav/chat.png";
  String orderIcon = "lib/images/bottom_nav/orders.png";
  String profileIcon = "lib/images/bottom_nav/profile.png";

  Widget getViewForIndex(int index) {
    switch (index) {
      case 0:
        return MainCategView();
      case 1:
        return OrdersPage();
      // case 2:
      //   return ChatListScreen();
      case 2:
        return Profile();
      default:
        return MainCategView();
    }
  }
}
