import 'dart:async';

import 'package:flutter/material.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class SuccessPage extends StatelessWidget {
  static const String id = "success_page";

  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    Timer(Duration(seconds: 3), () {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => HomePageView(
                    index: 1,
                  )));
    });

    return Scaffold(
      appBar: AppBar(
        actions: [
          Container(
              margin: EdgeInsets.only(right: 5),
              child:
                  /*Icon(
              Icons.search_outlined,
              color: AppColor.blCommon,
            ),*/
                  Text(''))
        ],
        elevation: 1,
        backgroundColor: Colors.white,
        leading: Container(
          margin: EdgeInsets.only(left: 5),
          child: Image.asset("lib/images/logo/logo.png"),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: MediaQuery.of(context).size.width / 2,
                height: MediaQuery.of(context).size.width / 2,
                child: Lottie.asset(
                  "lib/images/success.json",
                  repeat: false,
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                language.lang == 'en'
                    ? "Thanks for paying the inspection amount \n Our inspector will get in touch with you for \n the additional help on the request"
                    : "شكرًا على دفع مبلغ الاستقصاء \n سيتواصل معك المفتش للحصول على \n  المساعدة الإضافية في الطلب",
                textAlign: TextAlign.center,
              )
            ],
          ),
        ),
      ),
    );
  }
}
