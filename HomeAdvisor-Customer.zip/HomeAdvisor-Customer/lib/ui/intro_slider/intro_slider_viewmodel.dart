import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/screen_util-extension.dart';
import 'package:home_advisor/core/services/language_service.dart';
import 'package:intro_slider/slide_object.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class IntroSliderViewModel extends BaseViewModel {
  BuildContext context;
  IntroSliderViewModel({this.context});
  List<Slide> slides = new List();

  void onInit() {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    slides.add(
      new Slide(
        backgroundColor: Colors.white,
        widgetTitle: Container(
          height: 150.h,
          child: Image.asset("lib/images/logo/logo.png"),
        ),
        styleTitle: TextStyle(
            color: Color(0xff3da4ab),
            fontSize: 30.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'RobotoMono'),
        description: language.lang == 'en'
            ? "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa."
            : "Lorem ipsum dolor sit amet، consectetuer adipiscing elit. Aenean Commodo ligula eget dolor عينين ماسة.",
        styleDescription: TextStyle(
            color: Color(0xfffe9c8f),
            fontSize: 20.0,
            fontStyle: FontStyle.italic,
            fontFamily: 'Raleway'),
        pathImage: "lib/images/logo/g1.png",
      ),
    );
    slides.add(
      new Slide(
        backgroundColor: Colors.white,
        widgetTitle: Container(
          height: 150.h,
          child: Image.asset("lib/images/logo/logo.png"),
        ),
        styleTitle: TextStyle(
            color: Color(0xff3da4ab),
            fontSize: 30.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'RobotoMono'),
        description: language.lang == 'en'
            ? "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa."
            : "Lorem ipsum dolor sit amet، consectetuer adipiscing elit. Aenean Commodo ligula eget dolor عينين ماسة.",
        styleDescription: TextStyle(
            color: Color(0xfffe9c8f),
            fontSize: 20.0,
            fontStyle: FontStyle.italic,
            fontFamily: 'Raleway'),
        pathImage: "lib/images/logo/g3.png",
      ),
    );
    slides.add(
      new Slide(
        backgroundColor: Colors.white,
        widgetTitle: Container(
          height: 150.h,
          child: Image.asset("lib/images/logo/logo.png"),
        ),
        styleTitle: TextStyle(
            color: Color(0xff3da4ab),
            fontSize: 30.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'RobotoMono'),
        description: language.lang == 'en'
            ? "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa."
            : "Lorem ipsum dolor sit amet، consectetuer adipiscing elit. Aenean Commodo ligula eget dolor عينين ماسة.",
        styleDescription: TextStyle(
            color: Color(0xfffe9c8f),
            fontSize: 20.0,
            fontStyle: FontStyle.italic,
            fontFamily: 'Raleway'),
        pathImage: "lib/images/logo/g2.png",
      ),
    );
  }

  void onDonePress() {
    print("next");
  }

  Widget renderNextBtn() {
    return Icon(
      Icons.navigate_next,
      color: Color(0xffD02090),
      size: 35.0,
    );
  }

  Widget renderDoneBtn() {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return Text(
      language.lang == 'en' ? "Skip" : "تخطى",
      style: TextStyle(fontSize: 30.f),
    );
  }

  Widget renderSkipBtn() {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return Text(
      language.lang == 'en' ? "Skip" : "تخطى",
      style: TextStyle(fontSize: 30.f),
    );
  }
}
