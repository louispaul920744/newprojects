import 'package:flutter/material.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:home_advisor/ui/intro_slider/intro_slider_viewmodel.dart';
import 'package:home_advisor/ui/login_page/login_view.dart';
import 'package:intro_slider/intro_slider.dart';
import 'package:stacked/stacked.dart';

class IntroPage extends StatelessWidget {
  static const id = "IntroPage";
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);
    return ViewModelBuilder.reactive(
      builder: (context, model, child) => IntroSlider(
        slides: model.slides,
        sizeDot: 13,
        renderSkipBtn: model.renderDoneBtn(),
        renderDoneBtn: InkWell(
          onTap: () {
            Navigator.pushNamed(context, LoginView.id);
          },
          child: Container(
            child: model.renderDoneBtn(),
            width: 100,
          ),
        ),
      ),
      onModelReady: (model) => model.onInit(),
      viewModelBuilder: () => IntroSliderViewModel(context: context),
    );
  }
}
