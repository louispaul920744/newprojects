import 'package:firebase_auth/firebase_auth.dart';
import 'package:home_advisor/core/services/api_services.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';

class UserService {
  ProfileModel user = ProfileModel();
  String token;

  Future<ProfileModel> getUser() async {
    var fireUser = FirebaseAuth.instance.currentUser;
    String tkn = await fireUser.getIdToken();
    print(tkn);
    var userResponse = await APIServices.getProfileDetails(tkn);
    user = userResponse;
    token = tkn;
    return user;
  }

  Future updateFCMToken(String fCMToken, String type) async {
    var fireUser = FirebaseAuth.instance.currentUser;
    String tkn = await fireUser.getIdToken();
    await APIServices.updateFCMToken(tkn, fCMToken, type);
    return;
  }
}
