import 'dart:convert';
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/rendering.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_model.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_questions_model.dart';
import 'package:home_advisor/ui/about_us_page/about_us_model.dart';
import 'package:home_advisor/ui/aggreement_page/order_model.dart';
import 'package:home_advisor/ui/aggreement_page/order_post_model.dart';
import 'package:home_advisor/ui/contact_us_page/contact_us_model.dart';
import 'package:home_advisor/ui/disclaimer_page/disclaimer_model.dart';
import 'package:home_advisor/ui/main_category/CategorySearchDelegate.dart';
import 'package:home_advisor/ui/main_category/main_categ_model.dart';
import 'package:home_advisor/ui/notification_page/notification_page_model.dart';
import 'package:home_advisor/ui/orders_page/models/order_get_model.dart';
import 'package:home_advisor/ui/orders_page/models/orders_completed.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';
import 'package:home_advisor/ui/pay_milestone/pay_milestone_model.dart';
import 'package:home_advisor/ui/privacy_policy_page/privacy_policy_model.dart';
import 'package:home_advisor/ui/profile_view/profile_model.dart';
import 'package:home_advisor/ui/service_page/services_page_model.dart';
import 'package:home_advisor/ui/sub_category/sub_categ_model.dart';
import 'package:home_advisor/ui/survey_page/survey_page_model.dart';
import 'package:home_advisor/ui/terms_and_conditions_page/terms_conditions_model.dart';
import 'package:home_advisor/ui/terms_of_use_page/terms_of_use_model.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_model.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:path/path.dart';

class URLS {
  static const String baseURL = 'http://backend.homeadvisor.qa';
}

class APIServices {
  static Future<MainCategResponse> getCateg(String token) async {
    final response = await http.get('${URLS.baseURL}/api/category', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return MainCategResponse.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));

      // return MainCategResponse.fromJson(jsonDecode(response.body));
    } else {
      return null;
    }
  }

  Future<List> getLocationAndCategories() async {
    print('APIServices.getLocationAndCategories');

    var uri = Uri.parse(URLS.baseURL + '/api/area_services/');
    print('APIServices.getLocationAndCategories');

    var res = await http.get(
      uri,
      headers: {
        "Accept": "application/json",
      },
    );
    print('APIServices.getLocationAndCategories');
    print(jsonDecode(res.body));
    return jsonDecode(res.body)['area'];
  }

  static Future searchTag(String token) async {
    final response = await http.get('${URLS.baseURL}/api/tags', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      print(jsonDecode(response.body));
      return jsonDecode(response.body)['results'];
      // return MainCategResponse.fromJson(jsonDecode(response.body));
    } else {
      return [];
    }
  }

  static Future searchService(String token, String query) async {
    final response = await http
        .get('${URLS.baseURL}/api/service/?search=${query.trim()}', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      List<SearchResult> results = List<SearchResult>();
      if (jsonDecode(response.body) != null) {
        results = List<SearchResult>();
        jsonDecode(response.body)['results'].forEach((v) {
          results.add(new SearchResult.fromJson(v));
        });
      }
      print(jsonDecode(response.body));
      return results;
      return MainCategResponse.fromJson(jsonDecode(response.body));
    } else {
      return [];
    }
  }

  static Future<SubCategModel> getSubCateg(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/subcategory', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return SubCategModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<ServicesPageModel> getServices(String token) async {
    final response = await http.get('${URLS.baseURL}/api/service', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return ServicesPageModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<ProfileModel> getProfileDetails(String token) async {
    final response = await http.get('${URLS.baseURL}/auth/users/me', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });
    print(
        'cuurent user details ${jsonDecode(utf8.decode(response.bodyBytes))}');
    if (response.statusCode == 200) {
      return ProfileModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future updateFCMToken(
      String token, String fCMToken, String type) async {
    print('==========  UPDATING FCM TOKEN===============');
    await http.post('${URLS.baseURL}/api/fcmtoken-update/',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer $token",
        },
        body: jsonEncode({'fcm_token': fCMToken, 'type': type}));
    print('==========  UPDATING FCM TOKEN  END  ===============');

    return;
  }

  static Future updateProfileImage(
    String file,
    String fileName,
    String token,
  ) async {
    Map<String, String> headers = {
      "Authorization": "Bearer $token",
      "Content-type": "multipart/form-data"
    };

    var request = http.MultipartRequest(
      'PATCH',
      Uri.parse(
        'http://backend.homeadvisor.qa/auth/users/me/',
      ),
    );

    request.headers.addAll(headers);
    request.files.add(
      await http.MultipartFile.fromPath(
        'photo',
        file,
        filename: fileName,
        contentType: MediaType('image', 'jpeg'),
      ),
    );

    var res = await request.send();
    return res;
  }

  static Future<bool> checkUserType(String token, String phone) async {
    final response = await http.post(
      '${URLS.baseURL}/api/check_usertype/',
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode({"phone_number": phone}),
    );

    print(jsonDecode(response.body));
    return jsonDecode(response.body)['user_type'] != "vendor";
  }

  static Future<bool> checkEmail(String token, String email) async {
    final response = await http.post(
      '${URLS.baseURL}/api/validate_email/',
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode({"email": email}),
    );

    print(jsonDecode(response.body));
    return response.statusCode != 200;
  }

  static Future<ProfileModel> updateProfile(
      ProfileModel userProfile, String token,
      {bool isCompleteProfile = true}) async {
    var response;
    Map<String, String> headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    };
    if (!isCompleteProfile) {
      response = await http.put(
        '${URLS.baseURL}/auth/users/me/',
        headers: headers,
        body: jsonEncode(
          {
            'display_name': userProfile.displayName,
            'last_name': userProfile.lastName,
            'email': userProfile.email,
          },
        ),
      );
    } else {
      response = await http.put(
        '${URLS.baseURL}/auth/users/me/',
        headers: headers,
        body: json.encode(userProfile.toJson()),
      );
    }
    print(jsonDecode(response.body));
    if (response.statusCode == 200) {
      return ProfileModel.fromJson(jsonDecode(response.body));
    } else
      return null;
  }

  static Future uploadImages(
    List<String> files,
    String token,
    String orderId,
  ) async {
    Map<String, String> headers = {
      "Authorization": "Bearer $token",
      "Content-type": "multipart/form-data"
    };

    var request = http.MultipartRequest(
      'POST',
      Uri.parse(
        'http://backend.homeadvisor.qa/api/ordermedia/',
      ),
    );

    request.headers.addAll(headers);
    request.fields.addAll({'order': orderId});
    try {
      for (var file in files) {
        var index = files.indexOf(file);
        request.files.add(
          await http.MultipartFile.fromPath(
            'image_${index + 1}',
            file,
            filename: basename(file),
            contentType: MediaType('image', 'jpeg'),
          ),
        );
      }
    } catch (e) {
      print(e);
    }
    var response = await request.send();
  }

  static Future<OrderPostModel> putOrder(OrderModel order, String token) async {
    final response = await http.post(
      '${URLS.baseURL}/api/order/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        order.toJson(),
      ),
    );
    print(
        "putOrder ${URLS.baseURL}/api/order/}\nB:-${jsonEncode(order.toJson())}  R:-\n${jsonDecode(response.body)}");
    if (response.statusCode == 201) {
      return OrderPostModel.fromJson(jsonDecode(response.body));
    } else
      return null;
  }

  static Future<bool> postRating(
    String token, {
    String review,
    double rating,
    int orderId,
  }) async {
    final response = await http.post(
      '${URLS.baseURL}/api/vendorrating/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {
          "order": orderId,
          "review": "$review",
          "rating": rating,
        },
      ),
    );
    if (response.statusCode == 201) {
      if (jsonDecode(response.body)['id'] != null) {
        return true;
      } else {
        return false;
      }
    } else
      return null;
  }

  static Future<String> getWarrantyTerms(
    String token, {
    int orderId,
  }) async {
    print('${URLS.baseURL}/api/get-warranty-terms/\nR:- ${{
      "order": orderId,
    }}');
    final response = await http.post(
      '${URLS.baseURL}/api/get-warranty-terms/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {
          "order": orderId,
        },
      ),
    );
    print('jsonDecode(response.body)');

    return jsonDecode(response.body)['warranty_terms'] ??
        "Warranty not available";
  }

  static Future getOrder(String token, {String param}) async {
    print("url :-  ${URLS.baseURL}/api/order/?status=$param");
    final response =
        await http.get('${URLS.baseURL}/api/order/?status=$param', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    print("resposne :-  ${jsonDecode(utf8.decode(response.bodyBytes))}");

    if (response.statusCode == 200) {
      if (param == "INITIATED") {
        return OrderGetModel.fromJson(
          jsonDecode(
            utf8.decode(response.bodyBytes),
          ),
        );
      } else if (param == "IN-PROGRESS") {
        debugPrint(response.bodyBytes.toString());
        return OngoingOrder.fromJson(
          jsonDecode(
            utf8.decode(response.bodyBytes),
          ),
        );
      } else if (param == "COMPLETED") {
        return CompletedOrder.fromJson(
          jsonDecode(
            utf8.decode(response.bodyBytes),
          ),
        );
      }
    } else {
      return null;
    }
  }

  static Future viewQuoteDetails(int orderId) async {
    var fireUser = FirebaseAuth.instance.currentUser;
    String tkn = await fireUser.getIdToken();
    final response = await http.post(
      '${URLS.baseURL}/api/viewquote/',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer $tkn",
      },
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return false;
    }
  }

  static Future deleteOrder(String token, int orderId) async {
    final response = await http.delete(
      '${URLS.baseURL}/api/order/$orderId/',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
    );
    print(response.statusCode);
    if (response.statusCode == 204) {
      return true;
    } else {
      return false;
    }
  }

  static Future<String> getAdminUserAgreement(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/adminuseragreement/', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["agreement"];
    } else {
      return null;
    }
  }

  static Future<String> getVendorUserAgreement(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/vendoruseragreement/', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["agreement"];
    } else {
      return null;
    }
  }

////////////////////////////////////////////////////////////////////
  static Future<SurveyModel> getSurvey(String token) async {
    print(URLS.baseURL + '/api/survey');
    final response = await http.get('${URLS.baseURL}/api/survey', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });
    print(response.body);

    if (response.statusCode == 200) {
      var result =
          SurveyModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
      print('api/survey\n${result.toJson()}');
      return result;
    } else {
      return null;
    }
  }

  static Future<QuestionsModel> getQuestions(String token) async {
    final response = await http.get('${URLS.baseURL}/api/questions', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return QuestionsModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<FAQModel> getFAQ(String token) async {
    final response = await http.get('${URLS.baseURL}/api/faq', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return FAQModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<FAQQuestionsModel> getFAQQuestions(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/faqqouestions', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return FAQQuestionsModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<ContactUsModel> getContactUs(String token) async {
    final response = await http.get('${URLS.baseURL}/api/contactus', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return ContactUsModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<TermsConditionsModel> getTermsConditions(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/termsandconditions', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return TermsConditionsModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<PrivacyPolicyModel> getPrivacyPolicy(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/privacypolicy', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return PrivacyPolicyModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<AboutUsModel> getAboutUs(String token) async {
    final response = await http.get('${URLS.baseURL}/api/aboutus', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return AboutUsModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<DisclaimerModel> getDisclaimer(String token) async {
    final response = await http.get('${URLS.baseURL}/api/disclaimer', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return DisclaimerModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<TermsOfUseModel> getTermsOfUse(String token) async {
    final response = await http.get('${URLS.baseURL}/api/termsofuse', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    if (response.statusCode == 200) {
      return TermsOfUseModel.fromJson(
          jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<VendorQuote> getVendorQuote(String token, String order) async {
    final response = await http
        .get('${URLS.baseURL}/api/vendorquoteforuser/?order=$order', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });
    printWrapped(
        "url-> ${URLS.baseURL}/api/vendorquoteforuser/?order=$order\nResposne:-  ${jsonDecode(response.body)} ");

    if (response.statusCode == 200) {
      return VendorQuote.fromJson(
        jsonDecode(
          utf8.decode(response.bodyBytes),
        ),
      );
    } else {
      return null;
    }
  }

  static Future<bool> confirmQuote(
    int quoteId,
    String token,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/acceptqouterequest/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {
          "quotes": quoteId,
        },
      ),
    );

    if (response.statusCode == 200) {
      if (jsonDecode(response.body)['message'] ==
          'Your request successfully submitted') {
        return true;
      } else {
        return false;
      }
    } else
      return false;
  }

  static Future<bool> rejectQuote(
    int quoteId,
    String token,
    String reason,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/cancelqouterequest/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {"quotes": quoteId, "reasson": reason},
      ),
    );

    if (response.statusCode == 200) {
      if (jsonDecode(response.body)['message']
          .contains('Quotes successfully')) {
        return true;
      } else {
        return false;
      }
    } else
      return false;
  }

  static Future<bool> payQuote(
    String orderID,
    String token,
    String amount,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/payment/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode({
        "order": int.parse(orderID),
        "payment_type": "advance",
        "payment_order_id": 98594598,
        "amount": amount
      }),
    );
    print(response.body);
    if (response.statusCode == 201) {
      return true;
    } else
      return false;
  }

  static Future<bool> payMileStone(
    String token,
    Milestone milestone,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/payment/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode({
        "order": milestone.order,
        "payment_type": "milestone",
        "milestone": milestone.id,
        "payment_order_id": Random().nextInt(88888888),
        "amount": milestone.amount
      }),
    );
    print(response.body);
    if (response.statusCode == 201) {
      return true;
    } else
      return false;
  }

  static Future<Notification> getNotification(String token) async {
    final response =
        await http.get('${URLS.baseURL}/api/notifications/', headers: {
      'Content-Type': 'application/json',
      'Authorization': "Bearer $token",
    });

    print(jsonDecode(response.body));
    if (response.statusCode == 200) {
      return Notification.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      return null;
    }
  }

  static Future<Notification> postNotificationStatus(
      String token, List<int> notifications) async {
    final response = await http.post('${URLS.baseURL}/api/notificationread/',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer $token",
        },
        body: json.encode({"notification_ids": notifications}));

    if (response.statusCode == 200) {
    } else {
      return null;
    }
  }

  static Future<bool> postPayment(
    int amount,
    int orderId,
    String token,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/inspectionpayment/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {"order": orderId, "payment_order_id": 000000, "amount": amount},
      ),
    );
    print(response.statusCode);
    print(response.body);

    if (response.statusCode == 201) {
      print('payment placed');
    } else
      return false;
  }

  static Future<MileStone> getMilestone(String token, String orderID) async {
    print(
        "Payment milstones ${URLS.baseURL}/api/vendorquoteforuser/?order=$orderID");
    final response = await http.get(
        '${URLS.baseURL}/api/vendorquoteforuser/?order=$orderID',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer $token",
        });
    print("Response   ${response.body}");
    if (response.statusCode == 200) {
      return MileStone.fromJson(
        jsonDecode(
          utf8.decode(response.bodyBytes),
        ),
      );
    } else {
      return null;
    }
  }

  static Future<bool> ReportIssue(
    String reason,
    int orderId,
    String token,
  ) async {
    final response = await http.post(
      '${URLS.baseURL}/api/orderissue/',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': "Bearer $token",
      },
      body: jsonEncode(
        {
          "reason": "$reason",
          "order": orderId,
        },
      ),
    );

    if (response.statusCode == 201) {
      if (jsonDecode(response.body)['id'] != null) {
        return true;
      } else {
        return false;
      }
    } else
      return false;
  }
}
