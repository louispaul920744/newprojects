import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageService extends ChangeNotifier {
  String _lang = "en";

  String get lang => _lang;

  int _payLoad = 0;

  int get payLoad => _payLoad;

  void setPayloadListner(int paylod) {
    _payLoad = paylod;
  }

  void setLanguage(String lang) {
    _lang = lang;
    notifyListeners();
  }

  void setLanguagePreferance(String lang) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('lan', lang);
    setLanguage(lang);
  }

  Future getLanguagePreferance() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String lan = prefs.getString('lan');
    setLanguage(lan);
  }
}
