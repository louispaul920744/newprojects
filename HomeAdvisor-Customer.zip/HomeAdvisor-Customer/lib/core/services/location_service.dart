import 'package:flutter/material.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:google_maps_webservice/places.dart';

String _api = "AIzaSyBoZGYmNd8jvV1111TETjQUY5EziI65p6k";
double latitude;
double longitude;
Location location;

Future<Prediction> getLocation(BuildContext context) async {
  Prediction prediction = await PlacesAutocomplete.show(
    context: context,
    apiKey: _api,
    mode: Mode.fullscreen, // Mode.overlay
    language: "en",
  );

  return prediction;
}

Future<Location> getLatLng(Prediction prediction) async {
  GoogleMapsPlaces _places =
      new GoogleMapsPlaces(apiKey: _api); //Same API_KEY as above
  PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(prediction.placeId);
  latitude = detail.result.geometry.location.lat;
  longitude = detail.result.geometry.location.lng;
  //String address = prediction.description;
  location = Location(latitude, longitude);
  return location;
}
