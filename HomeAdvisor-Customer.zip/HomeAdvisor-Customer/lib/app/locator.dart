import 'package:get_it/get_it.dart';
import 'package:home_advisor/core/api/api.dart';
import 'package:home_advisor/core/services/auth/firebase_auth_service.dart';
import 'package:home_advisor/core/services/user_service.dart';
import 'package:home_advisor/ui/profile_view/profile_viewmodel.dart';

import '../ui/chatlist/chatlist_viewmodel.dart';

GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton(() => ChatListModel());
  locator.registerLazySingleton(() => Api());
  locator.registerLazySingleton<UserService>(() => UserService());
  locator
      .registerLazySingleton<FirebaseAuthService>(() => FirebaseAuthService());

  // Factory singletons
  locator.registerFactory(() => ProfileViewModel());
}
