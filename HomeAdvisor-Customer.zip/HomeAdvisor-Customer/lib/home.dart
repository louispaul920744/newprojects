import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:home_advisor/ui/FAQ_page/FAQ_view.dart';
import 'package:home_advisor/ui/about_us_page/about_us_view.dart';
import 'package:home_advisor/ui/complete_profile/complete_profile_view.dart';
import 'package:home_advisor/ui/contact_us_page/contact_us_view.dart';
import 'package:home_advisor/ui/disclaimer_page/disclaimer_view.dart';
import 'package:home_advisor/ui/homepage/home_page_view.dart';
import 'package:home_advisor/ui/intro_slider/intro_page_view.dart';
import 'package:home_advisor/ui/login_page/login_view.dart';
import 'package:home_advisor/ui/notification_page/notification_page_view.dart';
import 'package:home_advisor/ui/pay_milestone/pay_milestone_view.dart';
import 'package:home_advisor/ui/privacy_policy_page/privacy_policy_view.dart';
import 'package:home_advisor/ui/splash_screen/splash_screen_view.dart';
import 'package:home_advisor/ui/start_page.dart';
import 'package:home_advisor/ui/sub_category/sub_categ_view.dart';
import 'package:home_advisor/ui/terms_and_conditions_page/terms_conditions_view.dart';
import 'package:home_advisor/ui/terms_of_use_page/terms_of_use_view.dart';
import 'package:home_advisor/ui/vendor_details_page/vendor_details_page_view.dart';
import 'package:home_advisor/ui/vendors_page/vendors_page_view.dart';
import 'package:provider/provider.dart';

import 'core/services/language_service.dart';
import 'ui/locationdate/locationdate_view.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    LanguageService language = Provider.of<LanguageService>(
      context,
    );
    return MaterialApp(
      localizationsDelegates: [
        GlobalCupertinoLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      supportedLocales: [
        Locale("en", "US"),
        Locale("ar", "AE"),
      ],
      locale: language.lang == 'ar' ? Locale("ar", "AE") : Locale("en", "US"),

      // home: AuthService().handleAuth(),
      // initialRoute: SplashScreenView.id,
      initialRoute: FirebaseAuth.instance?.currentUser?.phoneNumber != null
          ? SplashScreenView.id
          : StartPage.id,
      routes: {
        StartPage.id: (context) => StartPage(),
        IntroPage.id: (context) => IntroPage(),
        CompleteProfileView.id: (context) => CompleteProfileView(),
        HomePageView.id: (context) => HomePageView(),
        SubCategView.id: (context) => SubCategView(),
        LoginView.id: (context) => LoginView(),
        PayMilestonePage.id: (context) => PayMilestonePage(),
        VendorsPage.id: (context) => VendorsPage(),
        NotificationPage.id: (context) => NotificationPage(),
        LocationDatePage.id: (context) => LocationDatePage(),
        SplashScreenView.id: (context) => SplashScreenView(),
        VendorDetailsPageView.id: (context) => VendorDetailsPageView(),
        FAQPage.id: (context) => FAQPage(),
        ContactUsPage.id: (context) => ContactUsPage(),
        TermsConditionsPage.id: (context) => TermsConditionsPage(),
        PrivacyPolicyPage.id: (context) => PrivacyPolicyPage(),
        AboutUsPage.id: (context) => AboutUsPage(),
        DisclaimerPage.id: (context) => DisclaimerPage(),
        TermsOfUsePage.id: (context) => TermsOfUsePage(),
      },
    );
  }
}
