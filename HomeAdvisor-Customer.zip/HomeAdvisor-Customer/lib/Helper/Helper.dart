import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme/text_styles.dart';
import 'package:intl/intl.dart';

class Helper {
  static void printWrapped(String text) {
    final pattern = RegExp('.{1,800}');
    pattern.allMatches(text).forEach((match) => print(match.group(0)));
  }

  static List<Map<String, dynamic>> municipalitiesArray(lang) => [
        {"id": 9, 'name': lang == 'en' ? "Al Wakrah" : "الوكرة"},
        {"id": 8, 'name': lang == 'en' ? "Al Rayyan" : "الريان"},
        {"id": 7, 'name': lang == 'en' ? "Doha" : "الدوحة"},
        {"id": 6, 'name': lang == 'en' ? "Al Daayen" : "الظعاين"},
        {"id": 5, 'name': lang == 'en' ? "Umm Salal" : "أم صلال"},
        {"id": 4, 'name': lang == 'en' ? "Al-Shahaniya" : "الشحانية"},
        {"id": 3, 'name': lang == 'en' ? "Al Khor" : "الخور"},
        {"id": 2, 'name': lang == 'en' ? "Al Shamal" : "الشمال"}
      ];

  List<DropdownMenuItem> municipalitiess(lang, final red) => [
        DropdownMenuItem(
          value: 9,
          child: Text(
            lang == 'en' ? "Al Wakrah" : "الوكرة",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
          value: 8,
          child: Text(
            lang == 'en' ? "Al Rayyan" : "الريان",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
          value: 7,
          child: Text(
            lang == 'en' ? "Doha" : "الدوحة",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
          value: 6,
          child: Text(
            lang == 'en' ? "Al Daayen" : "الظعاين",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
            value: 5,
            child: Text(
              lang == 'en' ? "Umm Salal" : "أم صلال",
              style: AppTextStyles.s2(
                red,
                size: 36,
              ),
            )),
        DropdownMenuItem(
          value: 4,
          child: Text(
            "Al-Shahaniya",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
          value: 3,
          child: Text(
            lang == 'en' ? "Al Khor" : "الخور",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        ),
        DropdownMenuItem(
          value: 2,
          child: Text(
            lang == 'en' ? "Al Shamal" : "الشمال",
            style: AppTextStyles.s2(
              red,
              size: 36,
            ),
          ),
        )
      ];

  static String formatDate(String date) {
    try {
      final format = DateFormat("yyyy-MM-dd");
      DateTime gettingDate = format.parse(date);
      final DateFormat formatter = DateFormat('dd-MM-yyyy');
      final String formatted = formatter.format(gettingDate);
      return formatted;
    } catch (e) {
      print(date);
      print(e);
      return date;
    }
  }

  static String timeAgoSinceDate(String dateString,
      {bool numericDates = true, locale = 'en'}) {
    try {
      DateTime notificationDate = DateFormat(
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      ).parse(dateString);

      // DateTime notificationDate = DateTime.parse(dateString);
      final date2 = DateTime.now();
      final difference = date2.difference(notificationDate);

      if (difference.inDays > 8) {
        return dateString;
      } else if ((difference.inDays / 7).floor() >= 1) {
        return (numericDates) ? '1 week ago' : 'Last week';
      } else if (difference.inDays >= 2) {
        return '${difference.inDays} days ago';
      } else if (difference.inDays >= 1) {
        return (numericDates) ? '1 day ago' : 'Yesterday';
      } else if (difference.inHours >= 2) {
        return '${difference.inHours} hours ago';
      } else if (difference.inHours >= 1) {
        return (numericDates) ? '1 hour ago' : 'An hour ago';
      } else if (difference.inMinutes >= 2) {
        return '${difference.inMinutes} minutes ago';
      } else if (difference.inMinutes >= 1) {
        return (numericDates) ? '1 minute ago' : 'A minute ago';
      } else if (difference.inSeconds >= 3) {
        return '${difference.inSeconds} seconds ago';
      } else {
        return 'Just now';
      }
    } catch (e) {
      return 'N/A';
    }
  }
}

void printWrapped(String text) {
  final pattern = RegExp('.{1,800}'); // 800 is the size of each chunk
  pattern.allMatches(text).forEach((match) => print(match.group(0)));
}
