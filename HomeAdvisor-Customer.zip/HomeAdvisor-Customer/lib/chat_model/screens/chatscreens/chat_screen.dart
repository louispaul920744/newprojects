import 'dart:io';
import 'dart:isolate';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emoji_picker/emoji_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:home_advisor/app_theme//screen_util-extension.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/chat_model/models/message.dart';
import 'package:home_advisor/chat_model/models/user.dart';
import 'package:home_advisor/chat_model/resources/auth_methods.dart';
import 'package:home_advisor/chat_model/resources/chat_methods.dart';
import 'package:home_advisor/chat_model/resources/storage_methods.dart';
import 'package:home_advisor/chat_model/screens/chatscreens/widgets/cached_image.dart';
import 'package:home_advisor/chat_model/utils/universal_variables.dart';
import 'package:home_advisor/chat_model/widgets/appbar.dart';
import 'package:home_advisor/chat_model/widgets/custom_tile.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:permission_handler/permission_handler.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final User vendor;
  final Results model;

  ChatScreen({
    this.vendor,
    this.chatId,
    this.model,
  });

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ChatMethods _chatMethods = ChatMethods();
  final StorageMethods _storageMethods = StorageMethods();

  TextEditingController textFieldController = TextEditingController();
  FocusNode textFieldFocus = FocusNode();

  User sender;
  String _localPath;
  bool isWriting = false;
  bool showEmojiPicker = false;
  bool _permissionReady;

  @override
  void initState() {
    super.initState();
    // _authMethods.getCurrentUser().then((user) {
    //   _currentUserId = user.uid;
    //
    //   setState(() {
    //     sender = User(
    //       uid: user.uid,
    //       name: user.displayName,
    //       profilePhoto: user.photoURL,
    //     );
    //   });
    // });
    FlutterDownloader.registerCallback(downloadCallback);

    _permissionReady = false;
    _prepare();
  }

  static void downloadCallback(
      String id, DownloadTaskStatus status, int progress) {
    print(
        'Background Isolate Callback: task ($id) is in status ($status) and process ($progress)');
    final SendPort send =
        IsolateNameServer.lookupPortByName('downloader_send_port');
    send.send([id, status, progress]);
  }

  showKeyboard() => textFieldFocus.requestFocus();

  hideKeyboard() => textFieldFocus.unfocus();

  hideEmojiContainer() {
    setState(() {
      showEmojiPicker = false;
    });
  }

  showEmojiContainer() {
    setState(() {
      showEmojiPicker = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context,
        designSize: Size(750, 1334), allowFontScaling: false);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: SizedBox(),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
            colors: [AppColor.blGradient2, AppColor.blGradient1],
            begin: Alignment.bottomLeft,
            end: Alignment.topRight,
          )),
          child: Padding(
            padding: EdgeInsets.only(left: 25.w, right: 25.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 40.h,
                ),
                Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.arrow_back_outlined,
                            color: Colors.white,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 12.w,
                    ),
                    Text(
                      widget.vendor.name,
                      style: TextStyle(
                        fontSize: 40.f,
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: <Widget>[
          Flexible(
            child: messageList(),
          ),
          chatControls(),
          showEmojiPicker ? Container(child: emojiContainer()) : Container(),
        ],
      ),
    );
  }

  emojiContainer() {
    return EmojiPicker(
      bgColor: UniversalVariables.separatorColor,
      indicatorColor: UniversalVariables.blueColor,
      rows: 3,
      columns: 7,
      onEmojiSelected: (emoji, category) {
        setState(() {
          isWriting = true;
        });

        textFieldController.text = textFieldController.text + emoji.emoji;
      },
      recommendKeywords: ["face", "happy", "party", "sad"],
      numRecommended: 50,
    );
  }

  Widget messageList() {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('chats')
          .doc(widget.chatId)
          .collection('messages')
          .orderBy('at', descending: true)
          .snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.data == null) {
          return Center(child: CircularProgressIndicator());
        }
        print('=================');
        print(snapshot.data.docs.length);
        // SchedulerBinding.instance.addPostFrameCallback((_) {
        //   _listScrollController.animateTo(
        //     _listScrollController.position.minScrollExtent,
        //     duration: Duration(milliseconds: 250),
        //     curve: Curves.easeInOut,
        //   );
        // });

        return ListView.builder(
          padding: EdgeInsets.all(10),
          reverse: true,
          itemCount: snapshot.data.docs.length,
          itemBuilder: (context, index) {
            // mention the arrow syntax if you get the time
            return chatMessageItem(snapshot.data.docs[index]);
          },
        );
      },
    );
  }

  Widget chatMessageItem(DocumentSnapshot snapshot) {
    print('[[[[[[[[[[[');
    print(snapshot.data());
    Message _message = Message.fromMap(snapshot.data());

    return Container(
      margin: EdgeInsets.symmetric(vertical: 15),
      child: Container(
        alignment: _message.userType == 'customer'
            ? Alignment.centerRight
            : Alignment.centerLeft,
        child: _message.userType == 'customer'
            ? senderLayout(_message)
            : receiverLayout(_message),
      ),
    );
  }

  Widget senderLayout(Message message) {
    Radius messageRadius = Radius.circular(10);

    return Container(
      margin: EdgeInsets.only(top: 12),
      constraints:
          BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
      decoration: BoxDecoration(
        color: UniversalVariables.senderColor,
        borderRadius: BorderRadius.only(
          topLeft: messageRadius,
          topRight: messageRadius,
          bottomLeft: messageRadius,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(10),
        child: getMessage(message, true),
      ),
    );
  }

  Future<bool> _checkPermission() async {
    if (Platform.isAndroid) {
      final status = await Permission.storage.status;
      if (status != PermissionStatus.granted) {
        final result = await Permission.storage.request();
        if (result == PermissionStatus.granted) {
          return true;
        }
      } else {
        return true;
      }
    } else {
      return true;
    }
    return false;
  }

  Future<String> _findLocalPath() async {
    final directory = Platform.isAndroid
        ? await getExternalStorageDirectory()
        : await getApplicationDocumentsDirectory();
    return directory.path;
  }

  _prepare() async {
    _permissionReady = await _checkPermission();

    _localPath =
        (await _findLocalPath()) + Platform.pathSeparator + 'Documents';

    final savedDir = Directory(_localPath);
    bool hasExisted = await savedDir.exists();
    if (!hasExisted) {
      savedDir.create();
    }
  }

  void _requestDownload({String message}) async {
    try {
      if (_permissionReady) {
        await FlutterDownloader.enqueue(
            url: message,
            headers: {"auth": "test_for_sql_encoding"},
            savedDir: _localPath,
            showNotification: true,
            requiresStorageNotLow: false,
            fileName: message.split('/').last,
            openFileFromNotification: false);
      } else {
        Fluttertoast.showToast(
            msg: 'Please give the permission for storage access');
      }
    } catch (e) {
      // print("dfjds "+e.toString());
    }
  }

  getMessage(Message message, bool isSender) {
    if (message.type == 'text') {
      return Text(
        message.message,
        style: TextStyle(
          color: isSender ? Colors.black : Colors.white,
          fontSize: 16.0,
        ),
      );
    } else {
      if (message.type == 'image') {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(4),
          ),
          child: CachedImage(
            message.attachment[0].attachment,
            fit: BoxFit.cover,
            height: 250,
            width: 250,
            radius: 10,
          ),
        );
      } else {
        return Padding(
          padding: const EdgeInsets.only(top: 5.0),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FutureBuilder<List<DownloadTask>>(
                        future: FlutterDownloader.loadTasksWithRawQuery(
                            query:
                                "SELECT * FROM task WHERE url LIKE '${message.attachment.first}"),
                        builder: (context, snapshot) {
                          DownloadTask dTask =
                              snapshot.data != null && snapshot.data.length > 0
                                  ? snapshot.data[0]
                                  : null;
                          return dTask != null &&
                                  dTask.status == DownloadTaskStatus.complete
                              ? Container()
                              : InkWell(
                                  onTap: () async {
                                    if (dTask != null &&
                                        (dTask.status ==
                                                DownloadTaskStatus.failed ||
                                            dTask.status ==
                                                DownloadTaskStatus.running ||
                                            dTask.status ==
                                                DownloadTaskStatus.canceled ||
                                            dTask.status ==
                                                DownloadTaskStatus.paused ||
                                            dTask.status ==
                                                DownloadTaskStatus.enqueued)) {
                                      try {
                                        await FlutterDownloader.remove(
                                            taskId: dTask.taskId);
                                      } catch (e) {}
                                      setState(() {});
                                    } else {
                                      _requestDownload(
                                          message: message
                                              .attachment.first.attachment);
                                    }
                                  },
                                  child: CircularPercentIndicator(
                                    radius: ScreenUtil()
                                        .setSp(42, allowFontScalingSelf: false),
                                    lineWidth: ScreenUtil()
                                        .setSp(3, allowFontScalingSelf: false),
                                    backgroundColor:
                                        UniversalVariables.greyColor,
                                    center: Icon(
                                      dTask != null &&
                                              (dTask.status ==
                                                      DownloadTaskStatus
                                                          .failed ||
                                                  dTask.status ==
                                                      DownloadTaskStatus
                                                          .running ||
                                                  dTask.status ==
                                                      DownloadTaskStatus
                                                          .canceled ||
                                                  dTask.status ==
                                                      DownloadTaskStatus
                                                          .paused ||
                                                  dTask.status ==
                                                      DownloadTaskStatus
                                                          .enqueued)
                                          ? Icons.close
                                          : Icons.arrow_downward,
                                      color: Colors.white,
                                      size: ScreenUtil().setSp(24,
                                          allowFontScalingSelf: false),
                                    ),
                                    percent: dTask != null
                                        ? dTask.progress <= 0
                                            ? 0.00
                                            : dTask.progress.toDouble() / 100
                                        : 0.00,
                                    progressColor:
                                        UniversalVariables.lightBlueColor,
                                  ),
                                );
                        }),
                    Text("   " + getdocumentName(message.attachment.first))
                  ],
                ),
                SizedBox(
                  height: ScreenUtil().setHeight(5),
                ),
                Text(readTimestamp(message.timestamp))
              ],
            ),
          ),
        );
      }
    }
  }

  String getdocumentName(Attachemt docName) {
    try {
      final filename = docName.fileName;
      if (filename.isNotEmpty) return filename;
      throw "";
    } catch (e) {
      print('suhal $e');
      print(e);
      return 'Document';
    }
  }

  String readTimestamp(var timestamp) {
    if (timestamp != null) {
      var format = new DateFormat(' hh:mm a');
      var date;
      if (timestamp is String) {
        date = DateTime.fromMillisecondsSinceEpoch(int.parse(timestamp));
      } else {
        date = DateTime.fromMillisecondsSinceEpoch(
            timestamp.millisecondsSinceEpoch);
      }
      return format.format(date);
    }
    return "dd";
  }

  Widget receiverLayout(Message message) {
    Radius messageRadius = Radius.circular(10);

    return Container(
      margin: EdgeInsets.only(top: 12),
      constraints:
          BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
      decoration: BoxDecoration(
        color: UniversalVariables.receiverColor,
        borderRadius: BorderRadius.only(
          bottomRight: messageRadius,
          topRight: messageRadius,
          bottomLeft: messageRadius,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(10),
        child: getMessage(message, false),
      ),
    );
  }

  bool isFirstMessageSending = true;
  Widget chatControls() {
    setWritingTo(bool val) {
      setState(() {
        isWriting = val;
      });
    }

    sendMessage() async {
      var text = textFieldController.text;

      var data = {
        'message': {'item': text, 'type': 'text'}
      };

      setState(() {
        isWriting = false;
      });

      textFieldController.text = "";

      if (isFirstMessageSending) {
        print('+++++)))))))))))))))))))))');
        AuthMethods().getVendorRequestNode(widget.model).then((result) async {
          if (result.docs.length < 1) {
            AuthMethods().updateVendorChatRequest(widget.model);
          } else {
            result.docs.first.reference.update({'at': Timestamp.now()});
          }
        }).catchError((ss) {
          print(ss);
        });

        setState(() {
          isFirstMessageSending = false;
        });
      }
      _chatMethods.addMessageToDb(data, widget.chatId);
    }

    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          // GestureDetector(
          //   onTap: () => addMediaModal(context),
          //   child: Container(
          //     padding: EdgeInsets.all(5),
          //     decoration: BoxDecoration(
          //       gradient: UniversalVariables.fabGradient,
          //       shape: BoxShape.circle,
          //     ),
          //     child: Icon(Icons.add),
          //   ),
          // ),
          SizedBox(
            width: 5,
          ),
          Expanded(
            child: Stack(
              alignment: Alignment.centerRight,
              children: [
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => addMediaModal(context),
                      child: Container(
                        padding: EdgeInsets.all(5),
                        child: Icon(
                          Icons.add,
                          color: UniversalVariables.greyColor,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: TextField(
                        controller: textFieldController,
                        focusNode: textFieldFocus,
                        onTap: () => hideEmojiContainer(),
                        style: TextStyle(
                          color: Colors.black,
                        ),
                        onChanged: (val) {
                          (val.length > 0 && val.trim() != "")
                              ? setWritingTo(true)
                              : setWritingTo(false);
                        },
                        maxLines: null,
                        maxLength: 100,
                        decoration: InputDecoration(
                          hintText: "Type a message",
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                          counterText: "",
                          labelStyle: TextStyle(
                            color: Colors.black,
                          ),
                          suffixIcon: IconButton(
                            splashColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onPressed: () {
                              if (!showEmojiPicker) {
                                // keyboard is visible
                                hideKeyboard();
                                showEmojiContainer();
                              } else {
                                //keyboard is hidden
                                showKeyboard();
                                hideEmojiContainer();
                              }
                            },
                            icon: Icon(Icons.face),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(50.0),
                            ),
                            borderSide: BorderSide(
                              color: UniversalVariables.greyColor,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          isWriting
              ? Container(
                  margin: EdgeInsets.only(left: 10),
                  decoration: BoxDecoration(
                      gradient: UniversalVariables.fabGradient,
                      shape: BoxShape.circle),
                  child: IconButton(
                    icon: Icon(
                      Icons.send,
                      size: 15,
                    ),
                    onPressed: () => sendMessage(),
                  ))
              : Container()
        ],
      ),
    );
  }

  addMediaModal(context) {
    showModalBottomSheet(
        context: context,
        elevation: 0,
        backgroundColor: Colors.white,
        builder: (context) {
          return Wrap(
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: <Widget>[
                    FlatButton(
                      child: Icon(
                        Icons.close,
                      ),
                      onPressed: () => Navigator.maybePop(context),
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Content and tools",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              ModalTile(
                title: "Camera",
                subtitle: "",
                icon: Icons.camera_alt,
                onTap: () {
                  pickImage(source: ImageSource.camera);
                  Navigator.maybePop(context);
                },
              ),
              ModalTile(
                title: "Photo & Library",
                subtitle: "",
                icon: Icons.image,
                onTap: () {
                  pickImage(source: ImageSource.gallery);
                  Navigator.maybePop(context);
                },
              ),
              ModalTile(
                title: "Document",
                subtitle: "",
                icon: Icons.tab,
                onTap: () {
                  pickImage(source: null);
                  Navigator.maybePop(context);
                },
              ),
            ],
          );
        });
  }

  CustomAppBar customAppBar(context) {
    return CustomAppBar(
      leading: IconButton(
        icon: Icon(Icons.arrow_back, color: UniversalVariables.blackColor),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      centerTitle: false,
      title: Text(
        widget.vendor.name,
        style: TextStyle(color: UniversalVariables.blackColor),
      ),
      actions: <Widget>[],
    );
  }

  Future<void> pickImage({ImageSource source}) async {
    if (source == null) {
      FilePickerResult result =
          await FilePicker.platform.pickFiles(allowedExtensions: [
        'pdf',
      ], type: FileType.custom, allowMultiple: false);
      if (result.names != null && result.names.length > 0)
        sendAttachment(result.files.first.path, false);
    } else if (source == ImageSource.gallery) {
      FilePickerResult result = await FilePicker.platform.pickFiles(
          allowedExtensions: ['jpg', 'png'],
          type: FileType.custom,
          allowMultiple: false);
      if (result.names != null && result.names.length > 0)
        sendAttachment(result.files.first.path, true);
    } else {
      PickedFile pickedFile = await ImagePicker()
          .getImage(source: source, preferredCameraDevice: CameraDevice.rear);
      if (pickedFile == null)
        pickedFile = (await ImagePicker().getLostData()).file;

      if (pickedFile != null) sendAttachment(pickedFile.path, true);
    }
  }

  sendAttachment(String path, bool isImage) {
    _storageMethods.uploadImage(
        image: File(path),
        chatId: widget.chatId,
        imageUploadProvider: null,
        isImage: isImage);
  }
}

class ModalTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Function onTap;

  const ModalTile({
    @required this.title,
    @required this.subtitle,
    @required this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: CustomTile(
        mini: false,
        onTap: onTap,
        leading: Container(
          margin: EdgeInsets.only(right: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: UniversalVariables.receiverColor,
          ),
          padding: EdgeInsets.all(10),
          child: Icon(
            icon,
            color: UniversalVariables.greyColor,
            size: 38,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            color: UniversalVariables.greyColor,
            fontSize: 14,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}
