import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/app_theme//screen_util-extension.dart';
import 'package:home_advisor/app_theme/app_colors.dart';
import 'package:home_advisor/chat_model/models/contact.dart';
import 'package:home_advisor/chat_model/provider/user_provider.dart';
import 'package:home_advisor/chat_model/resources/chat_methods.dart';
import 'package:home_advisor/chat_model/screens/pageviews/chats/widgets/contact_view.dart';
import 'package:home_advisor/chat_model/screens/pageviews/chats/widgets/quiet_box.dart';
import 'package:provider/provider.dart';

class ChatListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.square(100.h),
        child: AppBar(
          leading: SizedBox(),
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              colors: [AppColor.blGradient2, AppColor.blGradient1],
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
            )),
            child: Padding(
              padding: EdgeInsets.only(left: 25.w, right: 25.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 40.h,
                  ),
                  SizedBox(
                    height: 18.h,
                  ),
                  Text(
                    'Chat',
                    style: TextStyle(
                      fontSize: 40.f,
                      color: Colors.white,
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      body: ChatListContainer(),
    );
  }
}

class ChatListContainer extends StatelessWidget {
  final ChatMethods _chatMethods = ChatMethods();

  @override
  Widget build(BuildContext context) {
    final UserProvider userProvider = Provider.of<UserProvider>(context);

    return Container(
      child: StreamBuilder<QuerySnapshot>(
          stream: _chatMethods.fetchContacts(
            userId: userProvider.getUser.uid,
          ),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              print('got the respon');
              print(snapshot.data.docs.length);
              var docList = snapshot.data.docs;

              if (docList.isEmpty) {
                return QuietBox(
                  heading: "There is no customers contacted you",
                  subtitle: "Keep maintaining!!!",
                );
              }
              return ListView.builder(
                padding: EdgeInsets.all(10),
                itemCount: docList.length,
                itemBuilder: (context, index) {
                  print(docList[index].data());
                  Contact contact = Contact.fromMap(docList[index].data());
                  if (contact != null)
                    return ViewLayout(
                      contact: contact,
                    );
                  else
                    return Text('');
                },
              );
            }

            return Center(child: CircularProgressIndicator());
          }),
    );
  }
}
