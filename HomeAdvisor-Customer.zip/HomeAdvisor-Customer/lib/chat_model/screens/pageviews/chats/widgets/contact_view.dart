import 'package:flutter/material.dart';
import 'package:home_advisor/chat_model/models/contact.dart';
import 'package:home_advisor/chat_model/models/user.dart';
import 'package:home_advisor/chat_model/resources/auth_methods.dart';
import 'package:home_advisor/chat_model/resources/chat_methods.dart';
import 'package:home_advisor/chat_model/screens/chatscreens/chat_screen.dart';
import 'package:home_advisor/chat_model/screens/chatscreens/widgets/cached_image.dart';
import 'package:home_advisor/chat_model/widgets/custom_tile.dart';

class ContactView extends StatelessWidget {
  final Contact contact;
  final AuthMethods _authMethods = AuthMethods();

  ContactView(this.contact);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<User>(
      future: _authMethods.getUserDetailsById(contact.uid),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          User user = snapshot.data;

          return ViewLayout(
            contact: null,
          );
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }
}

class ViewLayout extends StatelessWidget {
  final Contact contact;
  final ChatMethods _chatMethods = ChatMethods();

  ViewLayout({
    @required this.contact,
  });

  @override
  Widget build(BuildContext context) {
    return CustomTile(
      mini: false,
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChatScreen(
              chatId: contact.uid,
              vendor: null,
            ),
          )),
      title: Text(
        '${contact.name} (${contact.id}) ' ?? contact.uid,
        style: TextStyle(
            color: Colors.black,
            fontFamily: "Arial",
            fontWeight: FontWeight.bold,
            fontSize: 19),
      ),
      leading: Container(
        constraints: BoxConstraints(maxHeight: 60, maxWidth: 60),
        child: Stack(
          children: <Widget>[
            CachedImage(
              'contact',
              radius: 80,
              isRound: true,
            ),
          ],
        ),
      ),
    );
  }
}
