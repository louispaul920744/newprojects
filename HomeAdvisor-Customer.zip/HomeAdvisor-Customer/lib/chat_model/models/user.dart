class User {
  String uid;
  String name;
  String email;
  String phone;
  String type;

  String profilePhoto;

  User({
    this.uid,
    this.name,
    this.email,
    this.phone,
    this.type,
    this.profilePhoto,
  });

  Map toMap(User user) {
    var data = Map<String, dynamic>();
    data['uid'] = user.uid;
    data['name'] = user.name;
    data['email'] = user.email;
    data['username'] = user.phone;
    data["status"] = user.type;
    data["profile_photo"] = user.profilePhoto;
    return data;
  }

  Map toJson() {
    var data = Map<String, dynamic>();
    data['uid'] = this.uid;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data["status"] = this.type;
    data["profile_photo"] = this.profilePhoto;
    return data;
  }

  // Named constructor
  User.fromMap(Map<String, dynamic> mapData) {
    print('mapData');
    print(mapData);
    this.uid = mapData['uid'];
    this.name = mapData['name'];
    this.email = mapData['email'];
    this.phone = mapData['phone_number'];
    this.type = mapData['type'];
    this.profilePhoto = mapData['image_url'] ?? mapData['profile_photo'];
  }
}
