import 'package:cloud_firestore/cloud_firestore.dart';

class Message {
  String senderId;
  String receiverId;
  String type;
  String message;
  String userType;
  Timestamp timestamp;
  String photoUrl;
  List<Attachemt> attachment;

  Message({
    this.senderId,
    this.receiverId,
    this.type,
    this.userType,
    this.message,
    this.timestamp,
  });

  //Will be only called when you wish to send an image
  // named constructor
  Message.imageMessage({
    this.senderId,
    this.receiverId,
    this.message,
    this.type,
    this.timestamp,
    this.photoUrl,
  });

  Map toMap() {
    var map = Map<String, dynamic>();
    map['senderId'] = this.senderId;
    map['receiverId'] = this.receiverId;
    map['type'] = this.type;
    map['message'] = this.message;
    map['userType'] = this.userType;
    map['timestamp'] = this.timestamp;
    return map;
  }

  Map toImageMap() {
    var map = Map<String, dynamic>();
    map['message'] = this.message;
    map['senderId'] = this.senderId;
    map['receiverId'] = this.receiverId;
    map['type'] = this.type;
    map['userType'] = this.userType;
    map['timestamp'] = this.timestamp;
    map['photoUrl'] = this.photoUrl;
    return map;
  }

  // named constructor
  Message.fromMap(Map<String, dynamic> map) {
    print(map);
    print('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    this.userType = map['userType'];
    this.type = map['message']['type'];
    this.timestamp = map['at'];
    print('attachment.length');
    print('attachment. ${map['message']['type']}');
    if (map['message']['type'] == 'image') {
      attachment = new List<Attachemt>();
      map['message']['item'].forEach((v) {
        attachment.add(new Attachemt.fromJson(v));
      });
      print('attachment.length');
      print('this.type');
      print(this.type);
      print(attachment.length);
    } else if (map['message']['type'] == 'text') {
      this.message = map['message']['item'];
    } else if (map['message']['type'] == 'docs') {
      print('%%%%%%%  ${map['message']['item']}');

      attachment = new List<Attachemt>();
      map['message']['item'].forEach((v) {
        attachment.add(new Attachemt.fromJson(v));
      });
      print('attachment.length');
      print('this.type');
      print(this.type);
      print(attachment.length);
    } else
      this.message = 'doc';

    // this.senderId = map['senderId'];
    // this.receiverId = map['receiverId'];
    //
    // this.photoUrl = map['photoUrl'];
  }
}

class Attachemt {
  String fileName;
  String attachment;

  Attachemt({this.fileName, this.attachment});

  Attachemt.fromJson(Map<String, dynamic> json) {
    fileName = json['fileName'];
    attachment = json['attachment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fileName'] = this.fileName;
    data['attachment'] = this.attachment;
    return data;
  }
}
