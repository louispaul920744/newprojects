import 'package:cloud_firestore/cloud_firestore.dart';

class Contact {
  String uid;
  Timestamp addedOn;
  String name;
  String id;

  Contact({
    this.uid,
    this.addedOn,
    this.name,
    this.id,
  });

  Map toMap(Contact contact) {
    var data = Map<String, dynamic>();
    data['contact_id'] = contact.uid;
    data['added_on'] = contact.addedOn;
    return data;
  }

  Contact.fromMap(Map<String, dynamic> mapData) {
    this.uid = mapData['chatId'];
    this.addedOn = mapData["at"];
    this.name = mapData["details"]["name"];
    this.id = mapData["details"]["id"].toString();
  }
}
