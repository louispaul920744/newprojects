enum ViewState{

  IDLE,
  LOADING,

}