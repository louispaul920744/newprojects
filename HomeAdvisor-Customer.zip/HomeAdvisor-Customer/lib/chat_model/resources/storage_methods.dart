import 'dart:io';
import 'package:path/path.dart' as p;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/widgets.dart';
import 'package:home_advisor/chat_model/models/user.dart';
import 'package:home_advisor/chat_model/provider/image_upload_provider.dart';
import 'package:home_advisor/chat_model/resources/chat_methods.dart';

class StorageMethods {
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;

  FirebaseStorage _storageReference = FirebaseStorage.instance;

  //user class
  User user = User();

  Future<String> uploadImageToStorage(File imageFile) async {
    // mention try catch later on

    try {
      String fileName = 'uploads/${DateTime.now().millisecondsSinceEpoch}}';

      await _storageReference.ref(fileName).putFile(imageFile);

      var url = _storageReference.ref(fileName).getDownloadURL();
      // print(url);
      return url;
    } catch (e) {
      return null;
    }
  }

  void uploadImage({
    @required File image,
    @required String chatId,
    @required ImageUploadProvider imageUploadProvider,
    @required bool isImage,
  }) async {
    final ChatMethods chatMethods = ChatMethods();

    // Set some loading value to db and show it to user
    // imageUploadProvider.setToLoading();

    // Get url from the image bucket
    String url = await uploadImageToStorage(image);

    // Hide loading
    // imageUploadProvider.setToIdle();
    var message = {
      'message': {
        'item': [
          {'attachment': url, 'fileName': p.basename(image.path)}
        ],
        'type': isImage ? 'image' : 'docs',
      }
    };

    print('%%%%%%%%%%%%%%%%%%%%%%% ${message}');
    chatMethods.addMessageToDb(message, chatId);
  }
}
