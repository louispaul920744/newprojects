import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:home_advisor/Helper/Helper.dart';
import 'package:home_advisor/chat_model/constants/strings.dart';
import 'package:home_advisor/chat_model/enum/user_state.dart';
import 'package:home_advisor/chat_model/models/user.dart' as U;
import 'package:home_advisor/chat_model/utils/utilities.dart';
import 'package:home_advisor/ui/orders_page/models/orders_ongoing%20_model.dart';

class AuthMethods {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;

  static final CollectionReference _userCollection =
      _firestore.collection(USERS_COLLECTION);

  Future<User> getCurrentUser() async {
    User currentUser;
    currentUser = _auth.currentUser;

    return currentUser;
  }

  Future<QuerySnapshot> getVendorRequestNode(Results model) async {
    return await (FirebaseFirestore.instance
            .collection('vendorChatRequests')
            .doc(model.vendor_uid)
            .collection('requestedChatIds')
            .where('chatId', isEqualTo: model.chat_id))
        .get();
  }

  updateVendorChatRequest(Results model) async {
    print('%%%%%%%%%%%%% updateVendorChatRequest ))))))))))))))');
    await FirebaseFirestore.instance
        .collection('vendorChatRequests')
        .doc(model.vendor_uid)
        .collection('requestedChatIds')
        .add({
      'at': Timestamp.now(),
      'chatId': model.chat_id,
      'details': {
        'id': model.orderNo,
        'name': model.name.english,
        'date': Helper.formatDate(model.date),
      },
      'customerDetails': (await getUserDetails()).toJson()
    });
  }

  Future<U.User> requestChat(Results model) async {
    try {
      print('chat ${model.chat_id}   ${model.toJson()}');
      // var vendorRequestNode = await getVendorRequestNode(model);

      // if (vendorRequestNode != null && vendorRequestNode.size > 0) {
      //   print('aaaaaaAAAHHHH');
      //   // await vendorRequestNode.docs.first.reference
      //   //     .update({'at': Timestamp.now()});
      // } else {
      //   // print('eeeeeee');
      //   // print((await getUserDetails()).toJson().toString());
      //   // return null;
      //   // updateVendorChatRequest(model);
      //
      // }
      print('sssssssssss');
      return (await getUserDetailsById(model.vendor_uid));
    } catch (e, s) {
      print('e');
      print(e);
      print(s);
      return null;
    }
  }

  Future<U.User> getUserDetails() async {
    User currentUser = await getCurrentUser();
    print(currentUser.uid == null);
    DocumentSnapshot documentSnapshot =
        await _userCollection.doc(currentUser.uid).get();

    print(documentSnapshot.data());
    return U.User.fromMap(documentSnapshot.data());
  }

  Future<U.User> getUserDetailsById(id) async {
    try {
      DocumentSnapshot documentSnapshot = await _userCollection.doc(id).get();
      return U.User.fromMap(documentSnapshot.data());
    } catch (e) {
      print(e);
      return null;
    }
  }

  Future<bool> authenticateUser(User user) async {
    QuerySnapshot result = await firestore
        .collection(USERS_COLLECTION)
        .where(EMAIL_FIELD, isEqualTo: user.email)
        .get();

    final List<DocumentSnapshot> docs = result.docs;

    //if user is registered then length of list > 0 or else less than 0
    return docs.length == 0 ? true : false;
  }

  Future<void> addDataToDb(User currentUser) async {
    String username = Utils.getUsername(currentUser.email);

    U.User user = U.User(
        uid: currentUser.uid,
        email: currentUser.email,
        name: currentUser.displayName,
        profilePhoto: currentUser.photoURL,
        phone: username);

    firestore
        .collection(USERS_COLLECTION)
        .doc(currentUser.uid)
        .set(user.toMap(user));
  }

  Future<List<U.User>> fetchAllUsers(User currentUser) async {
    List<U.User> userList = List<U.User>();

    QuerySnapshot querySnapshot =
        await firestore.collection(USERS_COLLECTION).get();
    for (var i = 0; i < querySnapshot.docs.length; i++) {
      if (querySnapshot.docs[i].id != currentUser.uid) {
        userList.add(U.User.fromMap(querySnapshot.docs[i].data()));
      }
    }
    return userList;
  }

  Future<bool> signOut() async {
    try {
      await _auth.signOut();
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }

  void setUserState({@required String userId, @required UserState userState}) {
    int stateNum = Utils.stateToNum(userState);

    _userCollection.doc(userId).update({
      "state": stateNum,
    });
  }

  Stream<DocumentSnapshot> getUserStream({@required String uid}) =>
      _userCollection.doc(uid).snapshots();
}
