import 'package:flutter/widgets.dart';
import 'package:home_advisor/chat_model/models/user.dart';
import 'package:home_advisor/chat_model/resources/auth_methods.dart';

class UserProvider with ChangeNotifier {
  User _user;
  AuthMethods _authMethods = AuthMethods();

  User get getUser => _user;

  Future<void> refreshUser() async {
    User user = await _authMethods.getUserDetails();
    print('user.toString()');
    print(user.toMap(user));
    _user = user;
    notifyListeners();
  }
}
